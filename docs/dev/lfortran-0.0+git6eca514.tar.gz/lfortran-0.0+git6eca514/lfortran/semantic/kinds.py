"""
LFortran type kind numbers
"""

int8 = 1
int16 = 2
int32 = 4
int64 = 8

real32 = 4
real64 = 8
real128 = 16
