// Uncomment the following line to stop catching exceptions and segfaults, thus
// allowing to use gdb to figure out where the code fails (also put this line
// into every test at the top):
//#define DOCTEST_CONFIG_NO_EXCEPTIONS

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
