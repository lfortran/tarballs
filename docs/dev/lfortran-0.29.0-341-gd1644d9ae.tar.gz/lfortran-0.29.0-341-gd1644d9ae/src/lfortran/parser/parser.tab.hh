/* A Bison parser, made by GNU Bison 3.4.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy"

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh"

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_LABEL = 262,
    TK_REAL = 263,
    TK_BOZ_CONSTANT = 264,
    TK_PLUS = 265,
    TK_MINUS = 266,
    TK_STAR = 267,
    TK_SLASH = 268,
    TK_COLON = 269,
    TK_SEMICOLON = 270,
    TK_COMMA = 271,
    TK_EQUAL = 272,
    TK_LPAREN = 273,
    TK_RPAREN = 274,
    TK_LBRACKET = 275,
    TK_RBRACKET = 276,
    TK_LBRACE = 277,
    TK_RBRACE = 278,
    TK_RBRACKET_OLD = 279,
    TK_PERCENT = 280,
    TK_VBAR = 281,
    TK_STRING = 282,
    TK_COMMENT = 283,
    TK_EOLCOMMENT = 284,
    TK_PRAGMA = 285,
    TK_DBL_DOT = 286,
    TK_DBL_COLON = 287,
    TK_POW = 288,
    TK_CONCAT = 289,
    TK_ARROW = 290,
    TK_EQ = 291,
    TK_NE = 292,
    TK_LT = 293,
    TK_LE = 294,
    TK_GT = 295,
    TK_GE = 296,
    TK_NOT = 297,
    TK_AND = 298,
    TK_OR = 299,
    TK_XOR = 300,
    TK_EQV = 301,
    TK_NEQV = 302,
    TK_TRUE = 303,
    TK_FALSE = 304,
    TK_FORMAT = 305,
    KW_ABSTRACT = 306,
    KW_ALL = 307,
    KW_ALLOCATABLE = 308,
    KW_ALLOCATE = 309,
    KW_ASSIGN = 310,
    KW_ASSIGNMENT = 311,
    KW_ASSOCIATE = 312,
    KW_ASYNCHRONOUS = 313,
    KW_BACKSPACE = 314,
    KW_BIND = 315,
    KW_BLOCK = 316,
    KW_CALL = 317,
    KW_CASE = 318,
    KW_CHANGE = 319,
    KW_CHANGE_TEAM = 320,
    KW_CHARACTER = 321,
    KW_CLASS = 322,
    KW_CLOSE = 323,
    KW_CODIMENSION = 324,
    KW_COMMON = 325,
    KW_COMPLEX = 326,
    KW_CONCURRENT = 327,
    KW_CONTAINS = 328,
    KW_CONTIGUOUS = 329,
    KW_CONTINUE = 330,
    KW_CRITICAL = 331,
    KW_CYCLE = 332,
    KW_DATA = 333,
    KW_DEALLOCATE = 334,
    KW_DEFAULT = 335,
    KW_DEFERRED = 336,
    KW_DIMENSION = 337,
    KW_DO = 338,
    KW_DOWHILE = 339,
    KW_DOUBLE = 340,
    KW_DOUBLE_PRECISION = 341,
    KW_DOUBLE_COMPLEX = 342,
    KW_ELEMENTAL = 343,
    KW_ELSE = 344,
    KW_ELSEIF = 345,
    KW_ELSEWHERE = 346,
    KW_END = 347,
    KW_END_PROGRAM = 348,
    KW_ENDPROGRAM = 349,
    KW_END_MODULE = 350,
    KW_ENDMODULE = 351,
    KW_END_SUBMODULE = 352,
    KW_ENDSUBMODULE = 353,
    KW_END_BLOCK = 354,
    KW_ENDBLOCK = 355,
    KW_END_BLOCK_DATA = 356,
    KW_ENDBLOCKDATA = 357,
    KW_END_SUBROUTINE = 358,
    KW_ENDSUBROUTINE = 359,
    KW_END_FUNCTION = 360,
    KW_ENDFUNCTION = 361,
    KW_END_PROCEDURE = 362,
    KW_ENDPROCEDURE = 363,
    KW_END_ENUM = 364,
    KW_ENDENUM = 365,
    KW_END_SELECT = 366,
    KW_ENDSELECT = 367,
    KW_END_IF = 368,
    KW_ENDIF = 369,
    KW_END_INTERFACE = 370,
    KW_ENDINTERFACE = 371,
    KW_END_TYPE = 372,
    KW_ENDTYPE = 373,
    KW_END_ASSOCIATE = 374,
    KW_ENDASSOCIATE = 375,
    KW_END_FORALL = 376,
    KW_ENDFORALL = 377,
    KW_END_DO = 378,
    KW_ENDDO = 379,
    KW_END_WHERE = 380,
    KW_ENDWHERE = 381,
    KW_END_CRITICAL = 382,
    KW_ENDCRITICAL = 383,
    KW_END_FILE = 384,
    KW_ENDFILE = 385,
    KW_END_TEAM = 386,
    KW_ENDTEAM = 387,
    KW_ENTRY = 388,
    KW_ENUM = 389,
    KW_ENUMERATOR = 390,
    KW_EQUIVALENCE = 391,
    KW_ERRMSG = 392,
    KW_ERROR = 393,
    KW_EVENT = 394,
    KW_EXIT = 395,
    KW_EXTENDS = 396,
    KW_EXTERNAL = 397,
    KW_FILE = 398,
    KW_FINAL = 399,
    KW_FLUSH = 400,
    KW_FORALL = 401,
    KW_FORMATTED = 402,
    KW_FORM = 403,
    KW_FORM_TEAM = 404,
    KW_FUNCTION = 405,
    KW_GENERIC = 406,
    KW_GO = 407,
    KW_GOTO = 408,
    KW_IF = 409,
    KW_IMAGES = 410,
    KW_IMPLICIT = 411,
    KW_IMPORT = 412,
    KW_IMPURE = 413,
    KW_IN = 414,
    KW_INCLUDE = 415,
    KW_INOUT = 416,
    KW_IN_OUT = 417,
    KW_INQUIRE = 418,
    KW_INSTANTIATE = 419,
    KW_INTEGER = 420,
    KW_INTENT = 421,
    KW_INTERFACE = 422,
    KW_INTRINSIC = 423,
    KW_IS = 424,
    KW_KIND = 425,
    KW_LEN = 426,
    KW_LOCAL = 427,
    KW_LOCAL_INIT = 428,
    KW_LOGICAL = 429,
    KW_MEMORY = 430,
    KW_MODULE = 431,
    KW_MOLD = 432,
    KW_NAME = 433,
    KW_NAMELIST = 434,
    KW_NEW_INDEX = 435,
    KW_NOPASS = 436,
    KW_NON_INTRINSIC = 437,
    KW_NON_OVERRIDABLE = 438,
    KW_NON_RECURSIVE = 439,
    KW_NONE = 440,
    KW_NULLIFY = 441,
    KW_ONLY = 442,
    KW_OPEN = 443,
    KW_OPERATOR = 444,
    KW_OPTIONAL = 445,
    KW_OUT = 446,
    KW_PARAMETER = 447,
    KW_PASS = 448,
    KW_POINTER = 449,
    KW_POST = 450,
    KW_PRECISION = 451,
    KW_PRINT = 452,
    KW_PRIVATE = 453,
    KW_PROCEDURE = 454,
    KW_PROGRAM = 455,
    KW_PROTECTED = 456,
    KW_PUBLIC = 457,
    KW_PURE = 458,
    KW_QUIET = 459,
    KW_RANK = 460,
    KW_READ = 461,
    KW_REAL = 462,
    KW_RECURSIVE = 463,
    KW_REDUCE = 464,
    KW_RESULT = 465,
    KW_RETURN = 466,
    KW_REWIND = 467,
    KW_SAVE = 468,
    KW_SELECT = 469,
    KW_SELECT_CASE = 470,
    KW_SELECT_RANK = 471,
    KW_SELECT_TYPE = 472,
    KW_SEQUENCE = 473,
    KW_SHARED = 474,
    KW_SOURCE = 475,
    KW_STAT = 476,
    KW_STOP = 477,
    KW_SUBMODULE = 478,
    KW_SUBROUTINE = 479,
    KW_SYNC = 480,
    KW_SYNC_ALL = 481,
    KW_SYNC_IMAGES = 482,
    KW_SYNC_MEMORY = 483,
    KW_SYNC_TEAM = 484,
    KW_TARGET = 485,
    KW_TEAM = 486,
    KW_TEAM_NUMBER = 487,
    KW_REQUIREMENT = 488,
    KW_REQUIRE = 489,
    KW_TEMPLATE = 490,
    KW_THEN = 491,
    KW_TO = 492,
    KW_TYPE = 493,
    KW_UNFORMATTED = 494,
    KW_USE = 495,
    KW_VALUE = 496,
    KW_VOLATILE = 497,
    KW_WAIT = 498,
    KW_WHERE = 499,
    KW_WHILE = 500,
    KW_WRITE = 501,
    UMINUS = 502
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LCompilers::LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LCompilers::LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
