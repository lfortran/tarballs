/* A Bison parser, made by GNU Bison 3.4.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy"

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh"

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_LABEL = 262,
    TK_REAL = 263,
    TK_BOZ_CONSTANT = 264,
    TK_PLUS = 265,
    TK_MINUS = 266,
    TK_STAR = 267,
    TK_SLASH = 268,
    TK_COLON = 269,
    TK_SEMICOLON = 270,
    TK_COMMA = 271,
    TK_EQUAL = 272,
    TK_LPAREN = 273,
    TK_RPAREN = 274,
    TK_LBRACKET = 275,
    TK_RBRACKET = 276,
    TK_LBRACE = 277,
    TK_RBRACE = 278,
    TK_RBRACKET_OLD = 279,
    TK_PERCENT = 280,
    TK_VBAR = 281,
    TK_STRING = 282,
    TK_COMMENT = 283,
    TK_EOLCOMMENT = 284,
    TK_PRAGMA_DECL = 285,
    TK_OMP = 286,
    TK_OMP_END = 287,
    TK_DBL_DOT = 288,
    TK_DBL_COLON = 289,
    TK_POW = 290,
    TK_CONCAT = 291,
    TK_ARROW = 292,
    TK_EQ = 293,
    TK_NE = 294,
    TK_LT = 295,
    TK_LE = 296,
    TK_GT = 297,
    TK_GE = 298,
    TK_NOT = 299,
    TK_AND = 300,
    TK_OR = 301,
    TK_XOR = 302,
    TK_EQV = 303,
    TK_NEQV = 304,
    TK_TRUE = 305,
    TK_FALSE = 306,
    TK_FORMAT = 307,
    KW_ABSTRACT = 308,
    KW_ALL = 309,
    KW_ALLOCATABLE = 310,
    KW_ALLOCATE = 311,
    KW_ASSIGN = 312,
    KW_ASSIGNMENT = 313,
    KW_ASSOCIATE = 314,
    KW_ASYNCHRONOUS = 315,
    KW_BACKSPACE = 316,
    KW_BIND = 317,
    KW_BLOCK = 318,
    KW_CALL = 319,
    KW_CASE = 320,
    KW_CHANGE = 321,
    KW_CHANGE_TEAM = 322,
    KW_CHARACTER = 323,
    KW_CLASS = 324,
    KW_CLOSE = 325,
    KW_CODIMENSION = 326,
    KW_COMMON = 327,
    KW_COMPLEX = 328,
    KW_CONCURRENT = 329,
    KW_CONTAINS = 330,
    KW_CONTIGUOUS = 331,
    KW_CONTINUE = 332,
    KW_CRITICAL = 333,
    KW_CYCLE = 334,
    KW_DATA = 335,
    KW_DEALLOCATE = 336,
    KW_DEFAULT = 337,
    KW_DEFERRED = 338,
    KW_DIMENSION = 339,
    KW_DO = 340,
    KW_DOWHILE = 341,
    KW_DOUBLE = 342,
    KW_DOUBLE_PRECISION = 343,
    KW_DOUBLE_COMPLEX = 344,
    KW_ELEMENTAL = 345,
    KW_ELSE = 346,
    KW_ELSEIF = 347,
    KW_ELSEWHERE = 348,
    KW_END = 349,
    KW_END_PROGRAM = 350,
    KW_ENDPROGRAM = 351,
    KW_END_MODULE = 352,
    KW_ENDMODULE = 353,
    KW_END_SUBMODULE = 354,
    KW_ENDSUBMODULE = 355,
    KW_END_BLOCK = 356,
    KW_ENDBLOCK = 357,
    KW_END_BLOCK_DATA = 358,
    KW_ENDBLOCKDATA = 359,
    KW_END_SUBROUTINE = 360,
    KW_ENDSUBROUTINE = 361,
    KW_END_FUNCTION = 362,
    KW_ENDFUNCTION = 363,
    KW_END_PROCEDURE = 364,
    KW_ENDPROCEDURE = 365,
    KW_END_ENUM = 366,
    KW_ENDENUM = 367,
    KW_END_SELECT = 368,
    KW_ENDSELECT = 369,
    KW_END_IF = 370,
    KW_ENDIF = 371,
    KW_END_INTERFACE = 372,
    KW_ENDINTERFACE = 373,
    KW_END_TYPE = 374,
    KW_ENDTYPE = 375,
    KW_END_ASSOCIATE = 376,
    KW_ENDASSOCIATE = 377,
    KW_END_FORALL = 378,
    KW_ENDFORALL = 379,
    KW_END_DO = 380,
    KW_ENDDO = 381,
    KW_END_WHERE = 382,
    KW_ENDWHERE = 383,
    KW_END_CRITICAL = 384,
    KW_ENDCRITICAL = 385,
    KW_END_FILE = 386,
    KW_ENDFILE = 387,
    KW_END_TEAM = 388,
    KW_ENDTEAM = 389,
    KW_ENTRY = 390,
    KW_ENUM = 391,
    KW_ENUMERATOR = 392,
    KW_EQUIVALENCE = 393,
    KW_ERRMSG = 394,
    KW_ERROR = 395,
    KW_EVENT = 396,
    KW_EXIT = 397,
    KW_EXTENDS = 398,
    KW_EXTERNAL = 399,
    KW_FILE = 400,
    KW_FINAL = 401,
    KW_FLUSH = 402,
    KW_FORALL = 403,
    KW_FORMATTED = 404,
    KW_FORM = 405,
    KW_FORM_TEAM = 406,
    KW_FUNCTION = 407,
    KW_GENERIC = 408,
    KW_GO = 409,
    KW_GOTO = 410,
    KW_IF = 411,
    KW_IMAGES = 412,
    KW_IMPLICIT = 413,
    KW_IMPORT = 414,
    KW_IMPURE = 415,
    KW_IN = 416,
    KW_INCLUDE = 417,
    KW_INOUT = 418,
    KW_IN_OUT = 419,
    KW_INQUIRE = 420,
    KW_INSTANTIATE = 421,
    KW_INTEGER = 422,
    KW_INTENT = 423,
    KW_INTERFACE = 424,
    KW_INTRINSIC = 425,
    KW_IS = 426,
    KW_KIND = 427,
    KW_LEN = 428,
    KW_LOCAL = 429,
    KW_LOCAL_INIT = 430,
    KW_LOGICAL = 431,
    KW_MEMORY = 432,
    KW_MODULE = 433,
    KW_MOLD = 434,
    KW_NAME = 435,
    KW_NAMELIST = 436,
    KW_NEW_INDEX = 437,
    KW_NOPASS = 438,
    KW_NON_INTRINSIC = 439,
    KW_NON_OVERRIDABLE = 440,
    KW_NON_RECURSIVE = 441,
    KW_NONE = 442,
    KW_NULLIFY = 443,
    KW_ONLY = 444,
    KW_OPEN = 445,
    KW_OPERATOR = 446,
    KW_OPTIONAL = 447,
    KW_OUT = 448,
    KW_PARAMETER = 449,
    KW_PASS = 450,
    KW_POINTER = 451,
    KW_POST = 452,
    KW_PRECISION = 453,
    KW_PRINT = 454,
    KW_PRIVATE = 455,
    KW_PROCEDURE = 456,
    KW_PROGRAM = 457,
    KW_PROTECTED = 458,
    KW_PUBLIC = 459,
    KW_PURE = 460,
    KW_QUIET = 461,
    KW_RANK = 462,
    KW_READ = 463,
    KW_REAL = 464,
    KW_RECURSIVE = 465,
    KW_REDUCE = 466,
    KW_RESULT = 467,
    KW_RETURN = 468,
    KW_REWIND = 469,
    KW_SAVE = 470,
    KW_SELECT = 471,
    KW_SELECT_CASE = 472,
    KW_SELECT_RANK = 473,
    KW_SELECT_TYPE = 474,
    KW_SEQUENCE = 475,
    KW_SHARED = 476,
    KW_SOURCE = 477,
    KW_STAT = 478,
    KW_STOP = 479,
    KW_SUBMODULE = 480,
    KW_SUBROUTINE = 481,
    KW_SYNC = 482,
    KW_SYNC_ALL = 483,
    KW_SYNC_IMAGES = 484,
    KW_SYNC_MEMORY = 485,
    KW_SYNC_TEAM = 486,
    KW_TARGET = 487,
    KW_TEAM = 488,
    KW_TEAM_NUMBER = 489,
    KW_REQUIREMENT = 490,
    KW_REQUIRE = 491,
    KW_TEMPLATE = 492,
    KW_THEN = 493,
    KW_TO = 494,
    KW_TYPE = 495,
    KW_UNFORMATTED = 496,
    KW_USE = 497,
    KW_VALUE = 498,
    KW_VOLATILE = 499,
    KW_WAIT = 500,
    KW_WHERE = 501,
    KW_WHILE = 502,
    KW_WRITE = 503,
    KW_LF_LIST = 504,
    KW_LF_SET = 505,
    KW_LF_DICT = 506,
    KW_LF_TUPLE = 507,
    KW_LF_UNION_TYPE = 508,
    KW_LF_END_UNION_TYPE = 509,
    UMINUS = 510
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LCompilers::LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LCompilers::LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
