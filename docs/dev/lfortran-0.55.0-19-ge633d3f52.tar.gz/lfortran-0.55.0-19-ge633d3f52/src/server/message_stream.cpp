#include <server/message_stream.h>

namespace LCompilers::LLanguageServer {

    MessageStream::MessageStream() {
        // empty
    }

    MessageStream::~MessageStream() {
        // empty
    }

} // namespace LCompilers::LLanguageServer
