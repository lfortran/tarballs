// ------------------------------------------------------------------------------
// NOTE: This file was generated from Microsoft's Language Server Protocol (LSP)
// specification. Please do not edit it by hand.
// ------------------------------------------------------------------------------

#pragma once

#include <memory>

#include <server/lsp_specification.h>

namespace LCompilers::LanguageServerProtocol {

    class LspTransformer {
    public:
        auto anyToSemanticTokenTypes(
            const LSPAny &any
        ) const -> SemanticTokenTypes;
        auto semanticTokenTypesToAny(SemanticTokenTypes param) const -> LSPAny;
        auto anyToSemanticTokenModifiers(
            const LSPAny &any
        ) const -> SemanticTokenModifiers;
        auto semanticTokenModifiersToAny(
            SemanticTokenModifiers param
        ) const -> LSPAny;
        auto anyToDocumentDiagnosticReportKind(
            const LSPAny &any
        ) const -> DocumentDiagnosticReportKind;
        auto documentDiagnosticReportKindToAny(
            DocumentDiagnosticReportKind param
        ) const -> LSPAny;
        auto anyToErrorCodes(const LSPAny &any) const -> ErrorCodes;
        auto errorCodesToAny(ErrorCodes param) const -> LSPAny;
        auto anyToLSPErrorCodes(const LSPAny &any) const -> LSPErrorCodes;
        auto lspErrorCodesToAny(LSPErrorCodes param) const -> LSPAny;
        auto anyToFoldingRangeKind(
            const LSPAny &any
        ) const -> FoldingRangeKind;
        auto foldingRangeKindToAny(FoldingRangeKind param) const -> LSPAny;
        auto anyToFoldingRangeClientCapabilities_foldingRangeKind(
            const LSPAny &any
        ) const -> FoldingRangeClientCapabilities_foldingRangeKind;
        auto foldingRangeClientCapabilities_foldingRangeKindToAny(
            const FoldingRangeClientCapabilities_foldingRangeKind &param
        ) const -> LSPAny;
        auto anyToFoldingRangeClientCapabilities_foldingRangeKind_valueSet(
            const LSPAny &any
        ) const -> FoldingRangeClientCapabilities_foldingRangeKind_valueSet;
        auto foldingRangeClientCapabilities_foldingRangeKind_valueSetToAny(
            const FoldingRangeClientCapabilities_foldingRangeKind_valueSet &array
        ) const -> LSPAny;
        auto anyToSymbolKind(const LSPAny &any) const -> SymbolKind;
        auto symbolKindToAny(SymbolKind param) const -> LSPAny;
        auto anyToWorkspaceSymbolClientCapabilities_symbolKind(
            const LSPAny &any
        ) const -> WorkspaceSymbolClientCapabilities_symbolKind;
        auto workspaceSymbolClientCapabilities_symbolKindToAny(
            const WorkspaceSymbolClientCapabilities_symbolKind &param
        ) const -> LSPAny;
        auto anyToWorkspaceSymbolClientCapabilities_symbolKind_valueSet(
            const LSPAny &any
        ) const -> WorkspaceSymbolClientCapabilities_symbolKind_valueSet;
        auto workspaceSymbolClientCapabilities_symbolKind_valueSetToAny(
            const WorkspaceSymbolClientCapabilities_symbolKind_valueSet &array
        ) const -> LSPAny;
        auto anyToDocumentSymbolClientCapabilities_symbolKind(
            const LSPAny &any
        ) const -> DocumentSymbolClientCapabilities_symbolKind;
        auto documentSymbolClientCapabilities_symbolKindToAny(
            const DocumentSymbolClientCapabilities_symbolKind &param
        ) const -> LSPAny;
        auto anyToDocumentSymbolClientCapabilities_symbolKind_valueSet(
            const LSPAny &any
        ) const -> DocumentSymbolClientCapabilities_symbolKind_valueSet;
        auto documentSymbolClientCapabilities_symbolKind_valueSetToAny(
            const DocumentSymbolClientCapabilities_symbolKind_valueSet &array
        ) const -> LSPAny;
        auto anyToSymbolTag(const LSPAny &any) const -> SymbolTag;
        auto symbolTagToAny(SymbolTag param) const -> LSPAny;
        auto anyToCallHierarchyItem_tags(
            const LSPAny &any
        ) const -> CallHierarchyItem_tags;
        auto callHierarchyItem_tagsToAny(
            const CallHierarchyItem_tags &array
        ) const -> LSPAny;
        auto anyToTypeHierarchyItem_tags(
            const LSPAny &any
        ) const -> TypeHierarchyItem_tags;
        auto typeHierarchyItem_tagsToAny(
            const TypeHierarchyItem_tags &array
        ) const -> LSPAny;
        auto anyToDocumentSymbol_tags(
            const LSPAny &any
        ) const -> DocumentSymbol_tags;
        auto documentSymbol_tagsToAny(
            const DocumentSymbol_tags &array
        ) const -> LSPAny;
        auto anyToBaseSymbolInformation_tags(
            const LSPAny &any
        ) const -> BaseSymbolInformation_tags;
        auto baseSymbolInformation_tagsToAny(
            const BaseSymbolInformation_tags &array
        ) const -> LSPAny;
        auto anyToWorkspaceSymbolClientCapabilities_tagSupport(
            const LSPAny &any
        ) const -> WorkspaceSymbolClientCapabilities_tagSupport;
        auto workspaceSymbolClientCapabilities_tagSupportToAny(
            const WorkspaceSymbolClientCapabilities_tagSupport &param
        ) const -> LSPAny;
        auto anyToWorkspaceSymbolClientCapabilities_tagSupport_valueSet(
            const LSPAny &any
        ) const -> WorkspaceSymbolClientCapabilities_tagSupport_valueSet;
        auto workspaceSymbolClientCapabilities_tagSupport_valueSetToAny(
            const WorkspaceSymbolClientCapabilities_tagSupport_valueSet &array
        ) const -> LSPAny;
        auto anyToDocumentSymbolClientCapabilities_tagSupport(
            const LSPAny &any
        ) const -> DocumentSymbolClientCapabilities_tagSupport;
        auto documentSymbolClientCapabilities_tagSupportToAny(
            const DocumentSymbolClientCapabilities_tagSupport &param
        ) const -> LSPAny;
        auto anyToDocumentSymbolClientCapabilities_tagSupport_valueSet(
            const LSPAny &any
        ) const -> DocumentSymbolClientCapabilities_tagSupport_valueSet;
        auto documentSymbolClientCapabilities_tagSupport_valueSetToAny(
            const DocumentSymbolClientCapabilities_tagSupport_valueSet &array
        ) const -> LSPAny;
        auto anyToUniquenessLevel(const LSPAny &any) const -> UniquenessLevel;
        auto uniquenessLevelToAny(UniquenessLevel param) const -> LSPAny;
        auto anyToMonikerKind(const LSPAny &any) const -> MonikerKind;
        auto monikerKindToAny(MonikerKind param) const -> LSPAny;
        auto anyToInlayHintKind(const LSPAny &any) const -> InlayHintKind;
        auto inlayHintKindToAny(InlayHintKind param) const -> LSPAny;
        auto anyToMessageType(const LSPAny &any) const -> MessageType;
        auto messageTypeToAny(MessageType param) const -> LSPAny;
        auto anyToTextDocumentSyncKind(
            const LSPAny &any
        ) const -> TextDocumentSyncKind;
        auto textDocumentSyncKindToAny(
            TextDocumentSyncKind param
        ) const -> LSPAny;
        auto anyToTextDocumentSaveReason(
            const LSPAny &any
        ) const -> TextDocumentSaveReason;
        auto textDocumentSaveReasonToAny(
            TextDocumentSaveReason param
        ) const -> LSPAny;
        auto anyToCompletionItemKind(
            const LSPAny &any
        ) const -> CompletionItemKind;
        auto completionItemKindToAny(CompletionItemKind param) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItemKind(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItemKind;
        auto completionClientCapabilities_completionItemKindToAny(
            const CompletionClientCapabilities_completionItemKind &param
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItemKind_valueSet(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItemKind_valueSet;
        auto completionClientCapabilities_completionItemKind_valueSetToAny(
            const CompletionClientCapabilities_completionItemKind_valueSet &array
        ) const -> LSPAny;
        auto anyToCompletionItemTag(
            const LSPAny &any
        ) const -> CompletionItemTag;
        auto completionItemTagToAny(CompletionItemTag param) const -> LSPAny;
        auto anyToCompletionItem_tags(
            const LSPAny &any
        ) const -> CompletionItem_tags;
        auto completionItem_tagsToAny(
            const CompletionItem_tags &array
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItem_tagSupport(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItem_tagSupport;
        auto completionClientCapabilities_completionItem_tagSupportToAny(
            const CompletionClientCapabilities_completionItem_tagSupport &param
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItem_tagSupport_valueSet(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItem_tagSupport_valueSet;
        auto completionClientCapabilities_completionItem_tagSupport_valueSetToAny(
            const CompletionClientCapabilities_completionItem_tagSupport_valueSet &array
        ) const -> LSPAny;
        auto anyToInsertTextFormat(
            const LSPAny &any
        ) const -> InsertTextFormat;
        auto insertTextFormatToAny(InsertTextFormat param) const -> LSPAny;
        auto anyToInsertTextMode(const LSPAny &any) const -> InsertTextMode;
        auto insertTextModeToAny(InsertTextMode param) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItem_insertTextModeSupport(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItem_insertTextModeSupport;
        auto completionClientCapabilities_completionItem_insertTextModeSupportToAny(
            const CompletionClientCapabilities_completionItem_insertTextModeSupport &param
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItem_insertTextModeSupport_valueSet(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItem_insertTextModeSupport_valueSet;
        auto completionClientCapabilities_completionItem_insertTextModeSupport_valueSetToAny(
            const CompletionClientCapabilities_completionItem_insertTextModeSupport_valueSet &array
        ) const -> LSPAny;
        auto anyToDocumentHighlightKind(
            const LSPAny &any
        ) const -> DocumentHighlightKind;
        auto documentHighlightKindToAny(
            DocumentHighlightKind param
        ) const -> LSPAny;
        auto anyToCodeActionKind(const LSPAny &any) const -> CodeActionKind;
        auto codeActionKindToAny(CodeActionKind param) const -> LSPAny;
        auto anyToCodeActionContext_only(
            const LSPAny &any
        ) const -> CodeActionContext_only;
        auto codeActionContext_onlyToAny(
            const CodeActionContext_only &array
        ) const -> LSPAny;
        auto anyToCodeActionOptions_codeActionKinds(
            const LSPAny &any
        ) const -> CodeActionOptions_codeActionKinds;
        auto codeActionOptions_codeActionKindsToAny(
            const CodeActionOptions_codeActionKinds &array
        ) const -> LSPAny;
        auto anyToCodeActionClientCapabilities_codeActionLiteralSupport_codeActionKind(
            const LSPAny &any
        ) const -> CodeActionClientCapabilities_codeActionLiteralSupport_codeActionKind;
        auto codeActionClientCapabilities_codeActionLiteralSupport_codeActionKindToAny(
            const CodeActionClientCapabilities_codeActionLiteralSupport_codeActionKind &param
        ) const -> LSPAny;
        auto anyToCodeActionClientCapabilities_codeActionLiteralSupport(
            const LSPAny &any
        ) const -> CodeActionClientCapabilities_codeActionLiteralSupport;
        auto codeActionClientCapabilities_codeActionLiteralSupportToAny(
            const CodeActionClientCapabilities_codeActionLiteralSupport &param
        ) const -> LSPAny;
        auto anyToCodeActionClientCapabilities_codeActionLiteralSupport_codeActionKind_valueSet(
            const LSPAny &any
        ) const -> CodeActionClientCapabilities_codeActionLiteralSupport_codeActionKind_valueSet;
        auto codeActionClientCapabilities_codeActionLiteralSupport_codeActionKind_valueSetToAny(
            const CodeActionClientCapabilities_codeActionLiteralSupport_codeActionKind_valueSet &array
        ) const -> LSPAny;
        auto anyToTraceValues(const LSPAny &any) const -> TraceValues;
        auto traceValuesToAny(TraceValues param) const -> LSPAny;
        auto anyToSetTraceParams(const LSPAny &any) const -> SetTraceParams;
        auto setTraceParamsToAny(const SetTraceParams &param) const -> LSPAny;
        auto asSetTraceParams(
            const MessageParams &notificationParams
        ) const -> SetTraceParams;
        auto anyToMarkupKind(const LSPAny &any) const -> MarkupKind;
        auto markupKindToAny(MarkupKind param) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItem_documentationFormat(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItem_documentationFormat;
        auto completionClientCapabilities_completionItem_documentationFormatToAny(
            const CompletionClientCapabilities_completionItem_documentationFormat &array
        ) const -> LSPAny;
        auto anyToHoverClientCapabilities_contentFormat(
            const LSPAny &any
        ) const -> HoverClientCapabilities_contentFormat;
        auto hoverClientCapabilities_contentFormatToAny(
            const HoverClientCapabilities_contentFormat &array
        ) const -> LSPAny;
        auto anyToSignatureHelpClientCapabilities_signatureInformation_documentationFormat(
            const LSPAny &any
        ) const -> SignatureHelpClientCapabilities_signatureInformation_documentationFormat;
        auto signatureHelpClientCapabilities_signatureInformation_documentationFormatToAny(
            const SignatureHelpClientCapabilities_signatureInformation_documentationFormat &array
        ) const -> LSPAny;
        auto anyToInlineCompletionTriggerKind(
            const LSPAny &any
        ) const -> InlineCompletionTriggerKind;
        auto inlineCompletionTriggerKindToAny(
            InlineCompletionTriggerKind param
        ) const -> LSPAny;
        auto anyToPositionEncodingKind(
            const LSPAny &any
        ) const -> PositionEncodingKind;
        auto positionEncodingKindToAny(
            PositionEncodingKind param
        ) const -> LSPAny;
        auto anyToGeneralClientCapabilities_positionEncodings(
            const LSPAny &any
        ) const -> GeneralClientCapabilities_positionEncodings;
        auto generalClientCapabilities_positionEncodingsToAny(
            const GeneralClientCapabilities_positionEncodings &array
        ) const -> LSPAny;
        auto anyToFileChangeType(const LSPAny &any) const -> FileChangeType;
        auto fileChangeTypeToAny(FileChangeType param) const -> LSPAny;
        auto anyToWatchKind(const LSPAny &any) const -> WatchKind;
        auto watchKindToAny(WatchKind param) const -> LSPAny;
        auto anyToDiagnosticSeverity(
            const LSPAny &any
        ) const -> DiagnosticSeverity;
        auto diagnosticSeverityToAny(DiagnosticSeverity param) const -> LSPAny;
        auto anyToDiagnosticTag(const LSPAny &any) const -> DiagnosticTag;
        auto diagnosticTagToAny(DiagnosticTag param) const -> LSPAny;
        auto anyToDiagnostic_tags(const LSPAny &any) const -> Diagnostic_tags;
        auto diagnostic_tagsToAny(
            const Diagnostic_tags &array
        ) const -> LSPAny;
        auto anyToPublishDiagnosticsClientCapabilities_tagSupport(
            const LSPAny &any
        ) const -> PublishDiagnosticsClientCapabilities_tagSupport;
        auto publishDiagnosticsClientCapabilities_tagSupportToAny(
            const PublishDiagnosticsClientCapabilities_tagSupport &param
        ) const -> LSPAny;
        auto anyToPublishDiagnosticsClientCapabilities_tagSupport_valueSet(
            const LSPAny &any
        ) const -> PublishDiagnosticsClientCapabilities_tagSupport_valueSet;
        auto publishDiagnosticsClientCapabilities_tagSupport_valueSetToAny(
            const PublishDiagnosticsClientCapabilities_tagSupport_valueSet &array
        ) const -> LSPAny;
        auto anyToCompletionTriggerKind(
            const LSPAny &any
        ) const -> CompletionTriggerKind;
        auto completionTriggerKindToAny(
            CompletionTriggerKind param
        ) const -> LSPAny;
        auto anyToSignatureHelpTriggerKind(
            const LSPAny &any
        ) const -> SignatureHelpTriggerKind;
        auto signatureHelpTriggerKindToAny(
            SignatureHelpTriggerKind param
        ) const -> LSPAny;
        auto anyToCodeActionTriggerKind(
            const LSPAny &any
        ) const -> CodeActionTriggerKind;
        auto codeActionTriggerKindToAny(
            CodeActionTriggerKind param
        ) const -> LSPAny;
        auto anyToFileOperationPatternKind(
            const LSPAny &any
        ) const -> FileOperationPatternKind;
        auto fileOperationPatternKindToAny(
            FileOperationPatternKind param
        ) const -> LSPAny;
        auto anyToNotebookCellKind(
            const LSPAny &any
        ) const -> NotebookCellKind;
        auto notebookCellKindToAny(NotebookCellKind param) const -> LSPAny;
        auto anyToResourceOperationKind(
            const LSPAny &any
        ) const -> ResourceOperationKind;
        auto resourceOperationKindToAny(
            ResourceOperationKind param
        ) const -> LSPAny;
        auto anyToWorkspaceEditClientCapabilities_resourceOperations(
            const LSPAny &any
        ) const -> WorkspaceEditClientCapabilities_resourceOperations;
        auto workspaceEditClientCapabilities_resourceOperationsToAny(
            const WorkspaceEditClientCapabilities_resourceOperations &array
        ) const -> LSPAny;
        auto anyToFailureHandlingKind(
            const LSPAny &any
        ) const -> FailureHandlingKind;
        auto failureHandlingKindToAny(
            FailureHandlingKind param
        ) const -> LSPAny;
        auto anyToPrepareSupportDefaultBehavior(
            const LSPAny &any
        ) const -> PrepareSupportDefaultBehavior;
        auto prepareSupportDefaultBehaviorToAny(
            PrepareSupportDefaultBehavior param
        ) const -> LSPAny;
        auto anyToTokenFormat(const LSPAny &any) const -> TokenFormat;
        auto tokenFormatToAny(TokenFormat param) const -> LSPAny;
        auto anyToSemanticTokensClientCapabilities_formats(
            const LSPAny &any
        ) const -> SemanticTokensClientCapabilities_formats;
        auto semanticTokensClientCapabilities_formatsToAny(
            const SemanticTokensClientCapabilities_formats &array
        ) const -> LSPAny;
        auto anyToDocumentUri(const LSPAny &any) const -> DocumentUri;
        auto documentUriToAny(const DocumentUri &param) const -> LSPAny;
        auto anyToWorkspaceSymbol_location_1(
            const LSPAny &any
        ) const -> WorkspaceSymbol_location_1;
        auto workspaceSymbol_location_1ToAny(
            const WorkspaceSymbol_location_1 &param
        ) const -> LSPAny;
        auto anyToTextDocumentIdentifier(
            const LSPAny &any
        ) const -> TextDocumentIdentifier;
        auto textDocumentIdentifierToAny(
            const TextDocumentIdentifier &param
        ) const -> LSPAny;
        auto anyToDidCloseNotebookDocumentParams_cellTextDocuments(
            const LSPAny &any
        ) const -> DidCloseNotebookDocumentParams_cellTextDocuments;
        auto didCloseNotebookDocumentParams_cellTextDocumentsToAny(
            const DidCloseNotebookDocumentParams_cellTextDocuments &array
        ) const -> LSPAny;
        auto anyToDidCloseTextDocumentParams(
            const LSPAny &any
        ) const -> DidCloseTextDocumentParams;
        auto didCloseTextDocumentParamsToAny(
            const DidCloseTextDocumentParams &param
        ) const -> LSPAny;
        auto anyToWillSaveTextDocumentParams(
            const LSPAny &any
        ) const -> WillSaveTextDocumentParams;
        auto willSaveTextDocumentParamsToAny(
            const WillSaveTextDocumentParams &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentChangeEvent_cells_structure_didClose(
            const LSPAny &any
        ) const -> NotebookDocumentChangeEvent_cells_structure_didClose;
        auto notebookDocumentChangeEvent_cells_structure_didCloseToAny(
            const NotebookDocumentChangeEvent_cells_structure_didClose &array
        ) const -> LSPAny;
        auto anyToFileEvent(const LSPAny &any) const -> FileEvent;
        auto fileEventToAny(const FileEvent &param) const -> LSPAny;
        auto anyToDidChangeWatchedFilesParams(
            const LSPAny &any
        ) const -> DidChangeWatchedFilesParams;
        auto didChangeWatchedFilesParamsToAny(
            const DidChangeWatchedFilesParams &param
        ) const -> LSPAny;
        auto anyToDidChangeWatchedFilesParams_changes(
            const LSPAny &any
        ) const -> DidChangeWatchedFilesParams_changes;
        auto didChangeWatchedFilesParams_changesToAny(
            const DidChangeWatchedFilesParams_changes &array
        ) const -> LSPAny;
        auto asTextDocument_DidCloseParams(
            const MessageParams &notificationParams
        ) const -> DidCloseTextDocumentParams;
        auto asTextDocument_WillSaveParams(
            const MessageParams &notificationParams
        ) const -> WillSaveTextDocumentParams;
        auto asWorkspace_DidChangeWatchedFilesParams(
            const MessageParams &notificationParams
        ) const -> DidChangeWatchedFilesParams;
        auto anyToURI(const LSPAny &any) const -> URI;
        auto uriToAny(const URI &param) const -> LSPAny;
        auto anyToNotebookDocumentIdentifier(
            const LSPAny &any
        ) const -> NotebookDocumentIdentifier;
        auto notebookDocumentIdentifierToAny(
            const NotebookDocumentIdentifier &param
        ) const -> LSPAny;
        auto anyToDidSaveNotebookDocumentParams(
            const LSPAny &any
        ) const -> DidSaveNotebookDocumentParams;
        auto didSaveNotebookDocumentParamsToAny(
            const DidSaveNotebookDocumentParams &param
        ) const -> LSPAny;
        auto anyToDidCloseNotebookDocumentParams(
            const LSPAny &any
        ) const -> DidCloseNotebookDocumentParams;
        auto didCloseNotebookDocumentParamsToAny(
            const DidCloseNotebookDocumentParams &param
        ) const -> LSPAny;
        auto anyToCodeDescription(const LSPAny &any) const -> CodeDescription;
        auto codeDescriptionToAny(
            const CodeDescription &param
        ) const -> LSPAny;
        auto asNotebookDocument_DidSaveParams(
            const MessageParams &notificationParams
        ) const -> DidSaveNotebookDocumentParams;
        auto asNotebookDocument_DidCloseParams(
            const MessageParams &notificationParams
        ) const -> DidCloseNotebookDocumentParams;
        auto anyToString(const LSPAny &any) const -> string_t;
        auto stringToAny(const string_t &param) const -> LSPAny;
        auto anyToWorkspaceFolder(const LSPAny &any) const -> WorkspaceFolder;
        auto workspaceFolderToAny(
            const WorkspaceFolder &param
        ) const -> LSPAny;
        auto anyToMoniker(const LSPAny &any) const -> Moniker;
        auto monikerToAny(const Moniker &param) const -> LSPAny;
        auto anyToInitializeResult_serverInfo(
            const LSPAny &any
        ) const -> InitializeResult_serverInfo;
        auto initializeResult_serverInfoToAny(
            const InitializeResult_serverInfo &param
        ) const -> LSPAny;
        auto anyToDidChangeConfigurationRegistrationOptions_section(
            const LSPAny &any
        ) const -> DidChangeConfigurationRegistrationOptions_section;
        auto didChangeConfigurationRegistrationOptions_sectionToAny(
            const DidChangeConfigurationRegistrationOptions_section &param
        ) const -> LSPAny;
        auto anyToDidChangeConfigurationRegistrationOptions(
            const LSPAny &any
        ) const -> DidChangeConfigurationRegistrationOptions;
        auto didChangeConfigurationRegistrationOptionsToAny(
            const DidChangeConfigurationRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDidChangeConfigurationRegistrationOptions_section_1(
            const LSPAny &any
        ) const -> DidChangeConfigurationRegistrationOptions_section_1;
        auto didChangeConfigurationRegistrationOptions_section_1ToAny(
            const DidChangeConfigurationRegistrationOptions_section_1 &array
        ) const -> LSPAny;
        auto anyToShowMessageParams(
            const LSPAny &any
        ) const -> ShowMessageParams;
        auto showMessageParamsToAny(
            const ShowMessageParams &param
        ) const -> LSPAny;
        auto anyToMessageActionItem(
            const LSPAny &any
        ) const -> MessageActionItem;
        auto messageActionItemToAny(
            const MessageActionItem &param
        ) const -> LSPAny;
        auto anyToShowMessageRequestParams(
            const LSPAny &any
        ) const -> ShowMessageRequestParams;
        auto showMessageRequestParamsToAny(
            const ShowMessageRequestParams &param
        ) const -> LSPAny;
        auto anyToShowMessageRequestParams_actions(
            const LSPAny &any
        ) const -> ShowMessageRequestParams_actions;
        auto showMessageRequestParams_actionsToAny(
            const ShowMessageRequestParams_actions &array
        ) const -> LSPAny;
        auto anyToLogMessageParams(
            const LSPAny &any
        ) const -> LogMessageParams;
        auto logMessageParamsToAny(
            const LogMessageParams &param
        ) const -> LSPAny;
        auto anyToDidSaveTextDocumentParams(
            const LSPAny &any
        ) const -> DidSaveTextDocumentParams;
        auto didSaveTextDocumentParamsToAny(
            const DidSaveTextDocumentParams &param
        ) const -> LSPAny;
        auto anyToCompletionItem_commitCharacters(
            const LSPAny &any
        ) const -> CompletionItem_commitCharacters;
        auto completionItem_commitCharactersToAny(
            const CompletionItem_commitCharacters &array
        ) const -> LSPAny;
        auto anyToCompletionList_itemDefaults_commitCharacters(
            const LSPAny &any
        ) const -> CompletionList_itemDefaults_commitCharacters;
        auto completionList_itemDefaults_commitCharactersToAny(
            const CompletionList_itemDefaults_commitCharacters &array
        ) const -> LSPAny;
        auto anyToCodeAction_disabled(
            const LSPAny &any
        ) const -> CodeAction_disabled;
        auto codeAction_disabledToAny(
            const CodeAction_disabled &param
        ) const -> LSPAny;
        auto anyToWorkDoneProgressEnd(
            const LSPAny &any
        ) const -> WorkDoneProgressEnd;
        auto workDoneProgressEndToAny(
            const WorkDoneProgressEnd &param
        ) const -> LSPAny;
        auto anyToLogTraceParams(const LSPAny &any) const -> LogTraceParams;
        auto logTraceParamsToAny(const LogTraceParams &param) const -> LSPAny;
        auto anyToStaticRegistrationOptions(
            const LSPAny &any
        ) const -> StaticRegistrationOptions;
        auto staticRegistrationOptionsToAny(
            const StaticRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToWorkspaceFoldersChangeEvent(
            const LSPAny &any
        ) const -> WorkspaceFoldersChangeEvent;
        auto workspaceFoldersChangeEventToAny(
            const WorkspaceFoldersChangeEvent &param
        ) const -> LSPAny;
        auto anyToDidChangeWorkspaceFoldersParams(
            const LSPAny &any
        ) const -> DidChangeWorkspaceFoldersParams;
        auto didChangeWorkspaceFoldersParamsToAny(
            const DidChangeWorkspaceFoldersParams &param
        ) const -> LSPAny;
        auto anyToWorkspaceFoldersChangeEvent_added(
            const LSPAny &any
        ) const -> WorkspaceFoldersChangeEvent_added;
        auto workspaceFoldersChangeEvent_addedToAny(
            const WorkspaceFoldersChangeEvent_added &array
        ) const -> LSPAny;
        auto anyToWorkspaceFoldersChangeEvent_removed(
            const LSPAny &any
        ) const -> WorkspaceFoldersChangeEvent_removed;
        auto workspaceFoldersChangeEvent_removedToAny(
            const WorkspaceFoldersChangeEvent_removed &array
        ) const -> LSPAny;
        auto anyToConfigurationItem(
            const LSPAny &any
        ) const -> ConfigurationItem;
        auto configurationItemToAny(
            const ConfigurationItem &param
        ) const -> LSPAny;
        auto anyToConfigurationParams(
            const LSPAny &any
        ) const -> ConfigurationParams;
        auto configurationParamsToAny(
            const ConfigurationParams &param
        ) const -> LSPAny;
        auto anyToConfigurationParams_items(
            const LSPAny &any
        ) const -> ConfigurationParams_items;
        auto configurationParams_itemsToAny(
            const ConfigurationParams_items &array
        ) const -> LSPAny;
        auto anyToFileCreate(const LSPAny &any) const -> FileCreate;
        auto fileCreateToAny(const FileCreate &param) const -> LSPAny;
        auto anyToCreateFilesParams(
            const LSPAny &any
        ) const -> CreateFilesParams;
        auto createFilesParamsToAny(
            const CreateFilesParams &param
        ) const -> LSPAny;
        auto anyToCreateFilesParams_files(
            const LSPAny &any
        ) const -> CreateFilesParams_files;
        auto createFilesParams_filesToAny(
            const CreateFilesParams_files &array
        ) const -> LSPAny;
        auto anyToFileRename(const LSPAny &any) const -> FileRename;
        auto fileRenameToAny(const FileRename &param) const -> LSPAny;
        auto anyToRenameFilesParams(
            const LSPAny &any
        ) const -> RenameFilesParams;
        auto renameFilesParamsToAny(
            const RenameFilesParams &param
        ) const -> LSPAny;
        auto anyToRenameFilesParams_files(
            const LSPAny &any
        ) const -> RenameFilesParams_files;
        auto renameFilesParams_filesToAny(
            const RenameFilesParams_files &array
        ) const -> LSPAny;
        auto anyToFileDelete(const LSPAny &any) const -> FileDelete;
        auto fileDeleteToAny(const FileDelete &param) const -> LSPAny;
        auto anyToDeleteFilesParams(
            const LSPAny &any
        ) const -> DeleteFilesParams;
        auto deleteFilesParamsToAny(
            const DeleteFilesParams &param
        ) const -> LSPAny;
        auto anyToDeleteFilesParams_files(
            const LSPAny &any
        ) const -> DeleteFilesParams_files;
        auto deleteFilesParams_filesToAny(
            const DeleteFilesParams_files &array
        ) const -> LSPAny;
        auto anyToMarkupContent(const LSPAny &any) const -> MarkupContent;
        auto markupContentToAny(const MarkupContent &param) const -> LSPAny;
        auto anyToInlayHint_tooltip(
            const LSPAny &any
        ) const -> InlayHint_tooltip;
        auto inlayHint_tooltipToAny(
            const InlayHint_tooltip &param
        ) const -> LSPAny;
        auto anyToCompletionItem_documentation(
            const LSPAny &any
        ) const -> CompletionItem_documentation;
        auto completionItem_documentationToAny(
            const CompletionItem_documentation &param
        ) const -> LSPAny;
        auto anyToInlayHintLabelPart_tooltip(
            const LSPAny &any
        ) const -> InlayHintLabelPart_tooltip;
        auto inlayHintLabelPart_tooltipToAny(
            const InlayHintLabelPart_tooltip &param
        ) const -> LSPAny;
        auto anyToUnchangedDocumentDiagnosticReport(
            const LSPAny &any
        ) const -> UnchangedDocumentDiagnosticReport;
        auto unchangedDocumentDiagnosticReportToAny(
            const UnchangedDocumentDiagnosticReport &param
        ) const -> LSPAny;
        auto anyToPreviousResultId(
            const LSPAny &any
        ) const -> PreviousResultId;
        auto previousResultIdToAny(
            const PreviousResultId &param
        ) const -> LSPAny;
        auto anyToWorkspaceDiagnosticParams_previousResultIds(
            const LSPAny &any
        ) const -> WorkspaceDiagnosticParams_previousResultIds;
        auto workspaceDiagnosticParams_previousResultIdsToAny(
            const WorkspaceDiagnosticParams_previousResultIds &array
        ) const -> LSPAny;
        auto anyToStringValue(const LSPAny &any) const -> StringValue;
        auto stringValueToAny(const StringValue &param) const -> LSPAny;
        auto anyToInlineCompletionItem_insertText(
            const LSPAny &any
        ) const -> InlineCompletionItem_insertText;
        auto inlineCompletionItem_insertTextToAny(
            const InlineCompletionItem_insertText &param
        ) const -> LSPAny;
        auto anyToUnregistration(const LSPAny &any) const -> Unregistration;
        auto unregistrationToAny(const Unregistration &param) const -> LSPAny;
        auto anyToUnregistrationParams(
            const LSPAny &any
        ) const -> UnregistrationParams;
        auto unregistrationParamsToAny(
            const UnregistrationParams &param
        ) const -> LSPAny;
        auto anyToUnregistrationParams_unregisterations(
            const LSPAny &any
        ) const -> UnregistrationParams_unregisterations;
        auto unregistrationParams_unregisterationsToAny(
            const UnregistrationParams_unregisterations &array
        ) const -> LSPAny;
        auto anyTo_InitializeParams_clientInfo(
            const LSPAny &any
        ) const -> _InitializeParams_clientInfo;
        auto _InitializeParams_clientInfoToAny(
            const _InitializeParams_clientInfo &param
        ) const -> LSPAny;
        auto anyToWorkspaceFoldersInitializeParams_workspaceFolders_0(
            const LSPAny &any
        ) const -> WorkspaceFoldersInitializeParams_workspaceFolders_0;
        auto workspaceFoldersInitializeParams_workspaceFolders_0ToAny(
            const WorkspaceFoldersInitializeParams_workspaceFolders_0 &array
        ) const -> LSPAny;
        auto anyToCompletionContext(
            const LSPAny &any
        ) const -> CompletionContext;
        auto completionContextToAny(
            const CompletionContext &param
        ) const -> LSPAny;
        auto anyToCompletionItemLabelDetails(
            const LSPAny &any
        ) const -> CompletionItemLabelDetails;
        auto completionItemLabelDetailsToAny(
            const CompletionItemLabelDetails &param
        ) const -> LSPAny;
        auto anyToCompletionOptions_triggerCharacters(
            const LSPAny &any
        ) const -> CompletionOptions_triggerCharacters;
        auto completionOptions_triggerCharactersToAny(
            const CompletionOptions_triggerCharacters &array
        ) const -> LSPAny;
        auto anyToCompletionOptions_allCommitCharacters(
            const LSPAny &any
        ) const -> CompletionOptions_allCommitCharacters;
        auto completionOptions_allCommitCharactersToAny(
            const CompletionOptions_allCommitCharacters &array
        ) const -> LSPAny;
        auto anyToSignatureInformation_documentation(
            const LSPAny &any
        ) const -> SignatureInformation_documentation;
        auto signatureInformation_documentationToAny(
            const SignatureInformation_documentation &param
        ) const -> LSPAny;
        auto anyToSignatureHelpOptions_triggerCharacters(
            const LSPAny &any
        ) const -> SignatureHelpOptions_triggerCharacters;
        auto signatureHelpOptions_triggerCharactersToAny(
            const SignatureHelpOptions_triggerCharacters &array
        ) const -> LSPAny;
        auto anyToSignatureHelpOptions_retriggerCharacters(
            const LSPAny &any
        ) const -> SignatureHelpOptions_retriggerCharacters;
        auto signatureHelpOptions_retriggerCharactersToAny(
            const SignatureHelpOptions_retriggerCharacters &array
        ) const -> LSPAny;
        auto anyToBaseSymbolInformation(
            const LSPAny &any
        ) const -> BaseSymbolInformation;
        auto baseSymbolInformationToAny(
            const BaseSymbolInformation &param
        ) const -> LSPAny;
        auto anyToDocumentOnTypeFormattingOptions(
            const LSPAny &any
        ) const -> DocumentOnTypeFormattingOptions;
        auto documentOnTypeFormattingOptionsToAny(
            const DocumentOnTypeFormattingOptions &param
        ) const -> LSPAny;
        auto anyToDocumentOnTypeFormattingOptions_moreTriggerCharacter(
            const LSPAny &any
        ) const -> DocumentOnTypeFormattingOptions_moreTriggerCharacter;
        auto documentOnTypeFormattingOptions_moreTriggerCharacterToAny(
            const DocumentOnTypeFormattingOptions_moreTriggerCharacter &array
        ) const -> LSPAny;
        auto anyToExecuteCommandOptions_commands(
            const LSPAny &any
        ) const -> ExecuteCommandOptions_commands;
        auto executeCommandOptions_commandsToAny(
            const ExecuteCommandOptions_commands &array
        ) const -> LSPAny;
        auto anyToSemanticTokensLegend(
            const LSPAny &any
        ) const -> SemanticTokensLegend;
        auto semanticTokensLegendToAny(
            const SemanticTokensLegend &param
        ) const -> LSPAny;
        auto anyToSemanticTokensLegend_tokenTypes(
            const LSPAny &any
        ) const -> SemanticTokensLegend_tokenTypes;
        auto semanticTokensLegend_tokenTypesToAny(
            const SemanticTokensLegend_tokenTypes &array
        ) const -> LSPAny;
        auto anyToSemanticTokensLegend_tokenModifiers(
            const LSPAny &any
        ) const -> SemanticTokensLegend_tokenModifiers;
        auto semanticTokensLegend_tokenModifiersToAny(
            const SemanticTokensLegend_tokenModifiers &array
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector_elem_0_cells_elem(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector_elem_0_cells_elem;
        auto notebookDocumentSyncOptions_notebookSelector_elem_0_cells_elemToAny(
            const NotebookDocumentSyncOptions_notebookSelector_elem_0_cells_elem &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector_elem_0_cells(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector_elem_0_cells;
        auto notebookDocumentSyncOptions_notebookSelector_elem_0_cellsToAny(
            const NotebookDocumentSyncOptions_notebookSelector_elem_0_cells &array
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector_elem_1_cells_elem(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector_elem_1_cells_elem;
        auto notebookDocumentSyncOptions_notebookSelector_elem_1_cells_elemToAny(
            const NotebookDocumentSyncOptions_notebookSelector_elem_1_cells_elem &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector_elem_1_cells(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector_elem_1_cells;
        auto notebookDocumentSyncOptions_notebookSelector_elem_1_cellsToAny(
            const NotebookDocumentSyncOptions_notebookSelector_elem_1_cells &array
        ) const -> LSPAny;
        auto anyToParameterInformation_documentation(
            const LSPAny &any
        ) const -> ParameterInformation_documentation;
        auto parameterInformation_documentationToAny(
            const ParameterInformation_documentation &param
        ) const -> LSPAny;
        auto anyToGeneralClientCapabilities_staleRequestSupport_retryOnContentModified(
            const LSPAny &any
        ) const -> GeneralClientCapabilities_staleRequestSupport_retryOnContentModified;
        auto generalClientCapabilities_staleRequestSupport_retryOnContentModifiedToAny(
            const GeneralClientCapabilities_staleRequestSupport_retryOnContentModified &array
        ) const -> LSPAny;
        auto anyToRelativePattern_baseUri(
            const LSPAny &any
        ) const -> RelativePattern_baseUri;
        auto relativePattern_baseUriToAny(
            const RelativePattern_baseUri &param
        ) const -> LSPAny;
        auto anyToWorkspaceSymbolClientCapabilities_resolveSupport(
            const LSPAny &any
        ) const -> WorkspaceSymbolClientCapabilities_resolveSupport;
        auto workspaceSymbolClientCapabilities_resolveSupportToAny(
            const WorkspaceSymbolClientCapabilities_resolveSupport &param
        ) const -> LSPAny;
        auto anyToWorkspaceSymbolClientCapabilities_resolveSupport_properties(
            const LSPAny &any
        ) const -> WorkspaceSymbolClientCapabilities_resolveSupport_properties;
        auto workspaceSymbolClientCapabilities_resolveSupport_propertiesToAny(
            const WorkspaceSymbolClientCapabilities_resolveSupport_properties &array
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItem_resolveSupport(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItem_resolveSupport;
        auto completionClientCapabilities_completionItem_resolveSupportToAny(
            const CompletionClientCapabilities_completionItem_resolveSupport &param
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItem_resolveSupport_properties(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItem_resolveSupport_properties;
        auto completionClientCapabilities_completionItem_resolveSupport_propertiesToAny(
            const CompletionClientCapabilities_completionItem_resolveSupport_properties &array
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionList(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionList;
        auto completionClientCapabilities_completionListToAny(
            const CompletionClientCapabilities_completionList &param
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionList_itemDefaults(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionList_itemDefaults;
        auto completionClientCapabilities_completionList_itemDefaultsToAny(
            const CompletionClientCapabilities_completionList_itemDefaults &array
        ) const -> LSPAny;
        auto anyToCodeActionClientCapabilities_resolveSupport(
            const LSPAny &any
        ) const -> CodeActionClientCapabilities_resolveSupport;
        auto codeActionClientCapabilities_resolveSupportToAny(
            const CodeActionClientCapabilities_resolveSupport &param
        ) const -> LSPAny;
        auto anyToCodeActionClientCapabilities_resolveSupport_properties(
            const LSPAny &any
        ) const -> CodeActionClientCapabilities_resolveSupport_properties;
        auto codeActionClientCapabilities_resolveSupport_propertiesToAny(
            const CodeActionClientCapabilities_resolveSupport_properties &array
        ) const -> LSPAny;
        auto anyToSemanticTokensClientCapabilities_tokenTypes(
            const LSPAny &any
        ) const -> SemanticTokensClientCapabilities_tokenTypes;
        auto semanticTokensClientCapabilities_tokenTypesToAny(
            const SemanticTokensClientCapabilities_tokenTypes &array
        ) const -> LSPAny;
        auto anyToSemanticTokensClientCapabilities_tokenModifiers(
            const LSPAny &any
        ) const -> SemanticTokensClientCapabilities_tokenModifiers;
        auto semanticTokensClientCapabilities_tokenModifiersToAny(
            const SemanticTokensClientCapabilities_tokenModifiers &array
        ) const -> LSPAny;
        auto anyToInlayHintClientCapabilities_resolveSupport(
            const LSPAny &any
        ) const -> InlayHintClientCapabilities_resolveSupport;
        auto inlayHintClientCapabilities_resolveSupportToAny(
            const InlayHintClientCapabilities_resolveSupport &param
        ) const -> LSPAny;
        auto anyToInlayHintClientCapabilities_resolveSupport_properties(
            const LSPAny &any
        ) const -> InlayHintClientCapabilities_resolveSupport_properties;
        auto inlayHintClientCapabilities_resolveSupport_propertiesToAny(
            const InlayHintClientCapabilities_resolveSupport_properties &array
        ) const -> LSPAny;
        auto anyToRegularExpressionsClientCapabilities(
            const LSPAny &any
        ) const -> RegularExpressionsClientCapabilities;
        auto regularExpressionsClientCapabilitiesToAny(
            const RegularExpressionsClientCapabilities &param
        ) const -> LSPAny;
        auto anyToMarkdownClientCapabilities(
            const LSPAny &any
        ) const -> MarkdownClientCapabilities;
        auto markdownClientCapabilitiesToAny(
            const MarkdownClientCapabilities &param
        ) const -> LSPAny;
        auto anyToMarkdownClientCapabilities_allowedTags(
            const LSPAny &any
        ) const -> MarkdownClientCapabilities_allowedTags;
        auto markdownClientCapabilities_allowedTagsToAny(
            const MarkdownClientCapabilities_allowedTags &array
        ) const -> LSPAny;
        auto anyToMessage(const LSPAny &any) const -> Message;
        auto messageToAny(const Message &param) const -> LSPAny;
        auto anyToDocumentParams(const LSPAny &any) const -> DocumentParams;
        auto documentParamsToAny(const DocumentParams &param) const -> LSPAny;
        auto anyToChangeAnnotationIdentifier(
            const LSPAny &any
        ) const -> ChangeAnnotationIdentifier;
        auto changeAnnotationIdentifierToAny(
            const ChangeAnnotationIdentifier &param
        ) const -> LSPAny;
        auto anyToResourceOperation(
            const LSPAny &any
        ) const -> ResourceOperation;
        auto resourceOperationToAny(
            const ResourceOperation &param
        ) const -> LSPAny;
        auto anyToTextDocumentContentChangeEvent_1(
            const LSPAny &any
        ) const -> TextDocumentContentChangeEvent_1;
        auto textDocumentContentChangeEvent_1ToAny(
            const TextDocumentContentChangeEvent_1 &param
        ) const -> LSPAny;
        auto anyToMarkedString_1(const LSPAny &any) const -> MarkedString_1;
        auto markedString_1ToAny(const MarkedString_1 &param) const -> LSPAny;
        auto anyToMarkedString(const LSPAny &any) const -> MarkedString;
        auto markedStringToAny(const MarkedString &param) const -> LSPAny;
        auto anyToHover_contents(const LSPAny &any) const -> Hover_contents;
        auto hover_contentsToAny(const Hover_contents &param) const -> LSPAny;
        auto anyToHover_contents_2(
            const LSPAny &any
        ) const -> Hover_contents_2;
        auto hover_contents_2ToAny(
            const Hover_contents_2 &array
        ) const -> LSPAny;
        auto anyToLSPObject(const LSPAny &any) const -> LSPObject;
        auto lspObjectToAny(const LSPObject &map) const -> LSPAny;
        auto anyToTextDocumentFilter_0(
            const LSPAny &any
        ) const -> TextDocumentFilter_0;
        auto textDocumentFilter_0ToAny(
            const TextDocumentFilter_0 &param
        ) const -> LSPAny;
        auto anyToTextDocumentFilter_1(
            const LSPAny &any
        ) const -> TextDocumentFilter_1;
        auto textDocumentFilter_1ToAny(
            const TextDocumentFilter_1 &param
        ) const -> LSPAny;
        auto anyToTextDocumentFilter_2(
            const LSPAny &any
        ) const -> TextDocumentFilter_2;
        auto textDocumentFilter_2ToAny(
            const TextDocumentFilter_2 &param
        ) const -> LSPAny;
        auto anyToTextDocumentFilter(
            const LSPAny &any
        ) const -> TextDocumentFilter;
        auto textDocumentFilterToAny(
            const TextDocumentFilter &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentFilter_0(
            const LSPAny &any
        ) const -> NotebookDocumentFilter_0;
        auto notebookDocumentFilter_0ToAny(
            const NotebookDocumentFilter_0 &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentFilter_1(
            const LSPAny &any
        ) const -> NotebookDocumentFilter_1;
        auto notebookDocumentFilter_1ToAny(
            const NotebookDocumentFilter_1 &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentFilter_2(
            const LSPAny &any
        ) const -> NotebookDocumentFilter_2;
        auto notebookDocumentFilter_2ToAny(
            const NotebookDocumentFilter_2 &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentFilter(
            const LSPAny &any
        ) const -> NotebookDocumentFilter;
        auto notebookDocumentFilterToAny(
            const NotebookDocumentFilter &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector_elem_0_notebook(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector_elem_0_notebook;
        auto notebookDocumentSyncOptions_notebookSelector_elem_0_notebookToAny(
            const NotebookDocumentSyncOptions_notebookSelector_elem_0_notebook &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector_elem_0(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector_elem_0;
        auto notebookDocumentSyncOptions_notebookSelector_elem_0ToAny(
            const NotebookDocumentSyncOptions_notebookSelector_elem_0 &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector_elem_1_notebook(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector_elem_1_notebook;
        auto notebookDocumentSyncOptions_notebookSelector_elem_1_notebookToAny(
            const NotebookDocumentSyncOptions_notebookSelector_elem_1_notebook &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector_elem_1(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector_elem_1;
        auto notebookDocumentSyncOptions_notebookSelector_elem_1ToAny(
            const NotebookDocumentSyncOptions_notebookSelector_elem_1 &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector_elem(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector_elem;
        auto notebookDocumentSyncOptions_notebookSelector_elemToAny(
            const NotebookDocumentSyncOptions_notebookSelector_elem &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions_notebookSelector(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions_notebookSelector;
        auto notebookDocumentSyncOptions_notebookSelectorToAny(
            const NotebookDocumentSyncOptions_notebookSelector &array
        ) const -> LSPAny;
        auto anyToNotebookCellTextDocumentFilter_notebook(
            const LSPAny &any
        ) const -> NotebookCellTextDocumentFilter_notebook;
        auto notebookCellTextDocumentFilter_notebookToAny(
            const NotebookCellTextDocumentFilter_notebook &param
        ) const -> LSPAny;
        auto anyToNotebookCellTextDocumentFilter(
            const LSPAny &any
        ) const -> NotebookCellTextDocumentFilter;
        auto notebookCellTextDocumentFilterToAny(
            const NotebookCellTextDocumentFilter &param
        ) const -> LSPAny;
        auto anyToDocumentFilter(const LSPAny &any) const -> DocumentFilter;
        auto documentFilterToAny(const DocumentFilter &param) const -> LSPAny;
        auto anyToDocumentSelector(
            const LSPAny &any
        ) const -> DocumentSelector;
        auto documentSelectorToAny(
            const DocumentSelector &array
        ) const -> LSPAny;
        auto anyToPattern(const LSPAny &any) const -> Pattern;
        auto patternToAny(const Pattern &param) const -> LSPAny;
        auto anyToRelativePattern(const LSPAny &any) const -> RelativePattern;
        auto relativePatternToAny(
            const RelativePattern &param
        ) const -> LSPAny;
        auto anyToGlobPattern(const LSPAny &any) const -> GlobPattern;
        auto globPatternToAny(const GlobPattern &param) const -> LSPAny;
        auto anyToFileSystemWatcher(
            const LSPAny &any
        ) const -> FileSystemWatcher;
        auto fileSystemWatcherToAny(
            const FileSystemWatcher &param
        ) const -> LSPAny;
        auto anyToDidChangeWatchedFilesRegistrationOptions(
            const LSPAny &any
        ) const -> DidChangeWatchedFilesRegistrationOptions;
        auto didChangeWatchedFilesRegistrationOptionsToAny(
            const DidChangeWatchedFilesRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDidChangeWatchedFilesRegistrationOptions_watchers(
            const LSPAny &any
        ) const -> DidChangeWatchedFilesRegistrationOptions_watchers;
        auto didChangeWatchedFilesRegistrationOptions_watchersToAny(
            const DidChangeWatchedFilesRegistrationOptions_watchers &array
        ) const -> LSPAny;
        auto anyToWorkspace_WorkspaceFoldersResult_0(
            const LSPAny &any
        ) const -> Workspace_WorkspaceFoldersResult_0;
        auto workspace_WorkspaceFoldersResult_0ToAny(
            const Workspace_WorkspaceFoldersResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_MonikerResult_0(
            const LSPAny &any
        ) const -> TextDocument_MonikerResult_0;
        auto textDocument_MonikerResult_0ToAny(
            const TextDocument_MonikerResult_0 &array
        ) const -> LSPAny;
        auto asWorkspace_DidChangeWorkspaceFoldersParams(
            const MessageParams &notificationParams
        ) const -> DidChangeWorkspaceFoldersParams;
        auto asWorkspace_DidCreateFilesParams(
            const MessageParams &notificationParams
        ) const -> CreateFilesParams;
        auto asWorkspace_DidRenameFilesParams(
            const MessageParams &notificationParams
        ) const -> RenameFilesParams;
        auto asWorkspace_DidDeleteFilesParams(
            const MessageParams &notificationParams
        ) const -> DeleteFilesParams;
        auto asMessageParams(
            const ShowMessageParams &notificationParams
        ) const -> MessageParams;
        auto asMessageParams(
            const LogMessageParams &notificationParams
        ) const -> MessageParams;
        auto asTextDocument_DidSaveParams(
            const MessageParams &notificationParams
        ) const -> DidSaveTextDocumentParams;
        auto asMessageParams(
            const LogTraceParams &notificationParams
        ) const -> MessageParams;
        auto anyToBoolean(const LSPAny &any) const -> boolean_t;
        auto booleanToAny(boolean_t param) const -> LSPAny;
        auto anyToWorkDoneProgressOptions(
            const LSPAny &any
        ) const -> WorkDoneProgressOptions;
        auto workDoneProgressOptionsToAny(
            const WorkDoneProgressOptions &param
        ) const -> LSPAny;
        auto anyToShowDocumentResult(
            const LSPAny &any
        ) const -> ShowDocumentResult;
        auto showDocumentResultToAny(
            const ShowDocumentResult &param
        ) const -> LSPAny;
        auto anyToDiagnosticServerCancellationData(
            const LSPAny &any
        ) const -> DiagnosticServerCancellationData;
        auto diagnosticServerCancellationDataToAny(
            const DiagnosticServerCancellationData &param
        ) const -> LSPAny;
        auto anyToInitializeError(const LSPAny &any) const -> InitializeError;
        auto initializeErrorToAny(
            const InitializeError &param
        ) const -> LSPAny;
        auto anyToImplementationOptions(
            const LSPAny &any
        ) const -> ImplementationOptions;
        auto implementationOptionsToAny(
            const ImplementationOptions &param
        ) const -> LSPAny;
        auto anyToTypeDefinitionOptions(
            const LSPAny &any
        ) const -> TypeDefinitionOptions;
        auto typeDefinitionOptionsToAny(
            const TypeDefinitionOptions &param
        ) const -> LSPAny;
        auto anyToDocumentColorOptions(
            const LSPAny &any
        ) const -> DocumentColorOptions;
        auto documentColorOptionsToAny(
            const DocumentColorOptions &param
        ) const -> LSPAny;
        auto anyToFoldingRangeOptions(
            const LSPAny &any
        ) const -> FoldingRangeOptions;
        auto foldingRangeOptionsToAny(
            const FoldingRangeOptions &param
        ) const -> LSPAny;
        auto anyToDeclarationOptions(
            const LSPAny &any
        ) const -> DeclarationOptions;
        auto declarationOptionsToAny(
            const DeclarationOptions &param
        ) const -> LSPAny;
        auto anyToSelectionRangeOptions(
            const LSPAny &any
        ) const -> SelectionRangeOptions;
        auto selectionRangeOptionsToAny(
            const SelectionRangeOptions &param
        ) const -> LSPAny;
        auto anyToCallHierarchyOptions(
            const LSPAny &any
        ) const -> CallHierarchyOptions;
        auto callHierarchyOptionsToAny(
            const CallHierarchyOptions &param
        ) const -> LSPAny;
        auto anyToSemanticTokensOptions_full_1(
            const LSPAny &any
        ) const -> SemanticTokensOptions_full_1;
        auto semanticTokensOptions_full_1ToAny(
            const SemanticTokensOptions_full_1 &param
        ) const -> LSPAny;
        auto anyToSemanticTokensOptions_full(
            const LSPAny &any
        ) const -> SemanticTokensOptions_full;
        auto semanticTokensOptions_fullToAny(
            const SemanticTokensOptions_full &param
        ) const -> LSPAny;
        auto anyToLinkedEditingRangeOptions(
            const LSPAny &any
        ) const -> LinkedEditingRangeOptions;
        auto linkedEditingRangeOptionsToAny(
            const LinkedEditingRangeOptions &param
        ) const -> LSPAny;
        auto anyToChangeAnnotation(
            const LSPAny &any
        ) const -> ChangeAnnotation;
        auto changeAnnotationToAny(
            const ChangeAnnotation &param
        ) const -> LSPAny;
        auto anyToWorkspaceEdit_changeAnnotations(
            const LSPAny &any
        ) const -> WorkspaceEdit_changeAnnotations;
        auto workspaceEdit_changeAnnotationsToAny(
            const WorkspaceEdit_changeAnnotations &map
        ) const -> LSPAny;
        auto anyToMonikerOptions(const LSPAny &any) const -> MonikerOptions;
        auto monikerOptionsToAny(const MonikerOptions &param) const -> LSPAny;
        auto anyToTypeHierarchyOptions(
            const LSPAny &any
        ) const -> TypeHierarchyOptions;
        auto typeHierarchyOptionsToAny(
            const TypeHierarchyOptions &param
        ) const -> LSPAny;
        auto anyToInlineValueOptions(
            const LSPAny &any
        ) const -> InlineValueOptions;
        auto inlineValueOptionsToAny(
            const InlineValueOptions &param
        ) const -> LSPAny;
        auto anyToInlayHintOptions(
            const LSPAny &any
        ) const -> InlayHintOptions;
        auto inlayHintOptionsToAny(
            const InlayHintOptions &param
        ) const -> LSPAny;
        auto anyToDiagnosticOptions(
            const LSPAny &any
        ) const -> DiagnosticOptions;
        auto diagnosticOptionsToAny(
            const DiagnosticOptions &param
        ) const -> LSPAny;
        auto anyToInlineCompletionOptions(
            const LSPAny &any
        ) const -> InlineCompletionOptions;
        auto inlineCompletionOptionsToAny(
            const InlineCompletionOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_inlineCompletionProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_inlineCompletionProvider;
        auto serverCapabilities_inlineCompletionProviderToAny(
            const ServerCapabilities_inlineCompletionProvider &param
        ) const -> LSPAny;
        auto anyToSaveOptions(const LSPAny &any) const -> SaveOptions;
        auto saveOptionsToAny(const SaveOptions &param) const -> LSPAny;
        auto anyToCompletionOptions_completionItem(
            const LSPAny &any
        ) const -> CompletionOptions_completionItem;
        auto completionOptions_completionItemToAny(
            const CompletionOptions_completionItem &param
        ) const -> LSPAny;
        auto anyToCompletionOptions(
            const LSPAny &any
        ) const -> CompletionOptions;
        auto completionOptionsToAny(
            const CompletionOptions &param
        ) const -> LSPAny;
        auto anyToHoverOptions(const LSPAny &any) const -> HoverOptions;
        auto hoverOptionsToAny(const HoverOptions &param) const -> LSPAny;
        auto anyToServerCapabilities_hoverProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_hoverProvider;
        auto serverCapabilities_hoverProviderToAny(
            const ServerCapabilities_hoverProvider &param
        ) const -> LSPAny;
        auto anyToSignatureHelpOptions(
            const LSPAny &any
        ) const -> SignatureHelpOptions;
        auto signatureHelpOptionsToAny(
            const SignatureHelpOptions &param
        ) const -> LSPAny;
        auto anyToDefinitionOptions(
            const LSPAny &any
        ) const -> DefinitionOptions;
        auto definitionOptionsToAny(
            const DefinitionOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_definitionProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_definitionProvider;
        auto serverCapabilities_definitionProviderToAny(
            const ServerCapabilities_definitionProvider &param
        ) const -> LSPAny;
        auto anyToReferenceContext(
            const LSPAny &any
        ) const -> ReferenceContext;
        auto referenceContextToAny(
            const ReferenceContext &param
        ) const -> LSPAny;
        auto anyToReferenceOptions(
            const LSPAny &any
        ) const -> ReferenceOptions;
        auto referenceOptionsToAny(
            const ReferenceOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_referencesProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_referencesProvider;
        auto serverCapabilities_referencesProviderToAny(
            const ServerCapabilities_referencesProvider &param
        ) const -> LSPAny;
        auto anyToDocumentHighlightOptions(
            const LSPAny &any
        ) const -> DocumentHighlightOptions;
        auto documentHighlightOptionsToAny(
            const DocumentHighlightOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_documentHighlightProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_documentHighlightProvider;
        auto serverCapabilities_documentHighlightProviderToAny(
            const ServerCapabilities_documentHighlightProvider &param
        ) const -> LSPAny;
        auto anyToDocumentSymbolOptions(
            const LSPAny &any
        ) const -> DocumentSymbolOptions;
        auto documentSymbolOptionsToAny(
            const DocumentSymbolOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_documentSymbolProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_documentSymbolProvider;
        auto serverCapabilities_documentSymbolProviderToAny(
            const ServerCapabilities_documentSymbolProvider &param
        ) const -> LSPAny;
        auto anyToCodeActionOptions(
            const LSPAny &any
        ) const -> CodeActionOptions;
        auto codeActionOptionsToAny(
            const CodeActionOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_codeActionProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_codeActionProvider;
        auto serverCapabilities_codeActionProviderToAny(
            const ServerCapabilities_codeActionProvider &param
        ) const -> LSPAny;
        auto anyToWorkspaceSymbolOptions(
            const LSPAny &any
        ) const -> WorkspaceSymbolOptions;
        auto workspaceSymbolOptionsToAny(
            const WorkspaceSymbolOptions &param
        ) const -> LSPAny;
        auto anyToWorkspaceSymbolRegistrationOptions(
            const LSPAny &any
        ) const -> WorkspaceSymbolRegistrationOptions;
        auto workspaceSymbolRegistrationOptionsToAny(
            const WorkspaceSymbolRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_workspaceSymbolProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_workspaceSymbolProvider;
        auto serverCapabilities_workspaceSymbolProviderToAny(
            const ServerCapabilities_workspaceSymbolProvider &param
        ) const -> LSPAny;
        auto anyToCodeLensOptions(const LSPAny &any) const -> CodeLensOptions;
        auto codeLensOptionsToAny(
            const CodeLensOptions &param
        ) const -> LSPAny;
        auto anyToDocumentLinkOptions(
            const LSPAny &any
        ) const -> DocumentLinkOptions;
        auto documentLinkOptionsToAny(
            const DocumentLinkOptions &param
        ) const -> LSPAny;
        auto anyToDocumentFormattingOptions(
            const LSPAny &any
        ) const -> DocumentFormattingOptions;
        auto documentFormattingOptionsToAny(
            const DocumentFormattingOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_documentFormattingProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_documentFormattingProvider;
        auto serverCapabilities_documentFormattingProviderToAny(
            const ServerCapabilities_documentFormattingProvider &param
        ) const -> LSPAny;
        auto anyToDocumentRangeFormattingOptions(
            const LSPAny &any
        ) const -> DocumentRangeFormattingOptions;
        auto documentRangeFormattingOptionsToAny(
            const DocumentRangeFormattingOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_documentRangeFormattingProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_documentRangeFormattingProvider;
        auto serverCapabilities_documentRangeFormattingProviderToAny(
            const ServerCapabilities_documentRangeFormattingProvider &param
        ) const -> LSPAny;
        auto anyToRenameOptions(const LSPAny &any) const -> RenameOptions;
        auto renameOptionsToAny(const RenameOptions &param) const -> LSPAny;
        auto anyToServerCapabilities_renameProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_renameProvider;
        auto serverCapabilities_renameProviderToAny(
            const ServerCapabilities_renameProvider &param
        ) const -> LSPAny;
        auto anyToExecuteCommandOptions(
            const LSPAny &any
        ) const -> ExecuteCommandOptions;
        auto executeCommandOptionsToAny(
            const ExecuteCommandOptions &param
        ) const -> LSPAny;
        auto anyToExecuteCommandRegistrationOptions(
            const LSPAny &any
        ) const -> ExecuteCommandRegistrationOptions;
        auto executeCommandRegistrationOptionsToAny(
            const ExecuteCommandRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToCreateFileOptions(
            const LSPAny &any
        ) const -> CreateFileOptions;
        auto createFileOptionsToAny(
            const CreateFileOptions &param
        ) const -> LSPAny;
        auto anyToCreateFile(const LSPAny &any) const -> CreateFile;
        auto createFileToAny(const CreateFile &param) const -> LSPAny;
        auto anyToRenameFileOptions(
            const LSPAny &any
        ) const -> RenameFileOptions;
        auto renameFileOptionsToAny(
            const RenameFileOptions &param
        ) const -> LSPAny;
        auto anyToRenameFile(const LSPAny &any) const -> RenameFile;
        auto renameFileToAny(const RenameFile &param) const -> LSPAny;
        auto anyToDeleteFileOptions(
            const LSPAny &any
        ) const -> DeleteFileOptions;
        auto deleteFileOptionsToAny(
            const DeleteFileOptions &param
        ) const -> LSPAny;
        auto anyToDeleteFile(const LSPAny &any) const -> DeleteFile;
        auto deleteFileToAny(const DeleteFile &param) const -> LSPAny;
        auto anyToTextDocumentSyncOptions_save(
            const LSPAny &any
        ) const -> TextDocumentSyncOptions_save;
        auto textDocumentSyncOptions_saveToAny(
            const TextDocumentSyncOptions_save &param
        ) const -> LSPAny;
        auto anyToTextDocumentSyncOptions(
            const LSPAny &any
        ) const -> TextDocumentSyncOptions;
        auto textDocumentSyncOptionsToAny(
            const TextDocumentSyncOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_textDocumentSync(
            const LSPAny &any
        ) const -> ServerCapabilities_textDocumentSync;
        auto serverCapabilities_textDocumentSyncToAny(
            const ServerCapabilities_textDocumentSync &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncOptions(
            const LSPAny &any
        ) const -> NotebookDocumentSyncOptions;
        auto notebookDocumentSyncOptionsToAny(
            const NotebookDocumentSyncOptions &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncRegistrationOptions(
            const LSPAny &any
        ) const -> NotebookDocumentSyncRegistrationOptions;
        auto notebookDocumentSyncRegistrationOptionsToAny(
            const NotebookDocumentSyncRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_notebookDocumentSync(
            const LSPAny &any
        ) const -> ServerCapabilities_notebookDocumentSync;
        auto serverCapabilities_notebookDocumentSyncToAny(
            const ServerCapabilities_notebookDocumentSync &param
        ) const -> LSPAny;
        auto anyToWorkspaceFoldersServerCapabilities_changeNotifications(
            const LSPAny &any
        ) const -> WorkspaceFoldersServerCapabilities_changeNotifications;
        auto workspaceFoldersServerCapabilities_changeNotificationsToAny(
            const WorkspaceFoldersServerCapabilities_changeNotifications &param
        ) const -> LSPAny;
        auto anyToWorkspaceFoldersServerCapabilities(
            const LSPAny &any
        ) const -> WorkspaceFoldersServerCapabilities;
        auto workspaceFoldersServerCapabilitiesToAny(
            const WorkspaceFoldersServerCapabilities &param
        ) const -> LSPAny;
        auto anyToFileOperationPatternOptions(
            const LSPAny &any
        ) const -> FileOperationPatternOptions;
        auto fileOperationPatternOptionsToAny(
            const FileOperationPatternOptions &param
        ) const -> LSPAny;
        auto anyToFileOperationPattern(
            const LSPAny &any
        ) const -> FileOperationPattern;
        auto fileOperationPatternToAny(
            const FileOperationPattern &param
        ) const -> LSPAny;
        auto anyToFileOperationFilter(
            const LSPAny &any
        ) const -> FileOperationFilter;
        auto fileOperationFilterToAny(
            const FileOperationFilter &param
        ) const -> LSPAny;
        auto anyToFileOperationRegistrationOptions(
            const LSPAny &any
        ) const -> FileOperationRegistrationOptions;
        auto fileOperationRegistrationOptionsToAny(
            const FileOperationRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToFileOperationRegistrationOptions_filters(
            const LSPAny &any
        ) const -> FileOperationRegistrationOptions_filters;
        auto fileOperationRegistrationOptions_filtersToAny(
            const FileOperationRegistrationOptions_filters &array
        ) const -> LSPAny;
        auto anyToFileOperationOptions(
            const LSPAny &any
        ) const -> FileOperationOptions;
        auto fileOperationOptionsToAny(
            const FileOperationOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_workspace(
            const LSPAny &any
        ) const -> ServerCapabilities_workspace;
        auto serverCapabilities_workspaceToAny(
            const ServerCapabilities_workspace &param
        ) const -> LSPAny;
        auto anyToGeneralClientCapabilities_staleRequestSupport(
            const LSPAny &any
        ) const -> GeneralClientCapabilities_staleRequestSupport;
        auto generalClientCapabilities_staleRequestSupportToAny(
            const GeneralClientCapabilities_staleRequestSupport &param
        ) const -> LSPAny;
        auto anyToGeneralClientCapabilities(
            const LSPAny &any
        ) const -> GeneralClientCapabilities;
        auto generalClientCapabilitiesToAny(
            const GeneralClientCapabilities &param
        ) const -> LSPAny;
        auto anyToWorkspaceEditClientCapabilities_changeAnnotationSupport(
            const LSPAny &any
        ) const -> WorkspaceEditClientCapabilities_changeAnnotationSupport;
        auto workspaceEditClientCapabilities_changeAnnotationSupportToAny(
            const WorkspaceEditClientCapabilities_changeAnnotationSupport &param
        ) const -> LSPAny;
        auto anyToWorkspaceEditClientCapabilities(
            const LSPAny &any
        ) const -> WorkspaceEditClientCapabilities;
        auto workspaceEditClientCapabilitiesToAny(
            const WorkspaceEditClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDidChangeConfigurationClientCapabilities(
            const LSPAny &any
        ) const -> DidChangeConfigurationClientCapabilities;
        auto didChangeConfigurationClientCapabilitiesToAny(
            const DidChangeConfigurationClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDidChangeWatchedFilesClientCapabilities(
            const LSPAny &any
        ) const -> DidChangeWatchedFilesClientCapabilities;
        auto didChangeWatchedFilesClientCapabilitiesToAny(
            const DidChangeWatchedFilesClientCapabilities &param
        ) const -> LSPAny;
        auto anyToWorkspaceSymbolClientCapabilities(
            const LSPAny &any
        ) const -> WorkspaceSymbolClientCapabilities;
        auto workspaceSymbolClientCapabilitiesToAny(
            const WorkspaceSymbolClientCapabilities &param
        ) const -> LSPAny;
        auto anyToExecuteCommandClientCapabilities(
            const LSPAny &any
        ) const -> ExecuteCommandClientCapabilities;
        auto executeCommandClientCapabilitiesToAny(
            const ExecuteCommandClientCapabilities &param
        ) const -> LSPAny;
        auto anyToSemanticTokensWorkspaceClientCapabilities(
            const LSPAny &any
        ) const -> SemanticTokensWorkspaceClientCapabilities;
        auto semanticTokensWorkspaceClientCapabilitiesToAny(
            const SemanticTokensWorkspaceClientCapabilities &param
        ) const -> LSPAny;
        auto anyToCodeLensWorkspaceClientCapabilities(
            const LSPAny &any
        ) const -> CodeLensWorkspaceClientCapabilities;
        auto codeLensWorkspaceClientCapabilitiesToAny(
            const CodeLensWorkspaceClientCapabilities &param
        ) const -> LSPAny;
        auto anyToFileOperationClientCapabilities(
            const LSPAny &any
        ) const -> FileOperationClientCapabilities;
        auto fileOperationClientCapabilitiesToAny(
            const FileOperationClientCapabilities &param
        ) const -> LSPAny;
        auto anyToInlineValueWorkspaceClientCapabilities(
            const LSPAny &any
        ) const -> InlineValueWorkspaceClientCapabilities;
        auto inlineValueWorkspaceClientCapabilitiesToAny(
            const InlineValueWorkspaceClientCapabilities &param
        ) const -> LSPAny;
        auto anyToInlayHintWorkspaceClientCapabilities(
            const LSPAny &any
        ) const -> InlayHintWorkspaceClientCapabilities;
        auto inlayHintWorkspaceClientCapabilitiesToAny(
            const InlayHintWorkspaceClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDiagnosticWorkspaceClientCapabilities(
            const LSPAny &any
        ) const -> DiagnosticWorkspaceClientCapabilities;
        auto diagnosticWorkspaceClientCapabilitiesToAny(
            const DiagnosticWorkspaceClientCapabilities &param
        ) const -> LSPAny;
        auto anyToFoldingRangeWorkspaceClientCapabilities(
            const LSPAny &any
        ) const -> FoldingRangeWorkspaceClientCapabilities;
        auto foldingRangeWorkspaceClientCapabilitiesToAny(
            const FoldingRangeWorkspaceClientCapabilities &param
        ) const -> LSPAny;
        auto anyToWorkspaceClientCapabilities(
            const LSPAny &any
        ) const -> WorkspaceClientCapabilities;
        auto workspaceClientCapabilitiesToAny(
            const WorkspaceClientCapabilities &param
        ) const -> LSPAny;
        auto anyToTextDocumentSyncClientCapabilities(
            const LSPAny &any
        ) const -> TextDocumentSyncClientCapabilities;
        auto textDocumentSyncClientCapabilitiesToAny(
            const TextDocumentSyncClientCapabilities &param
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities_completionItem(
            const LSPAny &any
        ) const -> CompletionClientCapabilities_completionItem;
        auto completionClientCapabilities_completionItemToAny(
            const CompletionClientCapabilities_completionItem &param
        ) const -> LSPAny;
        auto anyToCompletionClientCapabilities(
            const LSPAny &any
        ) const -> CompletionClientCapabilities;
        auto completionClientCapabilitiesToAny(
            const CompletionClientCapabilities &param
        ) const -> LSPAny;
        auto anyToHoverClientCapabilities(
            const LSPAny &any
        ) const -> HoverClientCapabilities;
        auto hoverClientCapabilitiesToAny(
            const HoverClientCapabilities &param
        ) const -> LSPAny;
        auto anyToSignatureHelpClientCapabilities_signatureInformation_parameterInformation(
            const LSPAny &any
        ) const -> SignatureHelpClientCapabilities_signatureInformation_parameterInformation;
        auto signatureHelpClientCapabilities_signatureInformation_parameterInformationToAny(
            const SignatureHelpClientCapabilities_signatureInformation_parameterInformation &param
        ) const -> LSPAny;
        auto anyToSignatureHelpClientCapabilities_signatureInformation(
            const LSPAny &any
        ) const -> SignatureHelpClientCapabilities_signatureInformation;
        auto signatureHelpClientCapabilities_signatureInformationToAny(
            const SignatureHelpClientCapabilities_signatureInformation &param
        ) const -> LSPAny;
        auto anyToSignatureHelpClientCapabilities(
            const LSPAny &any
        ) const -> SignatureHelpClientCapabilities;
        auto signatureHelpClientCapabilitiesToAny(
            const SignatureHelpClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDeclarationClientCapabilities(
            const LSPAny &any
        ) const -> DeclarationClientCapabilities;
        auto declarationClientCapabilitiesToAny(
            const DeclarationClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDefinitionClientCapabilities(
            const LSPAny &any
        ) const -> DefinitionClientCapabilities;
        auto definitionClientCapabilitiesToAny(
            const DefinitionClientCapabilities &param
        ) const -> LSPAny;
        auto anyToTypeDefinitionClientCapabilities(
            const LSPAny &any
        ) const -> TypeDefinitionClientCapabilities;
        auto typeDefinitionClientCapabilitiesToAny(
            const TypeDefinitionClientCapabilities &param
        ) const -> LSPAny;
        auto anyToImplementationClientCapabilities(
            const LSPAny &any
        ) const -> ImplementationClientCapabilities;
        auto implementationClientCapabilitiesToAny(
            const ImplementationClientCapabilities &param
        ) const -> LSPAny;
        auto anyToReferenceClientCapabilities(
            const LSPAny &any
        ) const -> ReferenceClientCapabilities;
        auto referenceClientCapabilitiesToAny(
            const ReferenceClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDocumentHighlightClientCapabilities(
            const LSPAny &any
        ) const -> DocumentHighlightClientCapabilities;
        auto documentHighlightClientCapabilitiesToAny(
            const DocumentHighlightClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDocumentSymbolClientCapabilities(
            const LSPAny &any
        ) const -> DocumentSymbolClientCapabilities;
        auto documentSymbolClientCapabilitiesToAny(
            const DocumentSymbolClientCapabilities &param
        ) const -> LSPAny;
        auto anyToCodeActionClientCapabilities(
            const LSPAny &any
        ) const -> CodeActionClientCapabilities;
        auto codeActionClientCapabilitiesToAny(
            const CodeActionClientCapabilities &param
        ) const -> LSPAny;
        auto anyToCodeLensClientCapabilities(
            const LSPAny &any
        ) const -> CodeLensClientCapabilities;
        auto codeLensClientCapabilitiesToAny(
            const CodeLensClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDocumentLinkClientCapabilities(
            const LSPAny &any
        ) const -> DocumentLinkClientCapabilities;
        auto documentLinkClientCapabilitiesToAny(
            const DocumentLinkClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDocumentColorClientCapabilities(
            const LSPAny &any
        ) const -> DocumentColorClientCapabilities;
        auto documentColorClientCapabilitiesToAny(
            const DocumentColorClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDocumentFormattingClientCapabilities(
            const LSPAny &any
        ) const -> DocumentFormattingClientCapabilities;
        auto documentFormattingClientCapabilitiesToAny(
            const DocumentFormattingClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDocumentRangeFormattingClientCapabilities(
            const LSPAny &any
        ) const -> DocumentRangeFormattingClientCapabilities;
        auto documentRangeFormattingClientCapabilitiesToAny(
            const DocumentRangeFormattingClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDocumentOnTypeFormattingClientCapabilities(
            const LSPAny &any
        ) const -> DocumentOnTypeFormattingClientCapabilities;
        auto documentOnTypeFormattingClientCapabilitiesToAny(
            const DocumentOnTypeFormattingClientCapabilities &param
        ) const -> LSPAny;
        auto anyToRenameClientCapabilities(
            const LSPAny &any
        ) const -> RenameClientCapabilities;
        auto renameClientCapabilitiesToAny(
            const RenameClientCapabilities &param
        ) const -> LSPAny;
        auto anyToFoldingRangeClientCapabilities_foldingRange(
            const LSPAny &any
        ) const -> FoldingRangeClientCapabilities_foldingRange;
        auto foldingRangeClientCapabilities_foldingRangeToAny(
            const FoldingRangeClientCapabilities_foldingRange &param
        ) const -> LSPAny;
        auto anyToSelectionRangeClientCapabilities(
            const LSPAny &any
        ) const -> SelectionRangeClientCapabilities;
        auto selectionRangeClientCapabilitiesToAny(
            const SelectionRangeClientCapabilities &param
        ) const -> LSPAny;
        auto anyToPublishDiagnosticsClientCapabilities(
            const LSPAny &any
        ) const -> PublishDiagnosticsClientCapabilities;
        auto publishDiagnosticsClientCapabilitiesToAny(
            const PublishDiagnosticsClientCapabilities &param
        ) const -> LSPAny;
        auto anyToCallHierarchyClientCapabilities(
            const LSPAny &any
        ) const -> CallHierarchyClientCapabilities;
        auto callHierarchyClientCapabilitiesToAny(
            const CallHierarchyClientCapabilities &param
        ) const -> LSPAny;
        auto anyToSemanticTokensClientCapabilities_requests_full_1(
            const LSPAny &any
        ) const -> SemanticTokensClientCapabilities_requests_full_1;
        auto semanticTokensClientCapabilities_requests_full_1ToAny(
            const SemanticTokensClientCapabilities_requests_full_1 &param
        ) const -> LSPAny;
        auto anyToSemanticTokensClientCapabilities_requests_full(
            const LSPAny &any
        ) const -> SemanticTokensClientCapabilities_requests_full;
        auto semanticTokensClientCapabilities_requests_fullToAny(
            const SemanticTokensClientCapabilities_requests_full &param
        ) const -> LSPAny;
        auto anyToLinkedEditingRangeClientCapabilities(
            const LSPAny &any
        ) const -> LinkedEditingRangeClientCapabilities;
        auto linkedEditingRangeClientCapabilitiesToAny(
            const LinkedEditingRangeClientCapabilities &param
        ) const -> LSPAny;
        auto anyToMonikerClientCapabilities(
            const LSPAny &any
        ) const -> MonikerClientCapabilities;
        auto monikerClientCapabilitiesToAny(
            const MonikerClientCapabilities &param
        ) const -> LSPAny;
        auto anyToTypeHierarchyClientCapabilities(
            const LSPAny &any
        ) const -> TypeHierarchyClientCapabilities;
        auto typeHierarchyClientCapabilitiesToAny(
            const TypeHierarchyClientCapabilities &param
        ) const -> LSPAny;
        auto anyToInlineValueClientCapabilities(
            const LSPAny &any
        ) const -> InlineValueClientCapabilities;
        auto inlineValueClientCapabilitiesToAny(
            const InlineValueClientCapabilities &param
        ) const -> LSPAny;
        auto anyToInlayHintClientCapabilities(
            const LSPAny &any
        ) const -> InlayHintClientCapabilities;
        auto inlayHintClientCapabilitiesToAny(
            const InlayHintClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDiagnosticClientCapabilities(
            const LSPAny &any
        ) const -> DiagnosticClientCapabilities;
        auto diagnosticClientCapabilitiesToAny(
            const DiagnosticClientCapabilities &param
        ) const -> LSPAny;
        auto anyToInlineCompletionClientCapabilities(
            const LSPAny &any
        ) const -> InlineCompletionClientCapabilities;
        auto inlineCompletionClientCapabilitiesToAny(
            const InlineCompletionClientCapabilities &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentSyncClientCapabilities(
            const LSPAny &any
        ) const -> NotebookDocumentSyncClientCapabilities;
        auto notebookDocumentSyncClientCapabilitiesToAny(
            const NotebookDocumentSyncClientCapabilities &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentClientCapabilities(
            const LSPAny &any
        ) const -> NotebookDocumentClientCapabilities;
        auto notebookDocumentClientCapabilitiesToAny(
            const NotebookDocumentClientCapabilities &param
        ) const -> LSPAny;
        auto anyToShowMessageRequestClientCapabilities_messageActionItem(
            const LSPAny &any
        ) const -> ShowMessageRequestClientCapabilities_messageActionItem;
        auto showMessageRequestClientCapabilities_messageActionItemToAny(
            const ShowMessageRequestClientCapabilities_messageActionItem &param
        ) const -> LSPAny;
        auto anyToShowMessageRequestClientCapabilities(
            const LSPAny &any
        ) const -> ShowMessageRequestClientCapabilities;
        auto showMessageRequestClientCapabilitiesToAny(
            const ShowMessageRequestClientCapabilities &param
        ) const -> LSPAny;
        auto anyToShowDocumentClientCapabilities(
            const LSPAny &any
        ) const -> ShowDocumentClientCapabilities;
        auto showDocumentClientCapabilitiesToAny(
            const ShowDocumentClientCapabilities &param
        ) const -> LSPAny;
        auto anyToWindowClientCapabilities(
            const LSPAny &any
        ) const -> WindowClientCapabilities;
        auto windowClientCapabilitiesToAny(
            const WindowClientCapabilities &param
        ) const -> LSPAny;
        auto anyToPrepareRenameResult_2(
            const LSPAny &any
        ) const -> PrepareRenameResult_2;
        auto prepareRenameResult_2ToAny(
            const PrepareRenameResult_2 &param
        ) const -> LSPAny;
        auto anyToWindow_ShowDocumentResult(
            const LSPAny &any
        ) const -> Window_ShowDocumentResult;
        auto window_ShowDocumentResultToAny(
            const Window_ShowDocumentResult &param
        ) const -> LSPAny;
        auto anyToNull(const LSPAny &any) const -> null_t;
        auto nullToAny(null_t param) const -> LSPAny;
        auto anyToTextDocumentRegistrationOptions_documentSelector(
            const LSPAny &any
        ) const -> TextDocumentRegistrationOptions_documentSelector;
        auto textDocumentRegistrationOptions_documentSelectorToAny(
            const TextDocumentRegistrationOptions_documentSelector &param
        ) const -> LSPAny;
        auto anyToTextDocumentRegistrationOptions(
            const LSPAny &any
        ) const -> TextDocumentRegistrationOptions;
        auto textDocumentRegistrationOptionsToAny(
            const TextDocumentRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToImplementationRegistrationOptions(
            const LSPAny &any
        ) const -> ImplementationRegistrationOptions;
        auto implementationRegistrationOptionsToAny(
            const ImplementationRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToTypeDefinitionRegistrationOptions(
            const LSPAny &any
        ) const -> TypeDefinitionRegistrationOptions;
        auto typeDefinitionRegistrationOptionsToAny(
            const TypeDefinitionRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDocumentColorRegistrationOptions(
            const LSPAny &any
        ) const -> DocumentColorRegistrationOptions;
        auto documentColorRegistrationOptionsToAny(
            const DocumentColorRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToFoldingRangeRegistrationOptions(
            const LSPAny &any
        ) const -> FoldingRangeRegistrationOptions;
        auto foldingRangeRegistrationOptionsToAny(
            const FoldingRangeRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDeclarationRegistrationOptions(
            const LSPAny &any
        ) const -> DeclarationRegistrationOptions;
        auto declarationRegistrationOptionsToAny(
            const DeclarationRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToSelectionRangeRegistrationOptions(
            const LSPAny &any
        ) const -> SelectionRangeRegistrationOptions;
        auto selectionRangeRegistrationOptionsToAny(
            const SelectionRangeRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToCallHierarchyRegistrationOptions(
            const LSPAny &any
        ) const -> CallHierarchyRegistrationOptions;
        auto callHierarchyRegistrationOptionsToAny(
            const CallHierarchyRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToLinkedEditingRangeRegistrationOptions(
            const LSPAny &any
        ) const -> LinkedEditingRangeRegistrationOptions;
        auto linkedEditingRangeRegistrationOptionsToAny(
            const LinkedEditingRangeRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToMonikerRegistrationOptions(
            const LSPAny &any
        ) const -> MonikerRegistrationOptions;
        auto monikerRegistrationOptionsToAny(
            const MonikerRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToTypeHierarchyRegistrationOptions(
            const LSPAny &any
        ) const -> TypeHierarchyRegistrationOptions;
        auto typeHierarchyRegistrationOptionsToAny(
            const TypeHierarchyRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToInlineValueRegistrationOptions(
            const LSPAny &any
        ) const -> InlineValueRegistrationOptions;
        auto inlineValueRegistrationOptionsToAny(
            const InlineValueRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToInlayHintRegistrationOptions(
            const LSPAny &any
        ) const -> InlayHintRegistrationOptions;
        auto inlayHintRegistrationOptionsToAny(
            const InlayHintRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDiagnosticRegistrationOptions(
            const LSPAny &any
        ) const -> DiagnosticRegistrationOptions;
        auto diagnosticRegistrationOptionsToAny(
            const DiagnosticRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToInlineCompletionRegistrationOptions(
            const LSPAny &any
        ) const -> InlineCompletionRegistrationOptions;
        auto inlineCompletionRegistrationOptionsToAny(
            const InlineCompletionRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToTextDocumentChangeRegistrationOptions(
            const LSPAny &any
        ) const -> TextDocumentChangeRegistrationOptions;
        auto textDocumentChangeRegistrationOptionsToAny(
            const TextDocumentChangeRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToTextDocumentSaveRegistrationOptions(
            const LSPAny &any
        ) const -> TextDocumentSaveRegistrationOptions;
        auto textDocumentSaveRegistrationOptionsToAny(
            const TextDocumentSaveRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToCompletionRegistrationOptions(
            const LSPAny &any
        ) const -> CompletionRegistrationOptions;
        auto completionRegistrationOptionsToAny(
            const CompletionRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToHoverRegistrationOptions(
            const LSPAny &any
        ) const -> HoverRegistrationOptions;
        auto hoverRegistrationOptionsToAny(
            const HoverRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToSignatureHelpRegistrationOptions(
            const LSPAny &any
        ) const -> SignatureHelpRegistrationOptions;
        auto signatureHelpRegistrationOptionsToAny(
            const SignatureHelpRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDefinitionRegistrationOptions(
            const LSPAny &any
        ) const -> DefinitionRegistrationOptions;
        auto definitionRegistrationOptionsToAny(
            const DefinitionRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToReferenceRegistrationOptions(
            const LSPAny &any
        ) const -> ReferenceRegistrationOptions;
        auto referenceRegistrationOptionsToAny(
            const ReferenceRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDocumentHighlightRegistrationOptions(
            const LSPAny &any
        ) const -> DocumentHighlightRegistrationOptions;
        auto documentHighlightRegistrationOptionsToAny(
            const DocumentHighlightRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDocumentSymbolRegistrationOptions(
            const LSPAny &any
        ) const -> DocumentSymbolRegistrationOptions;
        auto documentSymbolRegistrationOptionsToAny(
            const DocumentSymbolRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToCodeActionRegistrationOptions(
            const LSPAny &any
        ) const -> CodeActionRegistrationOptions;
        auto codeActionRegistrationOptionsToAny(
            const CodeActionRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToCodeLensRegistrationOptions(
            const LSPAny &any
        ) const -> CodeLensRegistrationOptions;
        auto codeLensRegistrationOptionsToAny(
            const CodeLensRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDocumentLinkRegistrationOptions(
            const LSPAny &any
        ) const -> DocumentLinkRegistrationOptions;
        auto documentLinkRegistrationOptionsToAny(
            const DocumentLinkRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDocumentFormattingRegistrationOptions(
            const LSPAny &any
        ) const -> DocumentFormattingRegistrationOptions;
        auto documentFormattingRegistrationOptionsToAny(
            const DocumentFormattingRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDocumentRangeFormattingRegistrationOptions(
            const LSPAny &any
        ) const -> DocumentRangeFormattingRegistrationOptions;
        auto documentRangeFormattingRegistrationOptionsToAny(
            const DocumentRangeFormattingRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToDocumentOnTypeFormattingRegistrationOptions(
            const LSPAny &any
        ) const -> DocumentOnTypeFormattingRegistrationOptions;
        auto documentOnTypeFormattingRegistrationOptionsToAny(
            const DocumentOnTypeFormattingRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToRenameRegistrationOptions(
            const LSPAny &any
        ) const -> RenameRegistrationOptions;
        auto renameRegistrationOptionsToAny(
            const RenameRegistrationOptions &param
        ) const -> LSPAny;
        auto anyTo_InitializeParams_rootPath(
            const LSPAny &any
        ) const -> _InitializeParams_rootPath;
        auto _InitializeParams_rootPathToAny(
            const _InitializeParams_rootPath &param
        ) const -> LSPAny;
        auto anyTo_InitializeParams_rootUri(
            const LSPAny &any
        ) const -> _InitializeParams_rootUri;
        auto _InitializeParams_rootUriToAny(
            const _InitializeParams_rootUri &param
        ) const -> LSPAny;
        auto anyToWorkspaceFoldersInitializeParams_workspaceFolders(
            const LSPAny &any
        ) const -> WorkspaceFoldersInitializeParams_workspaceFolders;
        auto workspaceFoldersInitializeParams_workspaceFoldersToAny(
            const WorkspaceFoldersInitializeParams_workspaceFolders &param
        ) const -> LSPAny;
        auto anyToWorkspaceFoldersInitializeParams(
            const LSPAny &any
        ) const -> WorkspaceFoldersInitializeParams;
        auto workspaceFoldersInitializeParamsToAny(
            const WorkspaceFoldersInitializeParams &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_declarationProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_declarationProvider;
        auto serverCapabilities_declarationProviderToAny(
            const ServerCapabilities_declarationProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_typeDefinitionProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_typeDefinitionProvider;
        auto serverCapabilities_typeDefinitionProviderToAny(
            const ServerCapabilities_typeDefinitionProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_implementationProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_implementationProvider;
        auto serverCapabilities_implementationProviderToAny(
            const ServerCapabilities_implementationProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_colorProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_colorProvider;
        auto serverCapabilities_colorProviderToAny(
            const ServerCapabilities_colorProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_foldingRangeProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_foldingRangeProvider;
        auto serverCapabilities_foldingRangeProviderToAny(
            const ServerCapabilities_foldingRangeProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_selectionRangeProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_selectionRangeProvider;
        auto serverCapabilities_selectionRangeProviderToAny(
            const ServerCapabilities_selectionRangeProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_callHierarchyProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_callHierarchyProvider;
        auto serverCapabilities_callHierarchyProviderToAny(
            const ServerCapabilities_callHierarchyProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_linkedEditingRangeProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_linkedEditingRangeProvider;
        auto serverCapabilities_linkedEditingRangeProviderToAny(
            const ServerCapabilities_linkedEditingRangeProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_monikerProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_monikerProvider;
        auto serverCapabilities_monikerProviderToAny(
            const ServerCapabilities_monikerProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_typeHierarchyProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_typeHierarchyProvider;
        auto serverCapabilities_typeHierarchyProviderToAny(
            const ServerCapabilities_typeHierarchyProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_inlineValueProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_inlineValueProvider;
        auto serverCapabilities_inlineValueProviderToAny(
            const ServerCapabilities_inlineValueProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_inlayHintProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_inlayHintProvider;
        auto serverCapabilities_inlayHintProviderToAny(
            const ServerCapabilities_inlayHintProvider &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_diagnosticProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_diagnosticProvider;
        auto serverCapabilities_diagnosticProviderToAny(
            const ServerCapabilities_diagnosticProvider &param
        ) const -> LSPAny;
        auto anyToWorkspace_WorkspaceFoldersResult(
            const LSPAny &any
        ) const -> Workspace_WorkspaceFoldersResult;
        auto workspace_WorkspaceFoldersResultToAny(
            const Workspace_WorkspaceFoldersResult &param
        ) const -> LSPAny;
        auto anyToWorkspace_FoldingRange_RefreshResult(
            const LSPAny &any
        ) const -> Workspace_FoldingRange_RefreshResult;
        auto workspace_FoldingRange_RefreshResultToAny(
            const Workspace_FoldingRange_RefreshResult &param
        ) const -> LSPAny;
        auto anyToWindow_WorkDoneProgress_CreateResult(
            const LSPAny &any
        ) const -> Window_WorkDoneProgress_CreateResult;
        auto window_WorkDoneProgress_CreateResultToAny(
            const Window_WorkDoneProgress_CreateResult &param
        ) const -> LSPAny;
        auto anyToWorkspace_SemanticTokens_RefreshResult(
            const LSPAny &any
        ) const -> Workspace_SemanticTokens_RefreshResult;
        auto workspace_SemanticTokens_RefreshResultToAny(
            const Workspace_SemanticTokens_RefreshResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_MonikerResult(
            const LSPAny &any
        ) const -> TextDocument_MonikerResult;
        auto textDocument_MonikerResultToAny(
            const TextDocument_MonikerResult &param
        ) const -> LSPAny;
        auto anyToWorkspace_InlineValue_RefreshResult(
            const LSPAny &any
        ) const -> Workspace_InlineValue_RefreshResult;
        auto workspace_InlineValue_RefreshResultToAny(
            const Workspace_InlineValue_RefreshResult &param
        ) const -> LSPAny;
        auto anyToWorkspace_InlayHint_RefreshResult(
            const LSPAny &any
        ) const -> Workspace_InlayHint_RefreshResult;
        auto workspace_InlayHint_RefreshResultToAny(
            const Workspace_InlayHint_RefreshResult &param
        ) const -> LSPAny;
        auto anyToWorkspace_Diagnostic_RefreshResult(
            const LSPAny &any
        ) const -> Workspace_Diagnostic_RefreshResult;
        auto workspace_Diagnostic_RefreshResultToAny(
            const Workspace_Diagnostic_RefreshResult &param
        ) const -> LSPAny;
        auto anyToClient_RegisterCapabilityResult(
            const LSPAny &any
        ) const -> Client_RegisterCapabilityResult;
        auto client_RegisterCapabilityResultToAny(
            const Client_RegisterCapabilityResult &param
        ) const -> LSPAny;
        auto anyToClient_UnregisterCapabilityResult(
            const LSPAny &any
        ) const -> Client_UnregisterCapabilityResult;
        auto client_UnregisterCapabilityResultToAny(
            const Client_UnregisterCapabilityResult &param
        ) const -> LSPAny;
        auto asMessageParams(
            const UnregistrationParams &requestParams
        ) const -> MessageParams;
        auto anyToShutdownResult(const LSPAny &any) const -> ShutdownResult;
        auto shutdownResultToAny(const ShutdownResult &param) const -> LSPAny;
        auto anyToWindow_ShowMessageRequestResult(
            const LSPAny &any
        ) const -> Window_ShowMessageRequestResult;
        auto window_ShowMessageRequestResultToAny(
            const Window_ShowMessageRequestResult &param
        ) const -> LSPAny;
        auto asMessageParams(
            const ShowMessageRequestParams &requestParams
        ) const -> MessageParams;
        auto anyToWorkspace_CodeLens_RefreshResult(
            const LSPAny &any
        ) const -> Workspace_CodeLens_RefreshResult;
        auto workspace_CodeLens_RefreshResultToAny(
            const Workspace_CodeLens_RefreshResult &param
        ) const -> LSPAny;
        auto anyToUInteger(const LSPAny &any) const -> uinteger_t;
        auto uintegerToAny(uinteger_t param) const -> LSPAny;
        auto anyToFoldingRange(const LSPAny &any) const -> FoldingRange;
        auto foldingRangeToAny(const FoldingRange &param) const -> LSPAny;
        auto anyToSemanticTokens(const LSPAny &any) const -> SemanticTokens;
        auto semanticTokensToAny(const SemanticTokens &param) const -> LSPAny;
        auto anyToSemanticTokens_data(
            const LSPAny &any
        ) const -> SemanticTokens_data;
        auto semanticTokens_dataToAny(
            const SemanticTokens_data &array
        ) const -> LSPAny;
        auto anyToSemanticTokensPartialResult(
            const LSPAny &any
        ) const -> SemanticTokensPartialResult;
        auto semanticTokensPartialResultToAny(
            const SemanticTokensPartialResult &param
        ) const -> LSPAny;
        auto anyToSemanticTokensPartialResult_data(
            const LSPAny &any
        ) const -> SemanticTokensPartialResult_data;
        auto semanticTokensPartialResult_dataToAny(
            const SemanticTokensPartialResult_data &array
        ) const -> LSPAny;
        auto anyToApplyWorkspaceEditResult(
            const LSPAny &any
        ) const -> ApplyWorkspaceEditResult;
        auto applyWorkspaceEditResultToAny(
            const ApplyWorkspaceEditResult &param
        ) const -> LSPAny;
        auto anyToWorkDoneProgressBegin(
            const LSPAny &any
        ) const -> WorkDoneProgressBegin;
        auto workDoneProgressBeginToAny(
            const WorkDoneProgressBegin &param
        ) const -> LSPAny;
        auto anyToWorkDoneProgressReport(
            const LSPAny &any
        ) const -> WorkDoneProgressReport;
        auto workDoneProgressReportToAny(
            const WorkDoneProgressReport &param
        ) const -> LSPAny;
        auto anyToPosition(const LSPAny &any) const -> Position;
        auto positionToAny(const Position &param) const -> LSPAny;
        auto anyToSelectionRangeParams_positions(
            const LSPAny &any
        ) const -> SelectionRangeParams_positions;
        auto selectionRangeParams_positionsToAny(
            const SelectionRangeParams_positions &array
        ) const -> LSPAny;
        auto anyToTextDocumentPositionParams(
            const LSPAny &any
        ) const -> TextDocumentPositionParams;
        auto textDocumentPositionParamsToAny(
            const TextDocumentPositionParams &param
        ) const -> LSPAny;
        auto anyToRange(const LSPAny &any) const -> Range;
        auto rangeToAny(const Range &param) const -> LSPAny;
        auto anyToLocation(const LSPAny &any) const -> Location;
        auto locationToAny(const Location &param) const -> LSPAny;
        auto anyToSelectionRange(const LSPAny &any) const -> SelectionRange;
        auto selectionRangeToAny(const SelectionRange &param) const -> LSPAny;
        auto anyToCallHierarchyIncomingCall_fromRanges(
            const LSPAny &any
        ) const -> CallHierarchyIncomingCall_fromRanges;
        auto callHierarchyIncomingCall_fromRangesToAny(
            const CallHierarchyIncomingCall_fromRanges &array
        ) const -> LSPAny;
        auto anyToCallHierarchyOutgoingCall_fromRanges(
            const LSPAny &any
        ) const -> CallHierarchyOutgoingCall_fromRanges;
        auto callHierarchyOutgoingCall_fromRangesToAny(
            const CallHierarchyOutgoingCall_fromRanges &array
        ) const -> LSPAny;
        auto anyToShowDocumentParams(
            const LSPAny &any
        ) const -> ShowDocumentParams;
        auto showDocumentParamsToAny(
            const ShowDocumentParams &param
        ) const -> LSPAny;
        auto anyToLinkedEditingRanges(
            const LSPAny &any
        ) const -> LinkedEditingRanges;
        auto linkedEditingRangesToAny(
            const LinkedEditingRanges &param
        ) const -> LSPAny;
        auto anyToLinkedEditingRanges_ranges(
            const LSPAny &any
        ) const -> LinkedEditingRanges_ranges;
        auto linkedEditingRanges_rangesToAny(
            const LinkedEditingRanges_ranges &array
        ) const -> LSPAny;
        auto anyToTextEdit(const LSPAny &any) const -> TextEdit;
        auto textEditToAny(const TextEdit &param) const -> LSPAny;
        auto anyToColorPresentation(
            const LSPAny &any
        ) const -> ColorPresentation;
        auto colorPresentationToAny(
            const ColorPresentation &param
        ) const -> LSPAny;
        auto anyToColorPresentation_additionalTextEdits(
            const LSPAny &any
        ) const -> ColorPresentation_additionalTextEdits;
        auto colorPresentation_additionalTextEditsToAny(
            const ColorPresentation_additionalTextEdits &array
        ) const -> LSPAny;
        auto anyToWorkspaceEdit_changes(
            const LSPAny &any
        ) const -> WorkspaceEdit_changes;
        auto workspaceEdit_changesToAny(
            const WorkspaceEdit_changes &map
        ) const -> LSPAny;
        auto anyToWorkspaceEdit_changes_value(
            const LSPAny &any
        ) const -> WorkspaceEdit_changes_value;
        auto workspaceEdit_changes_valueToAny(
            const WorkspaceEdit_changes_value &array
        ) const -> LSPAny;
        auto anyToInlayHint_textEdits(
            const LSPAny &any
        ) const -> InlayHint_textEdits;
        auto inlayHint_textEditsToAny(
            const InlayHint_textEdits &array
        ) const -> LSPAny;
        auto anyToCompletionItem_additionalTextEdits(
            const LSPAny &any
        ) const -> CompletionItem_additionalTextEdits;
        auto completionItem_additionalTextEditsToAny(
            const CompletionItem_additionalTextEdits &array
        ) const -> LSPAny;
        auto anyToCompletionList_itemDefaults_editRange_1(
            const LSPAny &any
        ) const -> CompletionList_itemDefaults_editRange_1;
        auto completionList_itemDefaults_editRange_1ToAny(
            const CompletionList_itemDefaults_editRange_1 &param
        ) const -> LSPAny;
        auto anyToCompletionList_itemDefaults_editRange(
            const LSPAny &any
        ) const -> CompletionList_itemDefaults_editRange;
        auto completionList_itemDefaults_editRangeToAny(
            const CompletionList_itemDefaults_editRange &param
        ) const -> LSPAny;
        auto anyToHover(const LSPAny &any) const -> Hover;
        auto hoverToAny(const Hover &param) const -> LSPAny;
        auto anyToDocumentHighlight(
            const LSPAny &any
        ) const -> DocumentHighlight;
        auto documentHighlightToAny(
            const DocumentHighlight &param
        ) const -> LSPAny;
        auto anyToSymbolInformation(
            const LSPAny &any
        ) const -> SymbolInformation;
        auto symbolInformationToAny(
            const SymbolInformation &param
        ) const -> LSPAny;
        auto anyToDocumentSymbol(const LSPAny &any) const -> DocumentSymbol;
        auto documentSymbolToAny(const DocumentSymbol &param) const -> LSPAny;
        auto anyToDocumentSymbol_children(
            const LSPAny &any
        ) const -> DocumentSymbol_children;
        auto documentSymbol_childrenToAny(
            const DocumentSymbol_children &array
        ) const -> LSPAny;
        auto anyToWorkspaceSymbol_location(
            const LSPAny &any
        ) const -> WorkspaceSymbol_location;
        auto workspaceSymbol_locationToAny(
            const WorkspaceSymbol_location &param
        ) const -> LSPAny;
        auto anyToDocumentRangesFormattingParams_ranges(
            const LSPAny &any
        ) const -> DocumentRangesFormattingParams_ranges;
        auto documentRangesFormattingParams_rangesToAny(
            const DocumentRangesFormattingParams_ranges &array
        ) const -> LSPAny;
        auto anyToLocationLink(const LSPAny &any) const -> LocationLink;
        auto locationLinkToAny(const LocationLink &param) const -> LSPAny;
        auto anyToSemanticTokensEdit(
            const LSPAny &any
        ) const -> SemanticTokensEdit;
        auto semanticTokensEditToAny(
            const SemanticTokensEdit &param
        ) const -> LSPAny;
        auto anyToSemanticTokensDelta(
            const LSPAny &any
        ) const -> SemanticTokensDelta;
        auto semanticTokensDeltaToAny(
            const SemanticTokensDelta &param
        ) const -> LSPAny;
        auto anyToSemanticTokensDelta_edits(
            const LSPAny &any
        ) const -> SemanticTokensDelta_edits;
        auto semanticTokensDelta_editsToAny(
            const SemanticTokensDelta_edits &array
        ) const -> LSPAny;
        auto anyToSemanticTokensDeltaPartialResult(
            const LSPAny &any
        ) const -> SemanticTokensDeltaPartialResult;
        auto semanticTokensDeltaPartialResultToAny(
            const SemanticTokensDeltaPartialResult &param
        ) const -> LSPAny;
        auto anyToSemanticTokensDeltaPartialResult_edits(
            const LSPAny &any
        ) const -> SemanticTokensDeltaPartialResult_edits;
        auto semanticTokensDeltaPartialResult_editsToAny(
            const SemanticTokensDeltaPartialResult_edits &array
        ) const -> LSPAny;
        auto anyToSemanticTokensEdit_data(
            const LSPAny &any
        ) const -> SemanticTokensEdit_data;
        auto semanticTokensEdit_dataToAny(
            const SemanticTokensEdit_data &array
        ) const -> LSPAny;
        auto anyToInlineValueText(const LSPAny &any) const -> InlineValueText;
        auto inlineValueTextToAny(
            const InlineValueText &param
        ) const -> LSPAny;
        auto anyToInlineValueVariableLookup(
            const LSPAny &any
        ) const -> InlineValueVariableLookup;
        auto inlineValueVariableLookupToAny(
            const InlineValueVariableLookup &param
        ) const -> LSPAny;
        auto anyToInlineValueEvaluatableExpression(
            const LSPAny &any
        ) const -> InlineValueEvaluatableExpression;
        auto inlineValueEvaluatableExpressionToAny(
            const InlineValueEvaluatableExpression &param
        ) const -> LSPAny;
        auto anyToInsertReplaceEdit(
            const LSPAny &any
        ) const -> InsertReplaceEdit;
        auto insertReplaceEditToAny(
            const InsertReplaceEdit &param
        ) const -> LSPAny;
        auto anyToCompletionItem_textEdit(
            const LSPAny &any
        ) const -> CompletionItem_textEdit;
        auto completionItem_textEditToAny(
            const CompletionItem_textEdit &param
        ) const -> LSPAny;
        auto anyToFormattingOptions(
            const LSPAny &any
        ) const -> FormattingOptions;
        auto formattingOptionsToAny(
            const FormattingOptions &param
        ) const -> LSPAny;
        auto anyToDocumentOnTypeFormattingParams(
            const LSPAny &any
        ) const -> DocumentOnTypeFormattingParams;
        auto documentOnTypeFormattingParamsToAny(
            const DocumentOnTypeFormattingParams &param
        ) const -> LSPAny;
        auto anyToAnnotatedTextEdit(
            const LSPAny &any
        ) const -> AnnotatedTextEdit;
        auto annotatedTextEditToAny(
            const AnnotatedTextEdit &param
        ) const -> LSPAny;
        auto anyToTextDocumentEdit_edits_elem(
            const LSPAny &any
        ) const -> TextDocumentEdit_edits_elem;
        auto textDocumentEdit_edits_elemToAny(
            const TextDocumentEdit_edits_elem &param
        ) const -> LSPAny;
        auto anyToTextDocumentEdit_edits(
            const LSPAny &any
        ) const -> TextDocumentEdit_edits;
        auto textDocumentEdit_editsToAny(
            const TextDocumentEdit_edits &array
        ) const -> LSPAny;
        auto anyToSelectedCompletionInfo(
            const LSPAny &any
        ) const -> SelectedCompletionInfo;
        auto selectedCompletionInfoToAny(
            const SelectedCompletionInfo &param
        ) const -> LSPAny;
        auto anyToInlineCompletionContext(
            const LSPAny &any
        ) const -> InlineCompletionContext;
        auto inlineCompletionContextToAny(
            const InlineCompletionContext &param
        ) const -> LSPAny;
        auto anyToDiagnosticRelatedInformation(
            const LSPAny &any
        ) const -> DiagnosticRelatedInformation;
        auto diagnosticRelatedInformationToAny(
            const DiagnosticRelatedInformation &param
        ) const -> LSPAny;
        auto anyToDiagnostic_relatedInformation(
            const LSPAny &any
        ) const -> Diagnostic_relatedInformation;
        auto diagnostic_relatedInformationToAny(
            const Diagnostic_relatedInformation &array
        ) const -> LSPAny;
        auto anyToParameterInformation_label(
            const LSPAny &any
        ) const -> ParameterInformation_label;
        auto parameterInformation_labelToAny(
            const ParameterInformation_label &param
        ) const -> LSPAny;
        auto anyToParameterInformation(
            const LSPAny &any
        ) const -> ParameterInformation;
        auto parameterInformationToAny(
            const ParameterInformation &param
        ) const -> LSPAny;
        auto anyToSignatureInformation(
            const LSPAny &any
        ) const -> SignatureInformation;
        auto signatureInformationToAny(
            const SignatureInformation &param
        ) const -> LSPAny;
        auto anyToSignatureHelp(const LSPAny &any) const -> SignatureHelp;
        auto signatureHelpToAny(const SignatureHelp &param) const -> LSPAny;
        auto anyToSignatureHelp_signatures(
            const LSPAny &any
        ) const -> SignatureHelp_signatures;
        auto signatureHelp_signaturesToAny(
            const SignatureHelp_signatures &array
        ) const -> LSPAny;
        auto anyToSignatureHelpContext(
            const LSPAny &any
        ) const -> SignatureHelpContext;
        auto signatureHelpContextToAny(
            const SignatureHelpContext &param
        ) const -> LSPAny;
        auto anyToSignatureInformation_parameters(
            const LSPAny &any
        ) const -> SignatureInformation_parameters;
        auto signatureInformation_parametersToAny(
            const SignatureInformation_parameters &array
        ) const -> LSPAny;
        auto anyToExecutionSummary(
            const LSPAny &any
        ) const -> ExecutionSummary;
        auto executionSummaryToAny(
            const ExecutionSummary &param
        ) const -> LSPAny;
        auto anyToFoldingRangeClientCapabilities(
            const LSPAny &any
        ) const -> FoldingRangeClientCapabilities;
        auto foldingRangeClientCapabilitiesToAny(
            const FoldingRangeClientCapabilities &param
        ) const -> LSPAny;
        auto anyToDefinition(const LSPAny &any) const -> Definition;
        auto definitionToAny(const Definition &param) const -> LSPAny;
        auto anyToDefinition_1(const LSPAny &any) const -> Definition_1;
        auto definition_1ToAny(const Definition_1 &array) const -> LSPAny;
        auto anyToDefinitionLink(const LSPAny &any) const -> DefinitionLink;
        auto definitionLinkToAny(const DefinitionLink &param) const -> LSPAny;
        auto anyToDeclaration(const LSPAny &any) const -> Declaration;
        auto declarationToAny(const Declaration &param) const -> LSPAny;
        auto anyToDeclaration_1(const LSPAny &any) const -> Declaration_1;
        auto declaration_1ToAny(const Declaration_1 &array) const -> LSPAny;
        auto anyToDeclarationLink(const LSPAny &any) const -> DeclarationLink;
        auto declarationLinkToAny(
            const DeclarationLink &param
        ) const -> LSPAny;
        auto anyToInlineValue(const LSPAny &any) const -> InlineValue;
        auto inlineValueToAny(const InlineValue &param) const -> LSPAny;
        auto anyToPrepareRenameResult_1(
            const LSPAny &any
        ) const -> PrepareRenameResult_1;
        auto prepareRenameResult_1ToAny(
            const PrepareRenameResult_1 &param
        ) const -> LSPAny;
        auto anyToPrepareRenameResult(
            const LSPAny &any
        ) const -> PrepareRenameResult;
        auto prepareRenameResultToAny(
            const PrepareRenameResult &param
        ) const -> LSPAny;
        auto anyToTextDocumentContentChangeEvent_0(
            const LSPAny &any
        ) const -> TextDocumentContentChangeEvent_0;
        auto textDocumentContentChangeEvent_0ToAny(
            const TextDocumentContentChangeEvent_0 &param
        ) const -> LSPAny;
        auto anyToTextDocumentContentChangeEvent(
            const LSPAny &any
        ) const -> TextDocumentContentChangeEvent;
        auto textDocumentContentChangeEventToAny(
            const TextDocumentContentChangeEvent &param
        ) const -> LSPAny;
        auto anyToDidChangeTextDocumentParams_contentChanges(
            const LSPAny &any
        ) const -> DidChangeTextDocumentParams_contentChanges;
        auto didChangeTextDocumentParams_contentChangesToAny(
            const DidChangeTextDocumentParams_contentChanges &array
        ) const -> LSPAny;
        auto anyToNotebookDocumentChangeEvent_cells_textContent_elem_changes(
            const LSPAny &any
        ) const -> NotebookDocumentChangeEvent_cells_textContent_elem_changes;
        auto notebookDocumentChangeEvent_cells_textContent_elem_changesToAny(
            const NotebookDocumentChangeEvent_cells_textContent_elem_changes &array
        ) const -> LSPAny;
        auto anyToTextDocument_ImplementationResult(
            const LSPAny &any
        ) const -> TextDocument_ImplementationResult;
        auto textDocument_ImplementationResultToAny(
            const TextDocument_ImplementationResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_ImplementationResult_1(
            const LSPAny &any
        ) const -> TextDocument_ImplementationResult_1;
        auto textDocument_ImplementationResult_1ToAny(
            const TextDocument_ImplementationResult_1 &array
        ) const -> LSPAny;
        auto anyToTextDocument_ImplementationResult_3(
            const LSPAny &any
        ) const -> TextDocument_ImplementationResult_3;
        auto textDocument_ImplementationResult_3ToAny(
            const TextDocument_ImplementationResult_3 &array
        ) const -> LSPAny;
        auto anyToTextDocument_TypeDefinitionResult(
            const LSPAny &any
        ) const -> TextDocument_TypeDefinitionResult;
        auto textDocument_TypeDefinitionResultToAny(
            const TextDocument_TypeDefinitionResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_TypeDefinitionResult_1(
            const LSPAny &any
        ) const -> TextDocument_TypeDefinitionResult_1;
        auto textDocument_TypeDefinitionResult_1ToAny(
            const TextDocument_TypeDefinitionResult_1 &array
        ) const -> LSPAny;
        auto anyToTextDocument_TypeDefinitionResult_3(
            const LSPAny &any
        ) const -> TextDocument_TypeDefinitionResult_3;
        auto textDocument_TypeDefinitionResult_3ToAny(
            const TextDocument_TypeDefinitionResult_3 &array
        ) const -> LSPAny;
        auto anyToTextDocument_ColorPresentationResult(
            const LSPAny &any
        ) const -> TextDocument_ColorPresentationResult;
        auto textDocument_ColorPresentationResultToAny(
            const TextDocument_ColorPresentationResult &array
        ) const -> LSPAny;
        auto anyToTextDocument_FoldingRangeResult(
            const LSPAny &any
        ) const -> TextDocument_FoldingRangeResult;
        auto textDocument_FoldingRangeResultToAny(
            const TextDocument_FoldingRangeResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_FoldingRangeResult_0(
            const LSPAny &any
        ) const -> TextDocument_FoldingRangeResult_0;
        auto textDocument_FoldingRangeResult_0ToAny(
            const TextDocument_FoldingRangeResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_DeclarationResult(
            const LSPAny &any
        ) const -> TextDocument_DeclarationResult;
        auto textDocument_DeclarationResultToAny(
            const TextDocument_DeclarationResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_DeclarationResult_1(
            const LSPAny &any
        ) const -> TextDocument_DeclarationResult_1;
        auto textDocument_DeclarationResult_1ToAny(
            const TextDocument_DeclarationResult_1 &array
        ) const -> LSPAny;
        auto anyToTextDocument_DeclarationResult_3(
            const LSPAny &any
        ) const -> TextDocument_DeclarationResult_3;
        auto textDocument_DeclarationResult_3ToAny(
            const TextDocument_DeclarationResult_3 &array
        ) const -> LSPAny;
        auto anyToTextDocument_SelectionRangeResult(
            const LSPAny &any
        ) const -> TextDocument_SelectionRangeResult;
        auto textDocument_SelectionRangeResultToAny(
            const TextDocument_SelectionRangeResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_SelectionRangeResult_0(
            const LSPAny &any
        ) const -> TextDocument_SelectionRangeResult_0;
        auto textDocument_SelectionRangeResult_0ToAny(
            const TextDocument_SelectionRangeResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_SemanticTokens_FullResult(
            const LSPAny &any
        ) const -> TextDocument_SemanticTokens_FullResult;
        auto textDocument_SemanticTokens_FullResultToAny(
            const TextDocument_SemanticTokens_FullResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_SemanticTokens_Full_DeltaResult(
            const LSPAny &any
        ) const -> TextDocument_SemanticTokens_Full_DeltaResult;
        auto textDocument_SemanticTokens_Full_DeltaResultToAny(
            const TextDocument_SemanticTokens_Full_DeltaResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_SemanticTokens_RangeResult(
            const LSPAny &any
        ) const -> TextDocument_SemanticTokens_RangeResult;
        auto textDocument_SemanticTokens_RangeResultToAny(
            const TextDocument_SemanticTokens_RangeResult &param
        ) const -> LSPAny;
        auto asMessageParams(
            const ShowDocumentParams &requestParams
        ) const -> MessageParams;
        auto anyToTextDocument_LinkedEditingRangeResult(
            const LSPAny &any
        ) const -> TextDocument_LinkedEditingRangeResult;
        auto textDocument_LinkedEditingRangeResultToAny(
            const TextDocument_LinkedEditingRangeResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_InlineValueResult(
            const LSPAny &any
        ) const -> TextDocument_InlineValueResult;
        auto textDocument_InlineValueResultToAny(
            const TextDocument_InlineValueResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_InlineValueResult_0(
            const LSPAny &any
        ) const -> TextDocument_InlineValueResult_0;
        auto textDocument_InlineValueResult_0ToAny(
            const TextDocument_InlineValueResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_WillSaveWaitUntilResult(
            const LSPAny &any
        ) const -> TextDocument_WillSaveWaitUntilResult;
        auto textDocument_WillSaveWaitUntilResultToAny(
            const TextDocument_WillSaveWaitUntilResult &param
        ) const -> LSPAny;
        auto asTextDocument_WillSaveWaitUntilParams(
            const MessageParams &requestParams
        ) const -> WillSaveTextDocumentParams;
        auto anyToTextDocument_WillSaveWaitUntilResult_0(
            const LSPAny &any
        ) const -> TextDocument_WillSaveWaitUntilResult_0;
        auto textDocument_WillSaveWaitUntilResult_0ToAny(
            const TextDocument_WillSaveWaitUntilResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_HoverResult(
            const LSPAny &any
        ) const -> TextDocument_HoverResult;
        auto textDocument_HoverResultToAny(
            const TextDocument_HoverResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_SignatureHelpResult(
            const LSPAny &any
        ) const -> TextDocument_SignatureHelpResult;
        auto textDocument_SignatureHelpResultToAny(
            const TextDocument_SignatureHelpResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_DefinitionResult(
            const LSPAny &any
        ) const -> TextDocument_DefinitionResult;
        auto textDocument_DefinitionResultToAny(
            const TextDocument_DefinitionResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_DefinitionResult_1(
            const LSPAny &any
        ) const -> TextDocument_DefinitionResult_1;
        auto textDocument_DefinitionResult_1ToAny(
            const TextDocument_DefinitionResult_1 &array
        ) const -> LSPAny;
        auto anyToTextDocument_DefinitionResult_3(
            const LSPAny &any
        ) const -> TextDocument_DefinitionResult_3;
        auto textDocument_DefinitionResult_3ToAny(
            const TextDocument_DefinitionResult_3 &array
        ) const -> LSPAny;
        auto anyToTextDocument_ReferencesResult(
            const LSPAny &any
        ) const -> TextDocument_ReferencesResult;
        auto textDocument_ReferencesResultToAny(
            const TextDocument_ReferencesResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_ReferencesResult_0(
            const LSPAny &any
        ) const -> TextDocument_ReferencesResult_0;
        auto textDocument_ReferencesResult_0ToAny(
            const TextDocument_ReferencesResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_DocumentHighlightResult(
            const LSPAny &any
        ) const -> TextDocument_DocumentHighlightResult;
        auto textDocument_DocumentHighlightResultToAny(
            const TextDocument_DocumentHighlightResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_DocumentHighlightResult_0(
            const LSPAny &any
        ) const -> TextDocument_DocumentHighlightResult_0;
        auto textDocument_DocumentHighlightResult_0ToAny(
            const TextDocument_DocumentHighlightResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_DocumentSymbolResult(
            const LSPAny &any
        ) const -> TextDocument_DocumentSymbolResult;
        auto textDocument_DocumentSymbolResultToAny(
            const TextDocument_DocumentSymbolResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_DocumentSymbolResult_0(
            const LSPAny &any
        ) const -> TextDocument_DocumentSymbolResult_0;
        auto textDocument_DocumentSymbolResult_0ToAny(
            const TextDocument_DocumentSymbolResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_DocumentSymbolResult_1(
            const LSPAny &any
        ) const -> TextDocument_DocumentSymbolResult_1;
        auto textDocument_DocumentSymbolResult_1ToAny(
            const TextDocument_DocumentSymbolResult_1 &array
        ) const -> LSPAny;
        auto anyToWorkspace_SymbolResult_0(
            const LSPAny &any
        ) const -> Workspace_SymbolResult_0;
        auto workspace_SymbolResult_0ToAny(
            const Workspace_SymbolResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_FormattingResult(
            const LSPAny &any
        ) const -> TextDocument_FormattingResult;
        auto textDocument_FormattingResultToAny(
            const TextDocument_FormattingResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_FormattingResult_0(
            const LSPAny &any
        ) const -> TextDocument_FormattingResult_0;
        auto textDocument_FormattingResult_0ToAny(
            const TextDocument_FormattingResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_RangeFormattingResult(
            const LSPAny &any
        ) const -> TextDocument_RangeFormattingResult;
        auto textDocument_RangeFormattingResultToAny(
            const TextDocument_RangeFormattingResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_RangeFormattingResult_0(
            const LSPAny &any
        ) const -> TextDocument_RangeFormattingResult_0;
        auto textDocument_RangeFormattingResult_0ToAny(
            const TextDocument_RangeFormattingResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_RangesFormattingResult(
            const LSPAny &any
        ) const -> TextDocument_RangesFormattingResult;
        auto textDocument_RangesFormattingResultToAny(
            const TextDocument_RangesFormattingResult &param
        ) const -> LSPAny;
        auto anyToTextDocument_RangesFormattingResult_0(
            const LSPAny &any
        ) const -> TextDocument_RangesFormattingResult_0;
        auto textDocument_RangesFormattingResult_0ToAny(
            const TextDocument_RangesFormattingResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_OnTypeFormattingResult(
            const LSPAny &any
        ) const -> TextDocument_OnTypeFormattingResult;
        auto textDocument_OnTypeFormattingResultToAny(
            const TextDocument_OnTypeFormattingResult &param
        ) const -> LSPAny;
        auto asTextDocument_OnTypeFormattingParams(
            const MessageParams &requestParams
        ) const -> DocumentOnTypeFormattingParams;
        auto anyToTextDocument_OnTypeFormattingResult_0(
            const LSPAny &any
        ) const -> TextDocument_OnTypeFormattingResult_0;
        auto textDocument_OnTypeFormattingResult_0ToAny(
            const TextDocument_OnTypeFormattingResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_PrepareRenameResult(
            const LSPAny &any
        ) const -> TextDocument_PrepareRenameResult;
        auto textDocument_PrepareRenameResultToAny(
            const TextDocument_PrepareRenameResult &param
        ) const -> LSPAny;
        auto anyToWorkspace_ApplyEditResult(
            const LSPAny &any
        ) const -> Workspace_ApplyEditResult;
        auto workspace_ApplyEditResultToAny(
            const Workspace_ApplyEditResult &param
        ) const -> LSPAny;
        auto anyToInitializedParams(
            const LSPAny &any
        ) const -> InitializedParams;
        auto initializedParamsToAny(
            const InitializedParams &param
        ) const -> LSPAny;
        auto asInitializedParams(
            const MessageParams &notificationParams
        ) const -> InitializedParams;
        auto anyToInteger(const LSPAny &any) const -> integer_t;
        auto integerToAny(integer_t param) const -> LSPAny;
        auto anyToCancelParams_id(const LSPAny &any) const -> CancelParams_id;
        auto cancelParams_idToAny(
            const CancelParams_id &param
        ) const -> LSPAny;
        auto anyToCancelParams(const LSPAny &any) const -> CancelParams;
        auto cancelParamsToAny(const CancelParams &param) const -> LSPAny;
        auto anyToInlineValueContext(
            const LSPAny &any
        ) const -> InlineValueContext;
        auto inlineValueContextToAny(
            const InlineValueContext &param
        ) const -> LSPAny;
        auto anyToTextDocumentItem(
            const LSPAny &any
        ) const -> TextDocumentItem;
        auto textDocumentItemToAny(
            const TextDocumentItem &param
        ) const -> LSPAny;
        auto anyToDidOpenNotebookDocumentParams_cellTextDocuments(
            const LSPAny &any
        ) const -> DidOpenNotebookDocumentParams_cellTextDocuments;
        auto didOpenNotebookDocumentParams_cellTextDocumentsToAny(
            const DidOpenNotebookDocumentParams_cellTextDocuments &array
        ) const -> LSPAny;
        auto anyToDidOpenTextDocumentParams(
            const LSPAny &any
        ) const -> DidOpenTextDocumentParams;
        auto didOpenTextDocumentParamsToAny(
            const DidOpenTextDocumentParams &param
        ) const -> LSPAny;
        auto anyToVersionedNotebookDocumentIdentifier(
            const LSPAny &any
        ) const -> VersionedNotebookDocumentIdentifier;
        auto versionedNotebookDocumentIdentifierToAny(
            const VersionedNotebookDocumentIdentifier &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentChangeEvent_cells_structure_didOpen(
            const LSPAny &any
        ) const -> NotebookDocumentChangeEvent_cells_structure_didOpen;
        auto notebookDocumentChangeEvent_cells_structure_didOpenToAny(
            const NotebookDocumentChangeEvent_cells_structure_didOpen &array
        ) const -> LSPAny;
        auto anyTo_InitializeParams_processId(
            const LSPAny &any
        ) const -> _InitializeParams_processId;
        auto _InitializeParams_processIdToAny(
            const _InitializeParams_processId &param
        ) const -> LSPAny;
        auto anyToVersionedTextDocumentIdentifier(
            const LSPAny &any
        ) const -> VersionedTextDocumentIdentifier;
        auto versionedTextDocumentIdentifierToAny(
            const VersionedTextDocumentIdentifier &param
        ) const -> LSPAny;
        auto anyToDidChangeTextDocumentParams(
            const LSPAny &any
        ) const -> DidChangeTextDocumentParams;
        auto didChangeTextDocumentParamsToAny(
            const DidChangeTextDocumentParams &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentChangeEvent_cells_textContent_elem(
            const LSPAny &any
        ) const -> NotebookDocumentChangeEvent_cells_textContent_elem;
        auto notebookDocumentChangeEvent_cells_textContent_elemToAny(
            const NotebookDocumentChangeEvent_cells_textContent_elem &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentChangeEvent_cells_textContent(
            const LSPAny &any
        ) const -> NotebookDocumentChangeEvent_cells_textContent;
        auto notebookDocumentChangeEvent_cells_textContentToAny(
            const NotebookDocumentChangeEvent_cells_textContent &array
        ) const -> LSPAny;
        auto anyToDiagnostic_code(const LSPAny &any) const -> Diagnostic_code;
        auto diagnostic_codeToAny(
            const Diagnostic_code &param
        ) const -> LSPAny;
        auto anyToOptionalVersionedTextDocumentIdentifier_version(
            const LSPAny &any
        ) const -> OptionalVersionedTextDocumentIdentifier_version;
        auto optionalVersionedTextDocumentIdentifier_versionToAny(
            const OptionalVersionedTextDocumentIdentifier_version &param
        ) const -> LSPAny;
        auto anyToOptionalVersionedTextDocumentIdentifier(
            const LSPAny &any
        ) const -> OptionalVersionedTextDocumentIdentifier;
        auto optionalVersionedTextDocumentIdentifierToAny(
            const OptionalVersionedTextDocumentIdentifier &param
        ) const -> LSPAny;
        auto anyToTextDocumentEdit(
            const LSPAny &any
        ) const -> TextDocumentEdit;
        auto textDocumentEditToAny(
            const TextDocumentEdit &param
        ) const -> LSPAny;
        auto anyToWorkspaceEdit_documentChanges_elem(
            const LSPAny &any
        ) const -> WorkspaceEdit_documentChanges_elem;
        auto workspaceEdit_documentChanges_elemToAny(
            const WorkspaceEdit_documentChanges_elem &param
        ) const -> LSPAny;
        auto anyToWorkspaceEdit(const LSPAny &any) const -> WorkspaceEdit;
        auto workspaceEditToAny(const WorkspaceEdit &param) const -> LSPAny;
        auto anyToWorkspaceEdit_documentChanges(
            const LSPAny &any
        ) const -> WorkspaceEdit_documentChanges;
        auto workspaceEdit_documentChangesToAny(
            const WorkspaceEdit_documentChanges &array
        ) const -> LSPAny;
        auto anyToApplyWorkspaceEditParams(
            const LSPAny &any
        ) const -> ApplyWorkspaceEditParams;
        auto applyWorkspaceEditParamsToAny(
            const ApplyWorkspaceEditParams &param
        ) const -> LSPAny;
        auto anyToWorkspaceFullDocumentDiagnosticReport_version(
            const LSPAny &any
        ) const -> WorkspaceFullDocumentDiagnosticReport_version;
        auto workspaceFullDocumentDiagnosticReport_versionToAny(
            const WorkspaceFullDocumentDiagnosticReport_version &param
        ) const -> LSPAny;
        auto anyToWorkspaceUnchangedDocumentDiagnosticReport_version(
            const LSPAny &any
        ) const -> WorkspaceUnchangedDocumentDiagnosticReport_version;
        auto workspaceUnchangedDocumentDiagnosticReport_versionToAny(
            const WorkspaceUnchangedDocumentDiagnosticReport_version &param
        ) const -> LSPAny;
        auto anyToWorkspaceUnchangedDocumentDiagnosticReport(
            const LSPAny &any
        ) const -> WorkspaceUnchangedDocumentDiagnosticReport;
        auto workspaceUnchangedDocumentDiagnosticReportToAny(
            const WorkspaceUnchangedDocumentDiagnosticReport &param
        ) const -> LSPAny;
        auto anyToDocumentResult(const LSPAny &any) const -> DocumentResult;
        auto documentResultToAny(const DocumentResult &param) const -> LSPAny;
        auto anyToProgressToken(const LSPAny &any) const -> ProgressToken;
        auto progressTokenToAny(const ProgressToken &param) const -> LSPAny;
        auto anyToWorkDoneProgressCreateParams(
            const LSPAny &any
        ) const -> WorkDoneProgressCreateParams;
        auto workDoneProgressCreateParamsToAny(
            const WorkDoneProgressCreateParams &param
        ) const -> LSPAny;
        auto anyToWorkDoneProgressCancelParams(
            const LSPAny &any
        ) const -> WorkDoneProgressCancelParams;
        auto workDoneProgressCancelParamsToAny(
            const WorkDoneProgressCancelParams &param
        ) const -> LSPAny;
        auto anyToWorkDoneProgressParams(
            const LSPAny &any
        ) const -> WorkDoneProgressParams;
        auto workDoneProgressParamsToAny(
            const WorkDoneProgressParams &param
        ) const -> LSPAny;
        auto anyToCallHierarchyPrepareParams(
            const LSPAny &any
        ) const -> CallHierarchyPrepareParams;
        auto callHierarchyPrepareParamsToAny(
            const CallHierarchyPrepareParams &param
        ) const -> LSPAny;
        auto anyToLinkedEditingRangeParams(
            const LSPAny &any
        ) const -> LinkedEditingRangeParams;
        auto linkedEditingRangeParamsToAny(
            const LinkedEditingRangeParams &param
        ) const -> LSPAny;
        auto anyToTypeHierarchyPrepareParams(
            const LSPAny &any
        ) const -> TypeHierarchyPrepareParams;
        auto typeHierarchyPrepareParamsToAny(
            const TypeHierarchyPrepareParams &param
        ) const -> LSPAny;
        auto anyToInlineValueParams(
            const LSPAny &any
        ) const -> InlineValueParams;
        auto inlineValueParamsToAny(
            const InlineValueParams &param
        ) const -> LSPAny;
        auto anyToInlayHintParams(const LSPAny &any) const -> InlayHintParams;
        auto inlayHintParamsToAny(
            const InlayHintParams &param
        ) const -> LSPAny;
        auto anyToInlineCompletionParams(
            const LSPAny &any
        ) const -> InlineCompletionParams;
        auto inlineCompletionParamsToAny(
            const InlineCompletionParams &param
        ) const -> LSPAny;
        auto anyToHoverParams(const LSPAny &any) const -> HoverParams;
        auto hoverParamsToAny(const HoverParams &param) const -> LSPAny;
        auto anyToSignatureHelpParams(
            const LSPAny &any
        ) const -> SignatureHelpParams;
        auto signatureHelpParamsToAny(
            const SignatureHelpParams &param
        ) const -> LSPAny;
        auto anyToDocumentFormattingParams(
            const LSPAny &any
        ) const -> DocumentFormattingParams;
        auto documentFormattingParamsToAny(
            const DocumentFormattingParams &param
        ) const -> LSPAny;
        auto anyToDocumentRangeFormattingParams(
            const LSPAny &any
        ) const -> DocumentRangeFormattingParams;
        auto documentRangeFormattingParamsToAny(
            const DocumentRangeFormattingParams &param
        ) const -> LSPAny;
        auto anyToDocumentRangesFormattingParams(
            const LSPAny &any
        ) const -> DocumentRangesFormattingParams;
        auto documentRangesFormattingParamsToAny(
            const DocumentRangesFormattingParams &param
        ) const -> LSPAny;
        auto anyToRenameParams(const LSPAny &any) const -> RenameParams;
        auto renameParamsToAny(const RenameParams &param) const -> LSPAny;
        auto anyToPrepareRenameParams(
            const LSPAny &any
        ) const -> PrepareRenameParams;
        auto prepareRenameParamsToAny(
            const PrepareRenameParams &param
        ) const -> LSPAny;
        auto anyToPartialResultParams(
            const LSPAny &any
        ) const -> PartialResultParams;
        auto partialResultParamsToAny(
            const PartialResultParams &param
        ) const -> LSPAny;
        auto anyToImplementationParams(
            const LSPAny &any
        ) const -> ImplementationParams;
        auto implementationParamsToAny(
            const ImplementationParams &param
        ) const -> LSPAny;
        auto anyToTypeDefinitionParams(
            const LSPAny &any
        ) const -> TypeDefinitionParams;
        auto typeDefinitionParamsToAny(
            const TypeDefinitionParams &param
        ) const -> LSPAny;
        auto anyToDocumentColorParams(
            const LSPAny &any
        ) const -> DocumentColorParams;
        auto documentColorParamsToAny(
            const DocumentColorParams &param
        ) const -> LSPAny;
        auto anyToFoldingRangeParams(
            const LSPAny &any
        ) const -> FoldingRangeParams;
        auto foldingRangeParamsToAny(
            const FoldingRangeParams &param
        ) const -> LSPAny;
        auto anyToDeclarationParams(
            const LSPAny &any
        ) const -> DeclarationParams;
        auto declarationParamsToAny(
            const DeclarationParams &param
        ) const -> LSPAny;
        auto anyToSelectionRangeParams(
            const LSPAny &any
        ) const -> SelectionRangeParams;
        auto selectionRangeParamsToAny(
            const SelectionRangeParams &param
        ) const -> LSPAny;
        auto anyToSemanticTokensParams(
            const LSPAny &any
        ) const -> SemanticTokensParams;
        auto semanticTokensParamsToAny(
            const SemanticTokensParams &param
        ) const -> LSPAny;
        auto anyToSemanticTokensDeltaParams(
            const LSPAny &any
        ) const -> SemanticTokensDeltaParams;
        auto semanticTokensDeltaParamsToAny(
            const SemanticTokensDeltaParams &param
        ) const -> LSPAny;
        auto anyToSemanticTokensRangeParams(
            const LSPAny &any
        ) const -> SemanticTokensRangeParams;
        auto semanticTokensRangeParamsToAny(
            const SemanticTokensRangeParams &param
        ) const -> LSPAny;
        auto anyToMonikerParams(const LSPAny &any) const -> MonikerParams;
        auto monikerParamsToAny(const MonikerParams &param) const -> LSPAny;
        auto anyToDocumentDiagnosticParams(
            const LSPAny &any
        ) const -> DocumentDiagnosticParams;
        auto documentDiagnosticParamsToAny(
            const DocumentDiagnosticParams &param
        ) const -> LSPAny;
        auto anyToWorkspaceDiagnosticParams(
            const LSPAny &any
        ) const -> WorkspaceDiagnosticParams;
        auto workspaceDiagnosticParamsToAny(
            const WorkspaceDiagnosticParams &param
        ) const -> LSPAny;
        auto anyToCompletionParams(
            const LSPAny &any
        ) const -> CompletionParams;
        auto completionParamsToAny(
            const CompletionParams &param
        ) const -> LSPAny;
        auto anyToDefinitionParams(
            const LSPAny &any
        ) const -> DefinitionParams;
        auto definitionParamsToAny(
            const DefinitionParams &param
        ) const -> LSPAny;
        auto anyToReferenceParams(const LSPAny &any) const -> ReferenceParams;
        auto referenceParamsToAny(
            const ReferenceParams &param
        ) const -> LSPAny;
        auto anyToDocumentHighlightParams(
            const LSPAny &any
        ) const -> DocumentHighlightParams;
        auto documentHighlightParamsToAny(
            const DocumentHighlightParams &param
        ) const -> LSPAny;
        auto anyToDocumentSymbolParams(
            const LSPAny &any
        ) const -> DocumentSymbolParams;
        auto documentSymbolParamsToAny(
            const DocumentSymbolParams &param
        ) const -> LSPAny;
        auto anyToWorkspaceSymbolParams(
            const LSPAny &any
        ) const -> WorkspaceSymbolParams;
        auto workspaceSymbolParamsToAny(
            const WorkspaceSymbolParams &param
        ) const -> LSPAny;
        auto anyToCodeLensParams(const LSPAny &any) const -> CodeLensParams;
        auto codeLensParamsToAny(const CodeLensParams &param) const -> LSPAny;
        auto anyToDocumentLinkParams(
            const LSPAny &any
        ) const -> DocumentLinkParams;
        auto documentLinkParamsToAny(
            const DocumentLinkParams &param
        ) const -> LSPAny;
        auto anyToRequestId(const LSPAny &any) const -> RequestId;
        auto requestIdToAny(const RequestId &param) const -> LSPAny;
        auto anyToResponseId(const LSPAny &any) const -> ResponseId;
        auto responseIdToAny(const ResponseId &param) const -> LSPAny;
        auto asTextDocument_ImplementationParams(
            const MessageParams &requestParams
        ) const -> ImplementationParams;
        auto asTextDocument_TypeDefinitionParams(
            const MessageParams &requestParams
        ) const -> TypeDefinitionParams;
        auto asTextDocument_FoldingRangeParams(
            const MessageParams &requestParams
        ) const -> FoldingRangeParams;
        auto asTextDocument_DeclarationParams(
            const MessageParams &requestParams
        ) const -> DeclarationParams;
        auto asTextDocument_SelectionRangeParams(
            const MessageParams &requestParams
        ) const -> SelectionRangeParams;
        auto asMessageParams(
            const WorkDoneProgressCreateParams &requestParams
        ) const -> MessageParams;
        auto asTextDocument_SemanticTokens_FullParams(
            const MessageParams &requestParams
        ) const -> SemanticTokensParams;
        auto asTextDocument_SemanticTokens_Full_DeltaParams(
            const MessageParams &requestParams
        ) const -> SemanticTokensDeltaParams;
        auto asTextDocument_SemanticTokens_RangeParams(
            const MessageParams &requestParams
        ) const -> SemanticTokensRangeParams;
        auto asTextDocument_LinkedEditingRangeParams(
            const MessageParams &requestParams
        ) const -> LinkedEditingRangeParams;
        auto anyToWorkspace_WillCreateFilesResult(
            const LSPAny &any
        ) const -> Workspace_WillCreateFilesResult;
        auto workspace_WillCreateFilesResultToAny(
            const Workspace_WillCreateFilesResult &param
        ) const -> LSPAny;
        auto asWorkspace_WillCreateFilesParams(
            const MessageParams &requestParams
        ) const -> CreateFilesParams;
        auto anyToWorkspace_WillRenameFilesResult(
            const LSPAny &any
        ) const -> Workspace_WillRenameFilesResult;
        auto workspace_WillRenameFilesResultToAny(
            const Workspace_WillRenameFilesResult &param
        ) const -> LSPAny;
        auto asWorkspace_WillRenameFilesParams(
            const MessageParams &requestParams
        ) const -> RenameFilesParams;
        auto anyToWorkspace_WillDeleteFilesResult(
            const LSPAny &any
        ) const -> Workspace_WillDeleteFilesResult;
        auto workspace_WillDeleteFilesResultToAny(
            const Workspace_WillDeleteFilesResult &param
        ) const -> LSPAny;
        auto asWorkspace_WillDeleteFilesParams(
            const MessageParams &requestParams
        ) const -> DeleteFilesParams;
        auto asTextDocument_MonikerParams(
            const MessageParams &requestParams
        ) const -> MonikerParams;
        auto asTextDocument_InlineValueParams(
            const MessageParams &requestParams
        ) const -> InlineValueParams;
        auto asTextDocument_HoverParams(
            const MessageParams &requestParams
        ) const -> HoverParams;
        auto asTextDocument_SignatureHelpParams(
            const MessageParams &requestParams
        ) const -> SignatureHelpParams;
        auto asTextDocument_DefinitionParams(
            const MessageParams &requestParams
        ) const -> DefinitionParams;
        auto asTextDocument_ReferencesParams(
            const MessageParams &requestParams
        ) const -> ReferenceParams;
        auto asTextDocument_DocumentHighlightParams(
            const MessageParams &requestParams
        ) const -> DocumentHighlightParams;
        auto asTextDocument_DocumentSymbolParams(
            const MessageParams &requestParams
        ) const -> DocumentSymbolParams;
        auto asTextDocument_FormattingParams(
            const MessageParams &requestParams
        ) const -> DocumentFormattingParams;
        auto asTextDocument_RangeFormattingParams(
            const MessageParams &requestParams
        ) const -> DocumentRangeFormattingParams;
        auto asTextDocument_RangesFormattingParams(
            const MessageParams &requestParams
        ) const -> DocumentRangesFormattingParams;
        auto anyToTextDocument_RenameResult(
            const LSPAny &any
        ) const -> TextDocument_RenameResult;
        auto textDocument_RenameResultToAny(
            const TextDocument_RenameResult &param
        ) const -> LSPAny;
        auto asTextDocument_RenameParams(
            const MessageParams &requestParams
        ) const -> RenameParams;
        auto asTextDocument_PrepareRenameParams(
            const MessageParams &requestParams
        ) const -> PrepareRenameParams;
        auto asMessageParams(
            const ApplyWorkspaceEditParams &requestParams
        ) const -> MessageParams;
        auto asDocumentParams(
            const MessageParams &requestParams
        ) const -> DocumentParams;
        auto asWindow_WorkDoneProgress_CancelParams(
            const MessageParams &notificationParams
        ) const -> WorkDoneProgressCancelParams;
        auto asTextDocument_DidOpenParams(
            const MessageParams &notificationParams
        ) const -> DidOpenTextDocumentParams;
        auto asTextDocument_DidChangeParams(
            const MessageParams &notificationParams
        ) const -> DidChangeTextDocumentParams;
        auto asCancelRequestParams(
            const MessageParams &notificationParams
        ) const -> CancelParams;
        auto asMessageParams(
            const CancelParams &notificationParams
        ) const -> MessageParams;
        auto anyToDecimal(const LSPAny &any) const -> decimal_t;
        auto decimalToAny(decimal_t param) const -> LSPAny;
        auto anyToColor(const LSPAny &any) const -> Color;
        auto colorToAny(const Color &param) const -> LSPAny;
        auto anyToColorInformation(
            const LSPAny &any
        ) const -> ColorInformation;
        auto colorInformationToAny(
            const ColorInformation &param
        ) const -> LSPAny;
        auto anyToColorPresentationParams(
            const LSPAny &any
        ) const -> ColorPresentationParams;
        auto colorPresentationParamsToAny(
            const ColorPresentationParams &param
        ) const -> LSPAny;
        auto anyToTextDocument_DocumentColorResult(
            const LSPAny &any
        ) const -> TextDocument_DocumentColorResult;
        auto textDocument_DocumentColorResultToAny(
            const TextDocument_DocumentColorResult &array
        ) const -> LSPAny;
        auto asTextDocument_DocumentColorParams(
            const MessageParams &requestParams
        ) const -> DocumentColorParams;
        auto asTextDocument_ColorPresentationParams(
            const MessageParams &requestParams
        ) const -> ColorPresentationParams;
        auto anyToSemanticTokensOptions_range_1(
            const LSPAny &any
        ) const -> SemanticTokensOptions_range_1;
        auto semanticTokensOptions_range_1ToAny(
            const SemanticTokensOptions_range_1 &param
        ) const -> LSPAny;
        auto anyToSemanticTokensOptions_range(
            const LSPAny &any
        ) const -> SemanticTokensOptions_range;
        auto semanticTokensOptions_rangeToAny(
            const SemanticTokensOptions_range &param
        ) const -> LSPAny;
        auto anyToSemanticTokensOptions(
            const LSPAny &any
        ) const -> SemanticTokensOptions;
        auto semanticTokensOptionsToAny(
            const SemanticTokensOptions &param
        ) const -> LSPAny;
        auto anyToSemanticTokensRegistrationOptions(
            const LSPAny &any
        ) const -> SemanticTokensRegistrationOptions;
        auto semanticTokensRegistrationOptionsToAny(
            const SemanticTokensRegistrationOptions &param
        ) const -> LSPAny;
        auto anyToServerCapabilities_semanticTokensProvider(
            const LSPAny &any
        ) const -> ServerCapabilities_semanticTokensProvider;
        auto serverCapabilities_semanticTokensProviderToAny(
            const ServerCapabilities_semanticTokensProvider &param
        ) const -> LSPAny;
        auto anyToSemanticTokensClientCapabilities_requests_range_1(
            const LSPAny &any
        ) const -> SemanticTokensClientCapabilities_requests_range_1;
        auto semanticTokensClientCapabilities_requests_range_1ToAny(
            const SemanticTokensClientCapabilities_requests_range_1 &param
        ) const -> LSPAny;
        auto anyToSemanticTokensClientCapabilities_requests_range(
            const LSPAny &any
        ) const -> SemanticTokensClientCapabilities_requests_range;
        auto semanticTokensClientCapabilities_requests_rangeToAny(
            const SemanticTokensClientCapabilities_requests_range &param
        ) const -> LSPAny;
        auto anyToSemanticTokensClientCapabilities_requests(
            const LSPAny &any
        ) const -> SemanticTokensClientCapabilities_requests;
        auto semanticTokensClientCapabilities_requestsToAny(
            const SemanticTokensClientCapabilities_requests &param
        ) const -> LSPAny;
        auto anyToSemanticTokensClientCapabilities(
            const LSPAny &any
        ) const -> SemanticTokensClientCapabilities;
        auto semanticTokensClientCapabilitiesToAny(
            const SemanticTokensClientCapabilities &param
        ) const -> LSPAny;
        auto anyToTextDocumentClientCapabilities(
            const LSPAny &any
        ) const -> TextDocumentClientCapabilities;
        auto textDocumentClientCapabilitiesToAny(
            const TextDocumentClientCapabilities &param
        ) const -> LSPAny;
        auto anyToLSPArray(const LSPAny &any) const -> LSPArray;
        auto lspArrayToAny(const LSPArray &array) const -> LSPAny;
        auto anyToLSPAny(const LSPAny &any) const -> LSPAny;
        auto lspAnyToAny(const LSPAny &param) const -> LSPAny;
        auto anyToCallHierarchyItem(
            const LSPAny &any
        ) const -> CallHierarchyItem;
        auto callHierarchyItemToAny(
            const CallHierarchyItem &param
        ) const -> LSPAny;
        auto anyToCallHierarchyIncomingCallsParams(
            const LSPAny &any
        ) const -> CallHierarchyIncomingCallsParams;
        auto callHierarchyIncomingCallsParamsToAny(
            const CallHierarchyIncomingCallsParams &param
        ) const -> LSPAny;
        auto anyToCallHierarchyIncomingCall(
            const LSPAny &any
        ) const -> CallHierarchyIncomingCall;
        auto callHierarchyIncomingCallToAny(
            const CallHierarchyIncomingCall &param
        ) const -> LSPAny;
        auto anyToCallHierarchyOutgoingCallsParams(
            const LSPAny &any
        ) const -> CallHierarchyOutgoingCallsParams;
        auto callHierarchyOutgoingCallsParamsToAny(
            const CallHierarchyOutgoingCallsParams &param
        ) const -> LSPAny;
        auto anyToCallHierarchyOutgoingCall(
            const LSPAny &any
        ) const -> CallHierarchyOutgoingCall;
        auto callHierarchyOutgoingCallToAny(
            const CallHierarchyOutgoingCall &param
        ) const -> LSPAny;
        auto anyToTypeHierarchyItem(
            const LSPAny &any
        ) const -> TypeHierarchyItem;
        auto typeHierarchyItemToAny(
            const TypeHierarchyItem &param
        ) const -> LSPAny;
        auto anyToTypeHierarchySupertypesParams(
            const LSPAny &any
        ) const -> TypeHierarchySupertypesParams;
        auto typeHierarchySupertypesParamsToAny(
            const TypeHierarchySupertypesParams &param
        ) const -> LSPAny;
        auto anyToTypeHierarchySubtypesParams(
            const LSPAny &any
        ) const -> TypeHierarchySubtypesParams;
        auto typeHierarchySubtypesParamsToAny(
            const TypeHierarchySubtypesParams &param
        ) const -> LSPAny;
        auto anyToDidChangeConfigurationParams(
            const LSPAny &any
        ) const -> DidChangeConfigurationParams;
        auto didChangeConfigurationParamsToAny(
            const DidChangeConfigurationParams &param
        ) const -> LSPAny;
        auto anyToCompletionList_itemDefaults(
            const LSPAny &any
        ) const -> CompletionList_itemDefaults;
        auto completionList_itemDefaultsToAny(
            const CompletionList_itemDefaults &param
        ) const -> LSPAny;
        auto anyToCommand(const LSPAny &any) const -> Command;
        auto commandToAny(const Command &param) const -> LSPAny;
        auto anyToInlineCompletionItem(
            const LSPAny &any
        ) const -> InlineCompletionItem;
        auto inlineCompletionItemToAny(
            const InlineCompletionItem &param
        ) const -> LSPAny;
        auto anyToInlineCompletionList(
            const LSPAny &any
        ) const -> InlineCompletionList;
        auto inlineCompletionListToAny(
            const InlineCompletionList &param
        ) const -> LSPAny;
        auto anyToInlineCompletionList_items(
            const LSPAny &any
        ) const -> InlineCompletionList_items;
        auto inlineCompletionList_itemsToAny(
            const InlineCompletionList_items &array
        ) const -> LSPAny;
        auto anyToCompletionItem(const LSPAny &any) const -> CompletionItem;
        auto completionItemToAny(const CompletionItem &param) const -> LSPAny;
        auto anyToCompletionList(const LSPAny &any) const -> CompletionList;
        auto completionListToAny(const CompletionList &param) const -> LSPAny;
        auto anyToCompletionList_items(
            const LSPAny &any
        ) const -> CompletionList_items;
        auto completionList_itemsToAny(
            const CompletionList_items &array
        ) const -> LSPAny;
        auto anyToCommand_arguments(
            const LSPAny &any
        ) const -> Command_arguments;
        auto command_argumentsToAny(
            const Command_arguments &array
        ) const -> LSPAny;
        auto anyToWorkspaceSymbol(const LSPAny &any) const -> WorkspaceSymbol;
        auto workspaceSymbolToAny(
            const WorkspaceSymbol &param
        ) const -> LSPAny;
        auto anyToCodeLens(const LSPAny &any) const -> CodeLens;
        auto codeLensToAny(const CodeLens &param) const -> LSPAny;
        auto anyToDocumentLink(const LSPAny &any) const -> DocumentLink;
        auto documentLinkToAny(const DocumentLink &param) const -> LSPAny;
        auto anyToExecuteCommandParams(
            const LSPAny &any
        ) const -> ExecuteCommandParams;
        auto executeCommandParamsToAny(
            const ExecuteCommandParams &param
        ) const -> LSPAny;
        auto anyToExecuteCommandParams_arguments(
            const LSPAny &any
        ) const -> ExecuteCommandParams_arguments;
        auto executeCommandParams_argumentsToAny(
            const ExecuteCommandParams_arguments &array
        ) const -> LSPAny;
        auto anyToProgressParams(const LSPAny &any) const -> ProgressParams;
        auto progressParamsToAny(const ProgressParams &param) const -> LSPAny;
        auto anyToInlayHintLabelPart(
            const LSPAny &any
        ) const -> InlayHintLabelPart;
        auto inlayHintLabelPartToAny(
            const InlayHintLabelPart &param
        ) const -> LSPAny;
        auto anyToInlayHint_label(const LSPAny &any) const -> InlayHint_label;
        auto inlayHint_labelToAny(
            const InlayHint_label &param
        ) const -> LSPAny;
        auto anyToInlayHint(const LSPAny &any) const -> InlayHint;
        auto inlayHintToAny(const InlayHint &param) const -> LSPAny;
        auto anyToInlayHint_label_1(
            const LSPAny &any
        ) const -> InlayHint_label_1;
        auto inlayHint_label_1ToAny(
            const InlayHint_label_1 &array
        ) const -> LSPAny;
        auto anyToRegistration(const LSPAny &any) const -> Registration;
        auto registrationToAny(const Registration &param) const -> LSPAny;
        auto anyToRegistrationParams(
            const LSPAny &any
        ) const -> RegistrationParams;
        auto registrationParamsToAny(
            const RegistrationParams &param
        ) const -> LSPAny;
        auto anyToRegistrationParams_registrations(
            const LSPAny &any
        ) const -> RegistrationParams_registrations;
        auto registrationParams_registrationsToAny(
            const RegistrationParams_registrations &array
        ) const -> LSPAny;
        auto anyToServerCapabilities(
            const LSPAny &any
        ) const -> ServerCapabilities;
        auto serverCapabilitiesToAny(
            const ServerCapabilities &param
        ) const -> LSPAny;
        auto anyToInitializeResult(
            const LSPAny &any
        ) const -> InitializeResult;
        auto initializeResultToAny(
            const InitializeResult &param
        ) const -> LSPAny;
        auto anyToDiagnostic(const LSPAny &any) const -> Diagnostic;
        auto diagnosticToAny(const Diagnostic &param) const -> LSPAny;
        auto anyToPublishDiagnosticsParams(
            const LSPAny &any
        ) const -> PublishDiagnosticsParams;
        auto publishDiagnosticsParamsToAny(
            const PublishDiagnosticsParams &param
        ) const -> LSPAny;
        auto anyToPublishDiagnosticsParams_diagnostics(
            const LSPAny &any
        ) const -> PublishDiagnosticsParams_diagnostics;
        auto publishDiagnosticsParams_diagnosticsToAny(
            const PublishDiagnosticsParams_diagnostics &array
        ) const -> LSPAny;
        auto anyToCodeAction(const LSPAny &any) const -> CodeAction;
        auto codeActionToAny(const CodeAction &param) const -> LSPAny;
        auto anyToCodeAction_diagnostics(
            const LSPAny &any
        ) const -> CodeAction_diagnostics;
        auto codeAction_diagnosticsToAny(
            const CodeAction_diagnostics &array
        ) const -> LSPAny;
        auto anyToFullDocumentDiagnosticReport(
            const LSPAny &any
        ) const -> FullDocumentDiagnosticReport;
        auto fullDocumentDiagnosticReportToAny(
            const FullDocumentDiagnosticReport &param
        ) const -> LSPAny;
        auto anyToDocumentDiagnosticReportPartialResult_relatedDocuments_value(
            const LSPAny &any
        ) const -> DocumentDiagnosticReportPartialResult_relatedDocuments_value;
        auto documentDiagnosticReportPartialResult_relatedDocuments_valueToAny(
            const DocumentDiagnosticReportPartialResult_relatedDocuments_value &param
        ) const -> LSPAny;
        auto anyToDocumentDiagnosticReportPartialResult(
            const LSPAny &any
        ) const -> DocumentDiagnosticReportPartialResult;
        auto documentDiagnosticReportPartialResultToAny(
            const DocumentDiagnosticReportPartialResult &param
        ) const -> LSPAny;
        auto anyToDocumentDiagnosticReportPartialResult_relatedDocuments(
            const LSPAny &any
        ) const -> DocumentDiagnosticReportPartialResult_relatedDocuments;
        auto documentDiagnosticReportPartialResult_relatedDocumentsToAny(
            const DocumentDiagnosticReportPartialResult_relatedDocuments &map
        ) const -> LSPAny;
        auto anyToRelatedFullDocumentDiagnosticReport_relatedDocuments_value(
            const LSPAny &any
        ) const -> RelatedFullDocumentDiagnosticReport_relatedDocuments_value;
        auto relatedFullDocumentDiagnosticReport_relatedDocuments_valueToAny(
            const RelatedFullDocumentDiagnosticReport_relatedDocuments_value &param
        ) const -> LSPAny;
        auto anyToRelatedFullDocumentDiagnosticReport(
            const LSPAny &any
        ) const -> RelatedFullDocumentDiagnosticReport;
        auto relatedFullDocumentDiagnosticReportToAny(
            const RelatedFullDocumentDiagnosticReport &param
        ) const -> LSPAny;
        auto anyToRelatedFullDocumentDiagnosticReport_relatedDocuments(
            const LSPAny &any
        ) const -> RelatedFullDocumentDiagnosticReport_relatedDocuments;
        auto relatedFullDocumentDiagnosticReport_relatedDocumentsToAny(
            const RelatedFullDocumentDiagnosticReport_relatedDocuments &map
        ) const -> LSPAny;
        auto anyToRelatedUnchangedDocumentDiagnosticReport_relatedDocuments_value(
            const LSPAny &any
        ) const -> RelatedUnchangedDocumentDiagnosticReport_relatedDocuments_value;
        auto relatedUnchangedDocumentDiagnosticReport_relatedDocuments_valueToAny(
            const RelatedUnchangedDocumentDiagnosticReport_relatedDocuments_value &param
        ) const -> LSPAny;
        auto anyToRelatedUnchangedDocumentDiagnosticReport(
            const LSPAny &any
        ) const -> RelatedUnchangedDocumentDiagnosticReport;
        auto relatedUnchangedDocumentDiagnosticReportToAny(
            const RelatedUnchangedDocumentDiagnosticReport &param
        ) const -> LSPAny;
        auto anyToRelatedUnchangedDocumentDiagnosticReport_relatedDocuments(
            const LSPAny &any
        ) const -> RelatedUnchangedDocumentDiagnosticReport_relatedDocuments;
        auto relatedUnchangedDocumentDiagnosticReport_relatedDocumentsToAny(
            const RelatedUnchangedDocumentDiagnosticReport_relatedDocuments &map
        ) const -> LSPAny;
        auto anyToFullDocumentDiagnosticReport_items(
            const LSPAny &any
        ) const -> FullDocumentDiagnosticReport_items;
        auto fullDocumentDiagnosticReport_itemsToAny(
            const FullDocumentDiagnosticReport_items &array
        ) const -> LSPAny;
        auto anyToCodeActionContext(
            const LSPAny &any
        ) const -> CodeActionContext;
        auto codeActionContextToAny(
            const CodeActionContext &param
        ) const -> LSPAny;
        auto anyToCodeActionParams(
            const LSPAny &any
        ) const -> CodeActionParams;
        auto codeActionParamsToAny(
            const CodeActionParams &param
        ) const -> LSPAny;
        auto anyToCodeActionContext_diagnostics(
            const LSPAny &any
        ) const -> CodeActionContext_diagnostics;
        auto codeActionContext_diagnosticsToAny(
            const CodeActionContext_diagnostics &array
        ) const -> LSPAny;
        auto anyToWorkspaceFullDocumentDiagnosticReport(
            const LSPAny &any
        ) const -> WorkspaceFullDocumentDiagnosticReport;
        auto workspaceFullDocumentDiagnosticReportToAny(
            const WorkspaceFullDocumentDiagnosticReport &param
        ) const -> LSPAny;
        auto anyToNotebookCell(const LSPAny &any) const -> NotebookCell;
        auto notebookCellToAny(const NotebookCell &param) const -> LSPAny;
        auto anyToNotebookDocument(
            const LSPAny &any
        ) const -> NotebookDocument;
        auto notebookDocumentToAny(
            const NotebookDocument &param
        ) const -> LSPAny;
        auto anyToDidOpenNotebookDocumentParams(
            const LSPAny &any
        ) const -> DidOpenNotebookDocumentParams;
        auto didOpenNotebookDocumentParamsToAny(
            const DidOpenNotebookDocumentParams &param
        ) const -> LSPAny;
        auto anyToNotebookDocument_cells(
            const LSPAny &any
        ) const -> NotebookDocument_cells;
        auto notebookDocument_cellsToAny(
            const NotebookDocument_cells &array
        ) const -> LSPAny;
        auto anyToNotebookDocumentChangeEvent_cells_data(
            const LSPAny &any
        ) const -> NotebookDocumentChangeEvent_cells_data;
        auto notebookDocumentChangeEvent_cells_dataToAny(
            const NotebookDocumentChangeEvent_cells_data &array
        ) const -> LSPAny;
        auto anyToNotebookCellArrayChange(
            const LSPAny &any
        ) const -> NotebookCellArrayChange;
        auto notebookCellArrayChangeToAny(
            const NotebookCellArrayChange &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentChangeEvent_cells_structure(
            const LSPAny &any
        ) const -> NotebookDocumentChangeEvent_cells_structure;
        auto notebookDocumentChangeEvent_cells_structureToAny(
            const NotebookDocumentChangeEvent_cells_structure &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentChangeEvent_cells(
            const LSPAny &any
        ) const -> NotebookDocumentChangeEvent_cells;
        auto notebookDocumentChangeEvent_cellsToAny(
            const NotebookDocumentChangeEvent_cells &param
        ) const -> LSPAny;
        auto anyToNotebookDocumentChangeEvent(
            const LSPAny &any
        ) const -> NotebookDocumentChangeEvent;
        auto notebookDocumentChangeEventToAny(
            const NotebookDocumentChangeEvent &param
        ) const -> LSPAny;
        auto anyToDidChangeNotebookDocumentParams(
            const LSPAny &any
        ) const -> DidChangeNotebookDocumentParams;
        auto didChangeNotebookDocumentParamsToAny(
            const DidChangeNotebookDocumentParams &param
        ) const -> LSPAny;
        auto anyToNotebookCellArrayChange_cells(
            const LSPAny &any
        ) const -> NotebookCellArrayChange_cells;
        auto notebookCellArrayChange_cellsToAny(
            const NotebookCellArrayChange_cells &array
        ) const -> LSPAny;
        auto anyToClientCapabilities(
            const LSPAny &any
        ) const -> ClientCapabilities;
        auto clientCapabilitiesToAny(
            const ClientCapabilities &param
        ) const -> LSPAny;
        auto anyTo_InitializeParams(
            const LSPAny &any
        ) const -> _InitializeParams;
        auto _InitializeParamsToAny(
            const _InitializeParams &param
        ) const -> LSPAny;
        auto anyToInitializeParams(
            const LSPAny &any
        ) const -> InitializeParams;
        auto initializeParamsToAny(
            const InitializeParams &param
        ) const -> LSPAny;
        auto anyToResponseError(const LSPAny &any) const -> ResponseError;
        auto responseErrorToAny(const ResponseError &param) const -> LSPAny;
        auto anyToResponseMessage(const LSPAny &any) const -> ResponseMessage;
        auto responseMessageToAny(
            const ResponseMessage &param
        ) const -> LSPAny;
        auto asNotebookDocument_DidOpenParams(
            const MessageParams &notificationParams
        ) const -> DidOpenNotebookDocumentParams;
        auto asNotebookDocument_DidChangeParams(
            const MessageParams &notificationParams
        ) const -> DidChangeNotebookDocumentParams;
        auto anyToDocumentDiagnosticReport(
            const LSPAny &any
        ) const -> DocumentDiagnosticReport;
        auto documentDiagnosticReportToAny(
            const DocumentDiagnosticReport &param
        ) const -> LSPAny;
        auto anyToWorkspaceDocumentDiagnosticReport(
            const LSPAny &any
        ) const -> WorkspaceDocumentDiagnosticReport;
        auto workspaceDocumentDiagnosticReportToAny(
            const WorkspaceDocumentDiagnosticReport &param
        ) const -> LSPAny;
        auto anyToWorkspaceDiagnosticReport(
            const LSPAny &any
        ) const -> WorkspaceDiagnosticReport;
        auto workspaceDiagnosticReportToAny(
            const WorkspaceDiagnosticReport &param
        ) const -> LSPAny;
        auto anyToWorkspaceDiagnosticReport_items(
            const LSPAny &any
        ) const -> WorkspaceDiagnosticReport_items;
        auto workspaceDiagnosticReport_itemsToAny(
            const WorkspaceDiagnosticReport_items &array
        ) const -> LSPAny;
        auto anyToWorkspaceDiagnosticReportPartialResult(
            const LSPAny &any
        ) const -> WorkspaceDiagnosticReportPartialResult;
        auto workspaceDiagnosticReportPartialResultToAny(
            const WorkspaceDiagnosticReportPartialResult &param
        ) const -> LSPAny;
        auto anyToWorkspaceDiagnosticReportPartialResult_items(
            const LSPAny &any
        ) const -> WorkspaceDiagnosticReportPartialResult_items;
        auto workspaceDiagnosticReportPartialResult_itemsToAny(
            const WorkspaceDiagnosticReportPartialResult_items &array
        ) const -> LSPAny;
        auto anyToMessageParams(const LSPAny &any) const -> MessageParams;
        auto messageParamsToAny(const MessageParams &param) const -> LSPAny;
        auto anyToRequestMessage(const LSPAny &any) const -> RequestMessage;
        auto requestMessageToAny(const RequestMessage &param) const -> LSPAny;
        auto anyToNotificationMessage(
            const LSPAny &any
        ) const -> NotificationMessage;
        auto notificationMessageToAny(
            const NotificationMessage &param
        ) const -> LSPAny;
        auto anyToWorkspace_ConfigurationResult(
            const LSPAny &any
        ) const -> Workspace_ConfigurationResult;
        auto workspace_ConfigurationResultToAny(
            const Workspace_ConfigurationResult &array
        ) const -> LSPAny;
        auto asMessageParams(
            const ConfigurationParams &requestParams
        ) const -> MessageParams;
        auto anyToTextDocument_PrepareCallHierarchyResult(
            const LSPAny &any
        ) const -> TextDocument_PrepareCallHierarchyResult;
        auto textDocument_PrepareCallHierarchyResultToAny(
            const TextDocument_PrepareCallHierarchyResult &param
        ) const -> LSPAny;
        auto asTextDocument_PrepareCallHierarchyParams(
            const MessageParams &requestParams
        ) const -> CallHierarchyPrepareParams;
        auto anyToTextDocument_PrepareCallHierarchyResult_0(
            const LSPAny &any
        ) const -> TextDocument_PrepareCallHierarchyResult_0;
        auto textDocument_PrepareCallHierarchyResult_0ToAny(
            const TextDocument_PrepareCallHierarchyResult_0 &array
        ) const -> LSPAny;
        auto anyToCallHierarchy_IncomingCallsResult(
            const LSPAny &any
        ) const -> CallHierarchy_IncomingCallsResult;
        auto callHierarchy_IncomingCallsResultToAny(
            const CallHierarchy_IncomingCallsResult &param
        ) const -> LSPAny;
        auto asCallHierarchy_IncomingCallsParams(
            const MessageParams &requestParams
        ) const -> CallHierarchyIncomingCallsParams;
        auto anyToCallHierarchy_IncomingCallsResult_0(
            const LSPAny &any
        ) const -> CallHierarchy_IncomingCallsResult_0;
        auto callHierarchy_IncomingCallsResult_0ToAny(
            const CallHierarchy_IncomingCallsResult_0 &array
        ) const -> LSPAny;
        auto anyToCallHierarchy_OutgoingCallsResult(
            const LSPAny &any
        ) const -> CallHierarchy_OutgoingCallsResult;
        auto callHierarchy_OutgoingCallsResultToAny(
            const CallHierarchy_OutgoingCallsResult &param
        ) const -> LSPAny;
        auto asCallHierarchy_OutgoingCallsParams(
            const MessageParams &requestParams
        ) const -> CallHierarchyOutgoingCallsParams;
        auto anyToCallHierarchy_OutgoingCallsResult_0(
            const LSPAny &any
        ) const -> CallHierarchy_OutgoingCallsResult_0;
        auto callHierarchy_OutgoingCallsResult_0ToAny(
            const CallHierarchy_OutgoingCallsResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_PrepareTypeHierarchyResult(
            const LSPAny &any
        ) const -> TextDocument_PrepareTypeHierarchyResult;
        auto textDocument_PrepareTypeHierarchyResultToAny(
            const TextDocument_PrepareTypeHierarchyResult &param
        ) const -> LSPAny;
        auto asTextDocument_PrepareTypeHierarchyParams(
            const MessageParams &requestParams
        ) const -> TypeHierarchyPrepareParams;
        auto anyToTextDocument_PrepareTypeHierarchyResult_0(
            const LSPAny &any
        ) const -> TextDocument_PrepareTypeHierarchyResult_0;
        auto textDocument_PrepareTypeHierarchyResult_0ToAny(
            const TextDocument_PrepareTypeHierarchyResult_0 &array
        ) const -> LSPAny;
        auto anyToTypeHierarchy_SupertypesResult(
            const LSPAny &any
        ) const -> TypeHierarchy_SupertypesResult;
        auto typeHierarchy_SupertypesResultToAny(
            const TypeHierarchy_SupertypesResult &param
        ) const -> LSPAny;
        auto asTypeHierarchy_SupertypesParams(
            const MessageParams &requestParams
        ) const -> TypeHierarchySupertypesParams;
        auto anyToTypeHierarchy_SupertypesResult_0(
            const LSPAny &any
        ) const -> TypeHierarchy_SupertypesResult_0;
        auto typeHierarchy_SupertypesResult_0ToAny(
            const TypeHierarchy_SupertypesResult_0 &array
        ) const -> LSPAny;
        auto anyToTypeHierarchy_SubtypesResult(
            const LSPAny &any
        ) const -> TypeHierarchy_SubtypesResult;
        auto typeHierarchy_SubtypesResultToAny(
            const TypeHierarchy_SubtypesResult &param
        ) const -> LSPAny;
        auto asTypeHierarchy_SubtypesParams(
            const MessageParams &requestParams
        ) const -> TypeHierarchySubtypesParams;
        auto anyToTypeHierarchy_SubtypesResult_0(
            const LSPAny &any
        ) const -> TypeHierarchy_SubtypesResult_0;
        auto typeHierarchy_SubtypesResult_0ToAny(
            const TypeHierarchy_SubtypesResult_0 &array
        ) const -> LSPAny;
        auto anyToTextDocument_InlayHintResult(
            const LSPAny &any
        ) const -> TextDocument_InlayHintResult;
        auto textDocument_InlayHintResultToAny(
            const TextDocument_InlayHintResult &param
        ) const -> LSPAny;
        auto asTextDocument_InlayHintParams(
            const MessageParams &requestParams
        ) const -> InlayHintParams;
        auto anyToTextDocument_InlayHintResult_0(
            const LSPAny &any
        ) const -> TextDocument_InlayHintResult_0;
        auto textDocument_InlayHintResult_0ToAny(
            const TextDocument_InlayHintResult_0 &array
        ) const -> LSPAny;
        auto anyToInlayHint_ResolveResult(
            const LSPAny &any
        ) const -> InlayHint_ResolveResult;
        auto inlayHint_ResolveResultToAny(
            const InlayHint_ResolveResult &param
        ) const -> LSPAny;
        auto asInlayHint_ResolveParams(
            const MessageParams &requestParams
        ) const -> InlayHint;
        auto anyToTextDocument_DiagnosticResult(
            const LSPAny &any
        ) const -> TextDocument_DiagnosticResult;
        auto textDocument_DiagnosticResultToAny(
            const TextDocument_DiagnosticResult &param
        ) const -> LSPAny;
        auto asTextDocument_DiagnosticParams(
            const MessageParams &requestParams
        ) const -> DocumentDiagnosticParams;
        auto anyToWorkspace_DiagnosticResult(
            const LSPAny &any
        ) const -> Workspace_DiagnosticResult;
        auto workspace_DiagnosticResultToAny(
            const Workspace_DiagnosticResult &param
        ) const -> LSPAny;
        auto asWorkspace_DiagnosticParams(
            const MessageParams &requestParams
        ) const -> WorkspaceDiagnosticParams;
        auto anyToTextDocument_InlineCompletionResult(
            const LSPAny &any
        ) const -> TextDocument_InlineCompletionResult;
        auto textDocument_InlineCompletionResultToAny(
            const TextDocument_InlineCompletionResult &param
        ) const -> LSPAny;
        auto asTextDocument_InlineCompletionParams(
            const MessageParams &requestParams
        ) const -> InlineCompletionParams;
        auto anyToTextDocument_InlineCompletionResult_1(
            const LSPAny &any
        ) const -> TextDocument_InlineCompletionResult_1;
        auto textDocument_InlineCompletionResult_1ToAny(
            const TextDocument_InlineCompletionResult_1 &array
        ) const -> LSPAny;
        auto asMessageParams(
            const RegistrationParams &requestParams
        ) const -> MessageParams;
        auto asInitializeParams(
            const MessageParams &requestParams
        ) const -> InitializeParams;
        auto anyToTextDocument_CompletionResult(
            const LSPAny &any
        ) const -> TextDocument_CompletionResult;
        auto textDocument_CompletionResultToAny(
            const TextDocument_CompletionResult &param
        ) const -> LSPAny;
        auto asTextDocument_CompletionParams(
            const MessageParams &requestParams
        ) const -> CompletionParams;
        auto anyToTextDocument_CompletionResult_0(
            const LSPAny &any
        ) const -> TextDocument_CompletionResult_0;
        auto textDocument_CompletionResult_0ToAny(
            const TextDocument_CompletionResult_0 &array
        ) const -> LSPAny;
        auto anyToCompletionItem_ResolveResult(
            const LSPAny &any
        ) const -> CompletionItem_ResolveResult;
        auto completionItem_ResolveResultToAny(
            const CompletionItem_ResolveResult &param
        ) const -> LSPAny;
        auto asCompletionItem_ResolveParams(
            const MessageParams &requestParams
        ) const -> CompletionItem;
        auto anyToTextDocument_CodeActionResult_0_elem(
            const LSPAny &any
        ) const -> TextDocument_CodeActionResult_0_elem;
        auto textDocument_CodeActionResult_0_elemToAny(
            const TextDocument_CodeActionResult_0_elem &param
        ) const -> LSPAny;
        auto anyToTextDocument_CodeActionResult(
            const LSPAny &any
        ) const -> TextDocument_CodeActionResult;
        auto textDocument_CodeActionResultToAny(
            const TextDocument_CodeActionResult &param
        ) const -> LSPAny;
        auto asTextDocument_CodeActionParams(
            const MessageParams &requestParams
        ) const -> CodeActionParams;
        auto anyToTextDocument_CodeActionResult_0(
            const LSPAny &any
        ) const -> TextDocument_CodeActionResult_0;
        auto textDocument_CodeActionResult_0ToAny(
            const TextDocument_CodeActionResult_0 &array
        ) const -> LSPAny;
        auto anyToCodeAction_ResolveResult(
            const LSPAny &any
        ) const -> CodeAction_ResolveResult;
        auto codeAction_ResolveResultToAny(
            const CodeAction_ResolveResult &param
        ) const -> LSPAny;
        auto asCodeAction_ResolveParams(
            const MessageParams &requestParams
        ) const -> CodeAction;
        auto anyToWorkspace_SymbolResult(
            const LSPAny &any
        ) const -> Workspace_SymbolResult;
        auto workspace_SymbolResultToAny(
            const Workspace_SymbolResult &param
        ) const -> LSPAny;
        auto asWorkspace_SymbolParams(
            const MessageParams &requestParams
        ) const -> WorkspaceSymbolParams;
        auto anyToWorkspace_SymbolResult_1(
            const LSPAny &any
        ) const -> Workspace_SymbolResult_1;
        auto workspace_SymbolResult_1ToAny(
            const Workspace_SymbolResult_1 &array
        ) const -> LSPAny;
        auto anyToWorkspaceSymbol_ResolveResult(
            const LSPAny &any
        ) const -> WorkspaceSymbol_ResolveResult;
        auto workspaceSymbol_ResolveResultToAny(
            const WorkspaceSymbol_ResolveResult &param
        ) const -> LSPAny;
        auto asWorkspaceSymbol_ResolveParams(
            const MessageParams &requestParams
        ) const -> WorkspaceSymbol;
        auto anyToTextDocument_CodeLensResult(
            const LSPAny &any
        ) const -> TextDocument_CodeLensResult;
        auto textDocument_CodeLensResultToAny(
            const TextDocument_CodeLensResult &param
        ) const -> LSPAny;
        auto asTextDocument_CodeLensParams(
            const MessageParams &requestParams
        ) const -> CodeLensParams;
        auto anyToTextDocument_CodeLensResult_0(
            const LSPAny &any
        ) const -> TextDocument_CodeLensResult_0;
        auto textDocument_CodeLensResult_0ToAny(
            const TextDocument_CodeLensResult_0 &array
        ) const -> LSPAny;
        auto anyToCodeLens_ResolveResult(
            const LSPAny &any
        ) const -> CodeLens_ResolveResult;
        auto codeLens_ResolveResultToAny(
            const CodeLens_ResolveResult &param
        ) const -> LSPAny;
        auto asCodeLens_ResolveParams(
            const MessageParams &requestParams
        ) const -> CodeLens;
        auto anyToTextDocument_DocumentLinkResult(
            const LSPAny &any
        ) const -> TextDocument_DocumentLinkResult;
        auto textDocument_DocumentLinkResultToAny(
            const TextDocument_DocumentLinkResult &param
        ) const -> LSPAny;
        auto asTextDocument_DocumentLinkParams(
            const MessageParams &requestParams
        ) const -> DocumentLinkParams;
        auto anyToTextDocument_DocumentLinkResult_0(
            const LSPAny &any
        ) const -> TextDocument_DocumentLinkResult_0;
        auto textDocument_DocumentLinkResult_0ToAny(
            const TextDocument_DocumentLinkResult_0 &array
        ) const -> LSPAny;
        auto anyToDocumentLink_ResolveResult(
            const LSPAny &any
        ) const -> DocumentLink_ResolveResult;
        auto documentLink_ResolveResultToAny(
            const DocumentLink_ResolveResult &param
        ) const -> LSPAny;
        auto asDocumentLink_ResolveParams(
            const MessageParams &requestParams
        ) const -> DocumentLink;
        auto anyToWorkspace_ExecuteCommandResult(
            const LSPAny &any
        ) const -> Workspace_ExecuteCommandResult;
        auto workspace_ExecuteCommandResultToAny(
            const Workspace_ExecuteCommandResult &param
        ) const -> LSPAny;
        auto asWorkspace_ExecuteCommandParams(
            const MessageParams &requestParams
        ) const -> ExecuteCommandParams;
        auto anyToTelemetryResult(const LSPAny &any) const -> TelemetryResult;
        auto telemetryResultToAny(
            const TelemetryResult &param
        ) const -> LSPAny;
        auto asWorkspace_DidChangeConfigurationParams(
            const MessageParams &notificationParams
        ) const -> DidChangeConfigurationParams;
        auto asMessageParams(
            const LSPAny &notificationParams
        ) const -> MessageParams;
        auto asMessageParams(
            const PublishDiagnosticsParams &notificationParams
        ) const -> MessageParams;
        auto asProgressParams(
            const MessageParams &notificationParams
        ) const -> ProgressParams;
        auto asMessageParams(
            const ProgressParams &notificationParams
        ) const -> MessageParams;
        auto copy(const LSPAny &any) const -> LSPAny;
        auto copy(
            const std::unique_ptr<LSPAny> &any
        ) const -> std::unique_ptr<LSPAny>;
        auto copy(const LSPObject &object) const -> LSPObject;
        auto copy(const LSPArray &array) const -> LSPArray;
    }; // class LspTransformer

} // namespace LCompilers::LanguageServerProtocol
