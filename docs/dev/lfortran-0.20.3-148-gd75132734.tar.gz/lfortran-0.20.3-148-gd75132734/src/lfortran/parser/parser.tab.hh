/* A Bison parser, made by GNU Bison 3.4.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy"

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh"

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_LABEL = 262,
    TK_REAL = 263,
    TK_BOZ_CONSTANT = 264,
    TK_PLUS = 265,
    TK_MINUS = 266,
    TK_STAR = 267,
    TK_SLASH = 268,
    TK_COLON = 269,
    TK_SEMICOLON = 270,
    TK_COMMA = 271,
    TK_EQUAL = 272,
    TK_LPAREN = 273,
    TK_RPAREN = 274,
    TK_LBRACKET = 275,
    TK_RBRACKET = 276,
    TK_LBRACE = 277,
    TK_RBRACE = 278,
    TK_RBRACKET_OLD = 279,
    TK_PERCENT = 280,
    TK_VBAR = 281,
    TK_STRING = 282,
    TK_COMMENT = 283,
    TK_EOLCOMMENT = 284,
    TK_DBL_DOT = 285,
    TK_DBL_COLON = 286,
    TK_POW = 287,
    TK_CONCAT = 288,
    TK_ARROW = 289,
    TK_EQ = 290,
    TK_NE = 291,
    TK_LT = 292,
    TK_LE = 293,
    TK_GT = 294,
    TK_GE = 295,
    TK_NOT = 296,
    TK_AND = 297,
    TK_OR = 298,
    TK_XOR = 299,
    TK_EQV = 300,
    TK_NEQV = 301,
    TK_TRUE = 302,
    TK_FALSE = 303,
    TK_FORMAT = 304,
    KW_ABSTRACT = 305,
    KW_ALL = 306,
    KW_ALLOCATABLE = 307,
    KW_ALLOCATE = 308,
    KW_ASSIGN = 309,
    KW_ASSIGNMENT = 310,
    KW_ASSOCIATE = 311,
    KW_ASYNCHRONOUS = 312,
    KW_BACKSPACE = 313,
    KW_BIND = 314,
    KW_BLOCK = 315,
    KW_CALL = 316,
    KW_CASE = 317,
    KW_CHANGE = 318,
    KW_CHANGE_TEAM = 319,
    KW_CHARACTER = 320,
    KW_CLASS = 321,
    KW_CLOSE = 322,
    KW_CODIMENSION = 323,
    KW_COMMON = 324,
    KW_COMPLEX = 325,
    KW_CONCURRENT = 326,
    KW_CONTAINS = 327,
    KW_CONTIGUOUS = 328,
    KW_CONTINUE = 329,
    KW_CRITICAL = 330,
    KW_CYCLE = 331,
    KW_DATA = 332,
    KW_DEALLOCATE = 333,
    KW_DEFAULT = 334,
    KW_DEFERRED = 335,
    KW_DIMENSION = 336,
    KW_DO = 337,
    KW_DOWHILE = 338,
    KW_DOUBLE = 339,
    KW_DOUBLE_PRECISION = 340,
    KW_DOUBLE_COMPLEX = 341,
    KW_ELEMENTAL = 342,
    KW_ELSE = 343,
    KW_ELSEIF = 344,
    KW_ELSEWHERE = 345,
    KW_END = 346,
    KW_END_PROGRAM = 347,
    KW_ENDPROGRAM = 348,
    KW_END_MODULE = 349,
    KW_ENDMODULE = 350,
    KW_END_SUBMODULE = 351,
    KW_ENDSUBMODULE = 352,
    KW_END_BLOCK = 353,
    KW_ENDBLOCK = 354,
    KW_END_BLOCK_DATA = 355,
    KW_ENDBLOCKDATA = 356,
    KW_END_SUBROUTINE = 357,
    KW_ENDSUBROUTINE = 358,
    KW_END_FUNCTION = 359,
    KW_ENDFUNCTION = 360,
    KW_END_PROCEDURE = 361,
    KW_ENDPROCEDURE = 362,
    KW_END_ENUM = 363,
    KW_ENDENUM = 364,
    KW_END_SELECT = 365,
    KW_ENDSELECT = 366,
    KW_END_IF = 367,
    KW_ENDIF = 368,
    KW_END_INTERFACE = 369,
    KW_ENDINTERFACE = 370,
    KW_END_TYPE = 371,
    KW_ENDTYPE = 372,
    KW_END_ASSOCIATE = 373,
    KW_ENDASSOCIATE = 374,
    KW_END_FORALL = 375,
    KW_ENDFORALL = 376,
    KW_END_DO = 377,
    KW_ENDDO = 378,
    KW_END_WHERE = 379,
    KW_ENDWHERE = 380,
    KW_END_CRITICAL = 381,
    KW_ENDCRITICAL = 382,
    KW_END_FILE = 383,
    KW_ENDFILE = 384,
    KW_END_TEAM = 385,
    KW_ENDTEAM = 386,
    KW_ENTRY = 387,
    KW_ENUM = 388,
    KW_ENUMERATOR = 389,
    KW_EQUIVALENCE = 390,
    KW_ERRMSG = 391,
    KW_ERROR = 392,
    KW_EVENT = 393,
    KW_EXIT = 394,
    KW_EXTENDS = 395,
    KW_EXTERNAL = 396,
    KW_FILE = 397,
    KW_FINAL = 398,
    KW_FLUSH = 399,
    KW_FORALL = 400,
    KW_FORMATTED = 401,
    KW_FORM = 402,
    KW_FORM_TEAM = 403,
    KW_FUNCTION = 404,
    KW_GENERIC = 405,
    KW_GO = 406,
    KW_GOTO = 407,
    KW_IF = 408,
    KW_IMAGES = 409,
    KW_IMPLICIT = 410,
    KW_IMPORT = 411,
    KW_IMPURE = 412,
    KW_IN = 413,
    KW_INCLUDE = 414,
    KW_INOUT = 415,
    KW_IN_OUT = 416,
    KW_INQUIRE = 417,
    KW_INSTANTIATE = 418,
    KW_INTEGER = 419,
    KW_INTENT = 420,
    KW_INTERFACE = 421,
    KW_INTRINSIC = 422,
    KW_IS = 423,
    KW_KIND = 424,
    KW_LEN = 425,
    KW_LOCAL = 426,
    KW_LOCAL_INIT = 427,
    KW_LOGICAL = 428,
    KW_MEMORY = 429,
    KW_MODULE = 430,
    KW_MOLD = 431,
    KW_NAME = 432,
    KW_NAMELIST = 433,
    KW_NEW_INDEX = 434,
    KW_NOPASS = 435,
    KW_NON_INTRINSIC = 436,
    KW_NON_OVERRIDABLE = 437,
    KW_NON_RECURSIVE = 438,
    KW_NONE = 439,
    KW_NULLIFY = 440,
    KW_ONLY = 441,
    KW_OPEN = 442,
    KW_OPERATOR = 443,
    KW_OPTIONAL = 444,
    KW_OUT = 445,
    KW_PARAMETER = 446,
    KW_PASS = 447,
    KW_POINTER = 448,
    KW_POST = 449,
    KW_PRECISION = 450,
    KW_PRINT = 451,
    KW_PRIVATE = 452,
    KW_PROCEDURE = 453,
    KW_PROGRAM = 454,
    KW_PROTECTED = 455,
    KW_PUBLIC = 456,
    KW_PURE = 457,
    KW_QUIET = 458,
    KW_RANK = 459,
    KW_READ = 460,
    KW_REAL = 461,
    KW_RECURSIVE = 462,
    KW_REDUCE = 463,
    KW_RESULT = 464,
    KW_RETURN = 465,
    KW_REWIND = 466,
    KW_SAVE = 467,
    KW_SELECT = 468,
    KW_SELECT_CASE = 469,
    KW_SELECT_RANK = 470,
    KW_SELECT_TYPE = 471,
    KW_SEQUENCE = 472,
    KW_SHARED = 473,
    KW_SOURCE = 474,
    KW_STAT = 475,
    KW_STOP = 476,
    KW_SUBMODULE = 477,
    KW_SUBROUTINE = 478,
    KW_SYNC = 479,
    KW_SYNC_ALL = 480,
    KW_SYNC_IMAGES = 481,
    KW_SYNC_MEMORY = 482,
    KW_SYNC_TEAM = 483,
    KW_TARGET = 484,
    KW_TEAM = 485,
    KW_TEAM_NUMBER = 486,
    KW_REQUIREMENT = 487,
    KW_REQUIRES = 488,
    KW_TEMPLATE = 489,
    KW_THEN = 490,
    KW_TO = 491,
    KW_TYPE = 492,
    KW_UNFORMATTED = 493,
    KW_USE = 494,
    KW_VALUE = 495,
    KW_VOLATILE = 496,
    KW_WAIT = 497,
    KW_WHERE = 498,
    KW_WHILE = 499,
    KW_WRITE = 500,
    UMINUS = 501
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LCompilers::LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LCompilers::LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
