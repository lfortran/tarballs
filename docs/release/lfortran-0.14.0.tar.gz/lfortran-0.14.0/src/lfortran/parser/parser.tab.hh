/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_LABEL = 262,
    TK_REAL = 263,
    TK_BOZ_CONSTANT = 264,
    TK_PLUS = 265,
    TK_MINUS = 266,
    TK_STAR = 267,
    TK_SLASH = 268,
    TK_COLON = 269,
    TK_SEMICOLON = 270,
    TK_COMMA = 271,
    TK_EQUAL = 272,
    TK_LPAREN = 273,
    TK_RPAREN = 274,
    TK_LBRACKET = 275,
    TK_RBRACKET = 276,
    TK_RBRACKET_OLD = 277,
    TK_PERCENT = 278,
    TK_VBAR = 279,
    TK_STRING = 280,
    TK_COMMENT = 281,
    TK_EOLCOMMENT = 282,
    TK_DBL_DOT = 283,
    TK_DBL_COLON = 284,
    TK_POW = 285,
    TK_CONCAT = 286,
    TK_ARROW = 287,
    TK_EQ = 288,
    TK_NE = 289,
    TK_LT = 290,
    TK_LE = 291,
    TK_GT = 292,
    TK_GE = 293,
    TK_NOT = 294,
    TK_AND = 295,
    TK_OR = 296,
    TK_EQV = 297,
    TK_NEQV = 298,
    TK_TRUE = 299,
    TK_FALSE = 300,
    TK_FORMAT = 301,
    KW_ABSTRACT = 302,
    KW_ALL = 303,
    KW_ALLOCATABLE = 304,
    KW_ALLOCATE = 305,
    KW_ASSIGN = 306,
    KW_ASSIGNMENT = 307,
    KW_ASSOCIATE = 308,
    KW_ASYNCHRONOUS = 309,
    KW_BACKSPACE = 310,
    KW_BIND = 311,
    KW_BLOCK = 312,
    KW_CALL = 313,
    KW_CASE = 314,
    KW_CHANGE = 315,
    KW_CHANGE_TEAM = 316,
    KW_CHARACTER = 317,
    KW_CLASS = 318,
    KW_CLOSE = 319,
    KW_CODIMENSION = 320,
    KW_COMMON = 321,
    KW_COMPLEX = 322,
    KW_CONCURRENT = 323,
    KW_CONTAINS = 324,
    KW_CONTIGUOUS = 325,
    KW_CONTINUE = 326,
    KW_CRITICAL = 327,
    KW_CYCLE = 328,
    KW_DATA = 329,
    KW_DEALLOCATE = 330,
    KW_DEFAULT = 331,
    KW_DEFERRED = 332,
    KW_DIMENSION = 333,
    KW_DO = 334,
    KW_DOWHILE = 335,
    KW_DOUBLE = 336,
    KW_DOUBLE_PRECISION = 337,
    KW_ELEMENTAL = 338,
    KW_ELSE = 339,
    KW_ELSEIF = 340,
    KW_ELSEWHERE = 341,
    KW_END = 342,
    KW_END_PROGRAM = 343,
    KW_ENDPROGRAM = 344,
    KW_END_MODULE = 345,
    KW_ENDMODULE = 346,
    KW_END_SUBMODULE = 347,
    KW_ENDSUBMODULE = 348,
    KW_END_BLOCK = 349,
    KW_ENDBLOCK = 350,
    KW_END_BLOCK_DATA = 351,
    KW_ENDBLOCKDATA = 352,
    KW_END_SUBROUTINE = 353,
    KW_ENDSUBROUTINE = 354,
    KW_END_FUNCTION = 355,
    KW_ENDFUNCTION = 356,
    KW_END_PROCEDURE = 357,
    KW_ENDPROCEDURE = 358,
    KW_END_ENUM = 359,
    KW_ENDENUM = 360,
    KW_END_SELECT = 361,
    KW_ENDSELECT = 362,
    KW_END_IF = 363,
    KW_ENDIF = 364,
    KW_END_INTERFACE = 365,
    KW_ENDINTERFACE = 366,
    KW_END_TYPE = 367,
    KW_ENDTYPE = 368,
    KW_END_ASSOCIATE = 369,
    KW_ENDASSOCIATE = 370,
    KW_END_FORALL = 371,
    KW_ENDFORALL = 372,
    KW_END_DO = 373,
    KW_ENDDO = 374,
    KW_END_WHERE = 375,
    KW_ENDWHERE = 376,
    KW_END_CRITICAL = 377,
    KW_ENDCRITICAL = 378,
    KW_END_FILE = 379,
    KW_ENDFILE = 380,
    KW_END_TEAM = 381,
    KW_ENDTEAM = 382,
    KW_ENTRY = 383,
    KW_ENUM = 384,
    KW_ENUMERATOR = 385,
    KW_EQUIVALENCE = 386,
    KW_ERRMSG = 387,
    KW_ERROR = 388,
    KW_EVENT = 389,
    KW_EXIT = 390,
    KW_EXTENDS = 391,
    KW_EXTERNAL = 392,
    KW_FILE = 393,
    KW_FINAL = 394,
    KW_FLUSH = 395,
    KW_FORALL = 396,
    KW_FORMATTED = 397,
    KW_FORM = 398,
    KW_FORM_TEAM = 399,
    KW_FUNCTION = 400,
    KW_GENERIC = 401,
    KW_GO = 402,
    KW_GOTO = 403,
    KW_IF = 404,
    KW_IMAGES = 405,
    KW_IMPLICIT = 406,
    KW_IMPORT = 407,
    KW_IMPURE = 408,
    KW_IN = 409,
    KW_INCLUDE = 410,
    KW_INOUT = 411,
    KW_IN_OUT = 412,
    KW_INQUIRE = 413,
    KW_INTEGER = 414,
    KW_INTENT = 415,
    KW_INTERFACE = 416,
    KW_INTRINSIC = 417,
    KW_IS = 418,
    KW_KIND = 419,
    KW_LEN = 420,
    KW_LOCAL = 421,
    KW_LOCAL_INIT = 422,
    KW_LOGICAL = 423,
    KW_MEMORY = 424,
    KW_MODULE = 425,
    KW_MOLD = 426,
    KW_NAME = 427,
    KW_NAMELIST = 428,
    KW_NEW_INDEX = 429,
    KW_NOPASS = 430,
    KW_NON_INTRINSIC = 431,
    KW_NON_OVERRIDABLE = 432,
    KW_NON_RECURSIVE = 433,
    KW_NONE = 434,
    KW_NULLIFY = 435,
    KW_ONLY = 436,
    KW_OPEN = 437,
    KW_OPERATOR = 438,
    KW_OPTIONAL = 439,
    KW_OUT = 440,
    KW_PARAMETER = 441,
    KW_PASS = 442,
    KW_POINTER = 443,
    KW_POST = 444,
    KW_PRECISION = 445,
    KW_PRINT = 446,
    KW_PRIVATE = 447,
    KW_PROCEDURE = 448,
    KW_PROGRAM = 449,
    KW_PROTECTED = 450,
    KW_PUBLIC = 451,
    KW_PURE = 452,
    KW_QUIET = 453,
    KW_RANK = 454,
    KW_READ = 455,
    KW_REAL = 456,
    KW_RECURSIVE = 457,
    KW_REDUCE = 458,
    KW_RESULT = 459,
    KW_RETURN = 460,
    KW_REWIND = 461,
    KW_SAVE = 462,
    KW_SELECT = 463,
    KW_SELECT_CASE = 464,
    KW_SELECT_RANK = 465,
    KW_SELECT_TYPE = 466,
    KW_SEQUENCE = 467,
    KW_SHARED = 468,
    KW_SOURCE = 469,
    KW_STAT = 470,
    KW_STOP = 471,
    KW_SUBMODULE = 472,
    KW_SUBROUTINE = 473,
    KW_SYNC = 474,
    KW_SYNC_ALL = 475,
    KW_SYNC_IMAGES = 476,
    KW_SYNC_MEMORY = 477,
    KW_SYNC_TEAM = 478,
    KW_TARGET = 479,
    KW_TEAM = 480,
    KW_TEAM_NUMBER = 481,
    KW_THEN = 482,
    KW_TO = 483,
    KW_TYPE = 484,
    KW_UNFORMATTED = 485,
    KW_USE = 486,
    KW_VALUE = 487,
    KW_VOLATILE = 488,
    KW_WAIT = 489,
    KW_WHERE = 490,
    KW_WHILE = 491,
    KW_WRITE = 492,
    UMINUS = 493
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
