#include <lfortran/asr.h>
#include <lfortran/containers.h>
#include <lfortran/exception.h>
#include <lfortran/asr_utils.h>
#include <lfortran/pass/do_loops.h>


namespace LFortran {

/*

This ASR pass replaces do loops with while loops. The function
`pass_replace_do_loops` transforms the ASR tree in-place.

Converts:

    do i = a, b, c
        ...
    end do

to:

    i = a-c
    do while (i+c <= b)
        i = i+c
        ...
    end do

The comparison is >= for c<0.
*/
Vec<ASR::stmt_t*> replace_doloop(Allocator &al, const ASR::DoLoop_t &loop) {
    Location loc = loop.base.base.loc;
    ASR::expr_t *a=loop.m_head.m_start;
    ASR::expr_t *b=loop.m_head.m_end;
    ASR::expr_t *c=loop.m_head.m_increment;
    LFORTRAN_ASSERT(a);
    LFORTRAN_ASSERT(b);
    if (!c) {
        ASR::ttype_t *type = TYPE(ASR::make_Integer_t(al, loc, 4, nullptr, 0));
        c = EXPR(ASR::make_Num_t(al, loc, 1, type));
    }
    LFORTRAN_ASSERT(c);
    int increment;
    if (c->type == ASR::exprType::Num) {
        increment = EXPR_NUM((ASR::asr_t*)c)->m_n;
    } else if (c->type == ASR::exprType::UnaryOp) {
        ASR::UnaryOp_t *u = EXPR_UNARYOP((ASR::asr_t*)c);
        LFORTRAN_ASSERT(u->m_op == ASR::unaryopType::USub);
        LFORTRAN_ASSERT(u->m_operand->type == ASR::exprType::Num);
        increment = - EXPR_NUM((ASR::asr_t*)u->m_operand)->m_n;
    } else {
        throw CodeGenError("Do loop increment type not supported");
    }
    ASR::cmpopType cmp_op;
    if (increment > 0) {
        cmp_op = ASR::cmpopType::LtE;
    } else {
        cmp_op = ASR::cmpopType::GtE;
    }
    ASR::expr_t *target = loop.m_head.m_v;
    ASR::ttype_t *type = TYPE(ASR::make_Integer_t(al, loc, 4, nullptr, 0));
    ASR::stmt_t *stmt1 = STMT(ASR::make_Assignment_t(al, loc, target,
        EXPR(ASR::make_BinOp_t(al, loc, a, ASR::operatorType::Sub, c, type))
    ));

    ASR::expr_t *cond = EXPR(ASR::make_Compare_t(al, loc,
        EXPR(ASR::make_BinOp_t(al, loc, target, ASR::operatorType::Add, c, type)),
        cmp_op, b, type));
    Vec<ASR::stmt_t*> body;
    body.reserve(al, loop.n_body+1);
    body.push_back(al, STMT(ASR::make_Assignment_t(al, loc, target,
        EXPR(ASR::make_BinOp_t(al, loc, target, ASR::operatorType::Add, c, type))
    )));
    for (size_t i=0; i<loop.n_body; i++) {
        body.push_back(al, loop.m_body[i]);
    }
    ASR::stmt_t *stmt2 = STMT(ASR::make_WhileLoop_t(al, loc, cond,
        body.p, body.size()));
    Vec<ASR::stmt_t*> result;
    result.reserve(al, 2);
    result.push_back(al, stmt1);
    result.push_back(al, stmt2);

    /*
    std::cout << "Input:" << std::endl;
    std::cout << pickle((ASR::asr_t&)loop);
    std::cout << "Output:" << std::endl;
    std::cout << pickle((ASR::asr_t&)*stmt1);
    std::cout << pickle((ASR::asr_t&)*stmt2);
    std::cout << "--------------" << std::endl;
    */

    return result;
}

class DoLoopVisitor : public ASR::BaseWalkVisitor<DoLoopVisitor>
{
private:
    Allocator &al;
    Vec<ASR::stmt_t*> do_loop_result;
public:
    DoLoopVisitor(Allocator &al) : al{al} {
        do_loop_result.n = 0;

    }

    void visit_TranslationUnit(const ASR::TranslationUnit_t &x) {
        for (auto &a : x.m_global_scope->scope) {
            this->visit_asr(*a.second);
        }
    }

    void transform_stmts(ASR::stmt_t **&m_body, size_t &n_body) {
        Vec<ASR::stmt_t*> body;
        body.reserve(al, n_body);
        for (size_t i=0; i<n_body; i++) {
            // Not necessary after we check it after each visit_stmt in every
            // visitor method:
            do_loop_result.n = 0;
            visit_stmt(*m_body[i]);
            if (do_loop_result.size() > 0) {
                for (size_t j=0; j<do_loop_result.size(); j++) {
                    body.push_back(al, do_loop_result[j]);
                }
                do_loop_result.n = 0;
            } else {
                body.push_back(al, m_body[i]);
            }
        }
        m_body = body.p;
        n_body = body.size();
    }

    // TODO: Only Program and While is processed, we need to process all calls
    // to visit_stmt().

    void visit_Program(const ASR::Program_t &x) {
        // FIXME: this is a hack, we need to pass in a non-const `x`,
        // which requires to generate a TransformVisitor.
        ASR::Program_t &xx = const_cast<ASR::Program_t&>(x);
        transform_stmts(xx.m_body, xx.n_body);
    }

    void visit_WhileLoop(const ASR::WhileLoop_t &x) {
        // FIXME: this is a hack, we need to pass in a non-const `x`,
        // which requires to generate a TransformVisitor.
        ASR::WhileLoop_t &xx = const_cast<ASR::WhileLoop_t&>(x);
        transform_stmts(xx.m_body, xx.n_body);
    }

    void visit_DoLoop(const ASR::DoLoop_t &x) {
        do_loop_result = replace_doloop(al, x);
    }
};

void pass_replace_do_loops(Allocator &al, ASR::TranslationUnit_t &unit) {
    DoLoopVisitor v(al);
    // Each call transforms only one layer of nested loops, so we call it twice
    // to transform doubly nested loops:
    v.visit_TranslationUnit(unit);
    v.visit_TranslationUnit(unit);
}


} // namespace LFortran
