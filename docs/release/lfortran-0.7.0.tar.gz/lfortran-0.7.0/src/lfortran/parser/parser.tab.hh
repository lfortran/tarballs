/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_REAL = 262,
    TK_PLUS = 263,
    TK_MINUS = 264,
    TK_STAR = 265,
    TK_SLASH = 266,
    TK_COLON = 267,
    TK_SEMICOLON = 268,
    TK_COMMA = 269,
    TK_EQUAL = 270,
    TK_LPAREN = 271,
    TK_RPAREN = 272,
    TK_LBRACKET = 273,
    TK_RBRACKET = 274,
    TK_PERCENT = 275,
    TK_VBAR = 276,
    TK_STRING = 277,
    TK_COMMENT = 278,
    TK_DBL_DOT = 279,
    TK_DBL_COLON = 280,
    TK_POW = 281,
    TK_CONCAT = 282,
    TK_ARROW = 283,
    TK_EQ = 284,
    TK_NE = 285,
    TK_LT = 286,
    TK_LE = 287,
    TK_GT = 288,
    TK_GE = 289,
    TK_NOT = 290,
    TK_AND = 291,
    TK_OR = 292,
    TK_EQV = 293,
    TK_NEQV = 294,
    TK_TRUE = 295,
    TK_FALSE = 296,
    KW_ABSTRACT = 297,
    KW_ALL = 298,
    KW_ALLOCATABLE = 299,
    KW_ALLOCATE = 300,
    KW_ASSIGNMENT = 301,
    KW_ASSOCIATE = 302,
    KW_ASYNCHRONOUS = 303,
    KW_BACKSPACE = 304,
    KW_BIND = 305,
    KW_BLOCK = 306,
    KW_CALL = 307,
    KW_CASE = 308,
    KW_CHARACTER = 309,
    KW_CLASS = 310,
    KW_CLOSE = 311,
    KW_CODIMENSION = 312,
    KW_COMMON = 313,
    KW_COMPLEX = 314,
    KW_CONCURRENT = 315,
    KW_CONTAINS = 316,
    KW_CONTIGUOUS = 317,
    KW_CONTINUE = 318,
    KW_CRITICAL = 319,
    KW_CYCLE = 320,
    KW_DATA = 321,
    KW_DEALLOCATE = 322,
    KW_DEFAULT = 323,
    KW_DEFERRED = 324,
    KW_DIMENSION = 325,
    KW_DO = 326,
    KW_DOWHILE = 327,
    KW_DOUBLE = 328,
    KW_ELEMENTAL = 329,
    KW_ELSE = 330,
    KW_END = 331,
    KW_END_IF = 332,
    KW_ENDIF = 333,
    KW_END_DO = 334,
    KW_ENDDO = 335,
    KW_END_WHERE = 336,
    KW_ENDWHERE = 337,
    KW_ENTRY = 338,
    KW_ENUM = 339,
    KW_ENUMERATOR = 340,
    KW_EQUIVALENCE = 341,
    KW_ERRMSG = 342,
    KW_ERROR = 343,
    KW_EXIT = 344,
    KW_EXTENDS = 345,
    KW_EXTERNAL = 346,
    KW_FILE = 347,
    KW_FINAL = 348,
    KW_FLUSH = 349,
    KW_FORALL = 350,
    KW_FORMAT = 351,
    KW_FORMATTED = 352,
    KW_FUNCTION = 353,
    KW_GENERIC = 354,
    KW_GO = 355,
    KW_IF = 356,
    KW_IMPLICIT = 357,
    KW_IMPORT = 358,
    KW_IMPURE = 359,
    KW_IN = 360,
    KW_INCLUDE = 361,
    KW_INOUT = 362,
    KW_INQUIRE = 363,
    KW_INTEGER = 364,
    KW_INTENT = 365,
    KW_INTERFACE = 366,
    KW_INTRINSIC = 367,
    KW_IS = 368,
    KW_KIND = 369,
    KW_LEN = 370,
    KW_LOCAL = 371,
    KW_LOCAL_INIT = 372,
    KW_LOGICAL = 373,
    KW_MODULE = 374,
    KW_MOLD = 375,
    KW_NAME = 376,
    KW_NAMELIST = 377,
    KW_NOPASS = 378,
    KW_NON_INTRINSIC = 379,
    KW_NON_OVERRIDABLE = 380,
    KW_NON_RECURSIVE = 381,
    KW_NONE = 382,
    KW_NULLIFY = 383,
    KW_ONLY = 384,
    KW_OPEN = 385,
    KW_OPERATOR = 386,
    KW_OPTIONAL = 387,
    KW_OUT = 388,
    KW_PARAMETER = 389,
    KW_PASS = 390,
    KW_POINTER = 391,
    KW_PRECISION = 392,
    KW_PRINT = 393,
    KW_PRIVATE = 394,
    KW_PROCEDURE = 395,
    KW_PROGRAM = 396,
    KW_PROTECTED = 397,
    KW_PUBLIC = 398,
    KW_PURE = 399,
    KW_QUIET = 400,
    KW_RANK = 401,
    KW_READ = 402,
    KW_REAL = 403,
    KW_RECURSIVE = 404,
    KW_REDUCE = 405,
    KW_RESULT = 406,
    KW_RETURN = 407,
    KW_REWIND = 408,
    KW_SAVE = 409,
    KW_SELECT = 410,
    KW_SEQUENCE = 411,
    KW_SHARED = 412,
    KW_SOURCE = 413,
    KW_STAT = 414,
    KW_STOP = 415,
    KW_SUBMODULE = 416,
    KW_SUBROUTINE = 417,
    KW_TARGET = 418,
    KW_TEAM = 419,
    KW_TEAM_NUMBER = 420,
    KW_THEN = 421,
    KW_TO = 422,
    KW_TYPE = 423,
    KW_UNFORMATTED = 424,
    KW_USE = 425,
    KW_VALUE = 426,
    KW_VOLATILE = 427,
    KW_WHERE = 428,
    KW_WHILE = 429,
    KW_WRITE = 430,
    UMINUS = 431
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
