/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_LABEL = 262,
    TK_REAL = 263,
    TK_BOZ_CONSTANT = 264,
    TK_PLUS = 265,
    TK_MINUS = 266,
    TK_STAR = 267,
    TK_SLASH = 268,
    TK_COLON = 269,
    TK_SEMICOLON = 270,
    TK_COMMA = 271,
    TK_EQUAL = 272,
    TK_LPAREN = 273,
    TK_RPAREN = 274,
    TK_LBRACKET = 275,
    TK_RBRACKET = 276,
    TK_RBRACKET_OLD = 277,
    TK_PERCENT = 278,
    TK_VBAR = 279,
    TK_STRING = 280,
    TK_COMMENT = 281,
    TK_DBL_DOT = 282,
    TK_DBL_COLON = 283,
    TK_POW = 284,
    TK_CONCAT = 285,
    TK_ARROW = 286,
    TK_EQ = 287,
    TK_NE = 288,
    TK_LT = 289,
    TK_LE = 290,
    TK_GT = 291,
    TK_GE = 292,
    TK_NOT = 293,
    TK_AND = 294,
    TK_OR = 295,
    TK_EQV = 296,
    TK_NEQV = 297,
    TK_TRUE = 298,
    TK_FALSE = 299,
    TK_FORMAT = 300,
    KW_ABSTRACT = 301,
    KW_ALL = 302,
    KW_ALLOCATABLE = 303,
    KW_ALLOCATE = 304,
    KW_ASSIGNMENT = 305,
    KW_ASSOCIATE = 306,
    KW_ASYNCHRONOUS = 307,
    KW_BACKSPACE = 308,
    KW_BIND = 309,
    KW_BLOCK = 310,
    KW_CALL = 311,
    KW_CASE = 312,
    KW_CHARACTER = 313,
    KW_CLASS = 314,
    KW_CLOSE = 315,
    KW_CODIMENSION = 316,
    KW_COMMON = 317,
    KW_COMPLEX = 318,
    KW_CONCURRENT = 319,
    KW_CONTAINS = 320,
    KW_CONTIGUOUS = 321,
    KW_CONTINUE = 322,
    KW_CRITICAL = 323,
    KW_CYCLE = 324,
    KW_DATA = 325,
    KW_DEALLOCATE = 326,
    KW_DEFAULT = 327,
    KW_DEFERRED = 328,
    KW_DIMENSION = 329,
    KW_DO = 330,
    KW_DOWHILE = 331,
    KW_DOUBLE = 332,
    KW_DOUBLE_PRECISION = 333,
    KW_ELEMENTAL = 334,
    KW_ELSE = 335,
    KW_ELSEIF = 336,
    KW_ELSEWHERE = 337,
    KW_END = 338,
    KW_END_PROGRAM = 339,
    KW_ENDPROGRAM = 340,
    KW_END_MODULE = 341,
    KW_ENDMODULE = 342,
    KW_END_SUBMODULE = 343,
    KW_ENDSUBMODULE = 344,
    KW_END_BLOCK = 345,
    KW_ENDBLOCK = 346,
    KW_END_BLOCK_DATA = 347,
    KW_ENDBLOCKDATA = 348,
    KW_END_SUBROUTINE = 349,
    KW_ENDSUBROUTINE = 350,
    KW_END_FUNCTION = 351,
    KW_ENDFUNCTION = 352,
    KW_END_PROCEDURE = 353,
    KW_ENDPROCEDURE = 354,
    KW_END_ENUM = 355,
    KW_ENDENUM = 356,
    KW_END_SELECT = 357,
    KW_ENDSELECT = 358,
    KW_END_IF = 359,
    KW_ENDIF = 360,
    KW_END_INTERFACE = 361,
    KW_ENDINTERFACE = 362,
    KW_END_TYPE = 363,
    KW_ENDTYPE = 364,
    KW_END_ASSOCIATE = 365,
    KW_ENDASSOCIATE = 366,
    KW_END_FORALL = 367,
    KW_ENDFORALL = 368,
    KW_END_DO = 369,
    KW_ENDDO = 370,
    KW_END_WHERE = 371,
    KW_ENDWHERE = 372,
    KW_END_CRITICAL = 373,
    KW_ENDCRITICAL = 374,
    KW_ENTRY = 375,
    KW_ENUM = 376,
    KW_ENUMERATOR = 377,
    KW_EQUIVALENCE = 378,
    KW_ERRMSG = 379,
    KW_ERROR = 380,
    KW_EVENT = 381,
    KW_EXIT = 382,
    KW_EXTENDS = 383,
    KW_EXTERNAL = 384,
    KW_FILE = 385,
    KW_FINAL = 386,
    KW_FLUSH = 387,
    KW_FORALL = 388,
    KW_FORMATTED = 389,
    KW_FUNCTION = 390,
    KW_GENERIC = 391,
    KW_GO = 392,
    KW_GOTO = 393,
    KW_IF = 394,
    KW_IMPLICIT = 395,
    KW_IMPORT = 396,
    KW_IMPURE = 397,
    KW_IN = 398,
    KW_INCLUDE = 399,
    KW_INOUT = 400,
    KW_IN_OUT = 401,
    KW_INQUIRE = 402,
    KW_INTEGER = 403,
    KW_INTENT = 404,
    KW_INTERFACE = 405,
    KW_INTRINSIC = 406,
    KW_IS = 407,
    KW_KIND = 408,
    KW_LEN = 409,
    KW_LOCAL = 410,
    KW_LOCAL_INIT = 411,
    KW_LOGICAL = 412,
    KW_MODULE = 413,
    KW_MOLD = 414,
    KW_NAME = 415,
    KW_NAMELIST = 416,
    KW_NOPASS = 417,
    KW_NON_INTRINSIC = 418,
    KW_NON_OVERRIDABLE = 419,
    KW_NON_RECURSIVE = 420,
    KW_NONE = 421,
    KW_NULLIFY = 422,
    KW_ONLY = 423,
    KW_OPEN = 424,
    KW_OPERATOR = 425,
    KW_OPTIONAL = 426,
    KW_OUT = 427,
    KW_PARAMETER = 428,
    KW_PASS = 429,
    KW_POINTER = 430,
    KW_POST = 431,
    KW_PRECISION = 432,
    KW_PRINT = 433,
    KW_PRIVATE = 434,
    KW_PROCEDURE = 435,
    KW_PROGRAM = 436,
    KW_PROTECTED = 437,
    KW_PUBLIC = 438,
    KW_PURE = 439,
    KW_QUIET = 440,
    KW_RANK = 441,
    KW_READ = 442,
    KW_REAL = 443,
    KW_RECURSIVE = 444,
    KW_REDUCE = 445,
    KW_RESULT = 446,
    KW_RETURN = 447,
    KW_REWIND = 448,
    KW_SAVE = 449,
    KW_SELECT = 450,
    KW_SELECT_CASE = 451,
    KW_SELECT_RANK = 452,
    KW_SELECT_TYPE = 453,
    KW_SEQUENCE = 454,
    KW_SHARED = 455,
    KW_SOURCE = 456,
    KW_STAT = 457,
    KW_STOP = 458,
    KW_SUBMODULE = 459,
    KW_SUBROUTINE = 460,
    KW_SYNC = 461,
    KW_TARGET = 462,
    KW_TEAM = 463,
    KW_TEAM_NUMBER = 464,
    KW_THEN = 465,
    KW_TO = 466,
    KW_TYPE = 467,
    KW_UNFORMATTED = 468,
    KW_USE = 469,
    KW_VALUE = 470,
    KW_VOLATILE = 471,
    KW_WAIT = 472,
    KW_WHERE = 473,
    KW_WHILE = 474,
    KW_WRITE = 475,
    UMINUS = 476
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
