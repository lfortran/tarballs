results = [
    ('Use', (1, 1), ('use_symbol', 'b', None), []),
    ('Use', (1, 1), ('use_symbol', 'a', None), [('use_symbol', 'b', None), ('use_symbol', 'c', None)]),
    ('Use', (1, 1), ('use_symbol', 'a', None), [('use_symbol', 'x', 'b'), ('use_symbol', 'c', None), ('use_symbol', 'd', 'a')]),
]
